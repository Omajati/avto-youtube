"use strict";
const $ = (s, el = document) => el.querySelector(s);
const main = $("#main");
let META = null;
let timer = null;

const STATUS_RU = { queued: "В очереди", running: "Делается", review: "Ждёт вашей проверки", paused: "На паузе", done: "Готово", error: "Ошибка" };

function esc(s) { return String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])); }
function nl(s) { return esc(s).replace(/\n/g, "<br>"); }
function toast(msg, err = false) {
  const d = document.createElement("div"); d.textContent = msg; if (err) d.className = "err";
  $("#toast").appendChild(d); setTimeout(() => d.remove(), err ? 9000 : 3500);
}
async function api(path, opts = {}) {
  const o = { ...opts };
  if (o.json !== undefined) { o.method = o.method || "POST"; o.headers = { "Content-Type": "application/json" }; o.body = JSON.stringify(o.json); delete o.json; }
  const r = await fetch(path, o);
  if (!r.ok) {
    let msg = `Ошибка ${r.status}`;
    try { const j = await r.json(); msg = j.error || j.detail || msg; } catch (e) { }
    throw new Error(msg);
  }
  const ct = r.headers.get("content-type") || "";
  return ct.includes("json") ? r.json() : r.blob();
}
function scoreCls(v) { return v >= 8 ? "s-good" : v >= 7 ? "s-mid" : "s-bad"; }
function score(v) { return `<span class="score ${scoreCls(v)}">${esc(v)}</span>`; }
function fmtTime(sec) { sec = Math.round(sec || 0); return `${Math.floor(sec / 60)}:${String(sec % 60).padStart(2, "0")}`; }
function badge(st) { return `<span class="badge ${st}">${STATUS_RU[st] || st}</span>`; }
function copyBtn(text) { return `<button class="sm" data-copy="${esc(text)}">Копировать</button>`; }
document.addEventListener("click", e => {
  const b = e.target.closest("[data-copy]");
  if (b) { navigator.clipboard.writeText(b.dataset.copy); toast("Скопировано"); }
});

// ------------------------------------------------------------------ theme: auto follows the Mac (light by day, dark at night)
const darkMQ = matchMedia("(prefers-color-scheme: dark)");
function themeMode() { try { return localStorage.getItem("ay_theme") || "auto"; } catch (e) { return "auto"; } }
function applyTheme() {
  const m = themeMode();
  document.documentElement.dataset.theme = m === "dark" || (m === "auto" && darkMQ.matches) ? "dark" : "light";
  document.querySelectorAll("#themesw [data-th]").forEach(b => b.classList.toggle("on", b.dataset.th === m));
}
darkMQ.addEventListener("change", applyTheme);
document.querySelectorAll("#themesw [data-th]").forEach(b => b.onclick = () => {
  try { localStorage.setItem("ay_theme", b.dataset.th); } catch (e) { }
  applyTheme();
});
applyTheme();

// ------------------------------------------------------------------ strict looks and the owner's order of the sidebar sections
const lsGetRaw = k => { try { return localStorage.getItem(k); } catch (e) { return null; } };
const lsSetRaw = (k, v) => { try { v == null ? localStorage.removeItem(k) : localStorage.setItem(k, v); } catch (e) { } };
(function () {
  const ls = document.getElementById("looksel");
  if (ls) {
    ls.value = lsGetRaw("ay_look") || "";
    ls.onchange = () => { lsSetRaw("ay_look", ls.value || null); if (ls.value) document.documentElement.dataset.look = ls.value; else delete document.documentElement.dataset.look; };
  }
  const nav = document.querySelector(".side nav"), btn = document.getElementById("navedit");
  // Line icons for the strict looks (the emoji stay for the usual look).
  const P = {
    new: '<rect x="3" y="3" width="18" height="18" rx="4"/><path d="M12 8v8M8 12h8"/>',
    jobs: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 4v16M17 4v16M3 9h4M3 15h4M17 9h4M17 15h4"/>',
    montage: '<circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><path d="M20 4 8.1 15.9M14.5 14.5 20 20M8.1 8.1 12 12"/>',
    "local-editor": '<rect x="2" y="4" width="20" height="16" rx="2"/><path d="M7 4v16M17 4v16M2 9h5M2 15h5M17 9h5M17 15h5"/>',
    remake: '<path d="M17 2l4 4-4 4"/><path d="M3 11V9a3 3 0 0 1 3-3h15"/><path d="M7 22l-4-4 4-4"/><path d="M21 13v2a3 3 0 0 1-3 3H3"/>',
    producer: '<path d="M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9z"/><path d="M19 15l.8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8z"/>',
    library: '<path d="M2 4h6a4 4 0 0 1 4 4v13a3 3 0 0 0-3-3H2zM22 4h-6a4 4 0 0 0-4 4v13a3 3 0 0 1 3-3h7z"/>',
    projects: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
    characters: '<circle cx="9" cy="8" r="4"/><path d="M2 21a7 7 0 0 1 14 0M16 3.1a4 4 0 0 1 0 7.8M22 21a7 7 0 0 0-4-6.3"/>',
    items: '<path d="M21 8 12 3 3 8v8l9 5 9-5z"/><path d="M3 8l9 5 9-5M12 13v8"/>',
    settings: '<path d="M4 6h10M18 6h2M4 12h4M12 12h8M4 18h12M20 18h0"/><circle cx="16" cy="6" r="2"/><circle cx="10" cy="12" r="2"/><circle cx="18" cy="18" r="2"/>',
    prompts: '<path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><path d="M14 3v6h6M8 13h8M8 17h5"/>',
    insta: '<rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><path d="M17.5 6.5h0"/>',
    music: '<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>',
    channels: '<rect x="2" y="5" width="20" height="14" rx="3"/><path d="M10 9.5v5l4.5-2.5z"/>',
    balance: '<rect x="2" y="6" width="20" height="14" rx="2"/><path d="M2 10h20M16 15h2"/>',
    help: '<circle cx="12" cy="12" r="9"/><path d="M9.5 9a2.5 2.5 0 1 1 3.5 2.3c-.6.3-1 .9-1 1.6V14M12 17.5h0"/>',
  };
  nav.querySelectorAll("a[data-nav]").forEach(a => { const d = P[a.dataset.nav]; if (d) a.insertAdjacentHTML("afterbegin", `<svg class="ni" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">${d}</svg>`); });
  const GROUPS = { new: "Создание", producer: "Знания", settings: "Система" };
  const DEFAULT = ["new", "jobs", "channels", "montage", "local-editor", "remake", "producer", "library", "insta", "projects", "characters", "items", "settings", "prompts", "music", "balance", "help"];
  const heads = () => {
    nav.querySelectorAll(".ngrp").forEach(x => x.remove());
    if (nav.classList.contains("editing")) return;
    const cur = [...nav.querySelectorAll("a[data-nav]")].map(a => a.dataset.nav);
    if (cur.join() !== DEFAULT.join()) return;  // the owner's own order: no group captions
    Object.entries(GROUPS).forEach(([k, t]) => nav.querySelector(`a[data-nav="${k}"]`).insertAdjacentHTML("beforebegin", `<div class="ngrp">${t}</div>`));
  };
  if (!nav || !btn) return;
  const links = () => [...nav.querySelectorAll("a[data-nav]")];
  const save = () => { lsSetRaw("ay_nav", JSON.stringify(links().map(a => a.dataset.nav))); heads(); };
  let order = []; try { order = JSON.parse(lsGetRaw("ay_nav") || "[]"); } catch (e) { }
  order.forEach(k => { const a = nav.querySelector(`a[data-nav="${k}"]`); if (a) nav.appendChild(a); });
  links().filter(a => !order.includes(a.dataset.nav) && order.length).forEach(a => nav.appendChild(a));  // new sections go last
  heads();
  links().forEach(a => {
    a.insertAdjacentHTML("beforeend", `<span class="mv"><b data-up title="Выше">▲</b><b data-dn title="Ниже">▼</b></span>`);
    a.querySelector("[data-up]").onclick = e => { e.preventDefault(); e.stopPropagation(); if (a.previousElementSibling) nav.insertBefore(a, a.previousElementSibling); save(); };
    a.querySelector("[data-dn]").onclick = e => { e.preventDefault(); e.stopPropagation(); if (a.nextElementSibling) nav.insertBefore(a.nextElementSibling, a); save(); };
    a.addEventListener("dragstart", e => { a.classList.add("drag"); e.dataTransfer.effectAllowed = "move"; });
    a.addEventListener("dragend", () => { a.classList.remove("drag"); save(); });
    a.addEventListener("dragover", e => {
      const cur = nav.querySelector("a.drag"); if (!cur || cur === a) return;
      e.preventDefault(); const r = a.getBoundingClientRect();
      nav.insertBefore(cur, e.clientY < r.top + r.height / 2 ? a : a.nextSibling);
    });
    a.addEventListener("click", e => { if (nav.classList.contains("editing")) e.preventDefault(); });
  });
  btn.onclick = () => {
    const on = !nav.classList.contains("editing");
    nav.classList.toggle("editing", on); links().forEach(a => a.draggable = on);
    if (on) nav.querySelectorAll(".ngrp").forEach(x => x.remove()); else heads();
    btn.textContent = on ? "✓ Готово" : "↕ Переставить разделы";
    if (!on) save();
  };
})();

// ------------------------------------------------------------------ my channels (the owner's notebook)
const CH_STATUS = {
  "": ["Без статуса", "st-none"], dead: ["Мёртвый", "st-dead"], subs: ["Нужны подписчики", "st-subs"], views: ["Идут просмотры", "st-views"],
  monetized: ["Монетизация", "st-mon"], demonetized: ["Демонетизация", "st-demon"],
};
async function viewMyChannels() {
  let list = (await api("/api/mychannels")).channels || [];
  let filter = lsGet("ay_ch_filter") || "all";
  let saveT = null;
  const save = (now) => {
    const lab = $("#mc-saved"); if (lab) lab.textContent = "Сохраняю…";
    clearTimeout(saveT);
    saveT = setTimeout(async () => {
      try { await api("/api/mychannels", { method: "PUT", json: { channels: list } }); if ($("#mc-saved")) $("#mc-saved").textContent = "✓ Сохранено"; }
      catch (e) { toast(e.message, true); }
    }, now ? 0 : 600);
  };
  const pill = st => `<span class="mc-pill ${CH_STATUS[st || ""][1]}">${CH_STATUS[st || ""][0]}</span>`;
  const head = ch => `${pill(ch.status)} <b>${esc(ch.name || "Без названия")}</b>${ch.niche ? ` <span class="muted small">· ${esc(ch.niche)}</span>` : ""}${ch.url ? ` <a class="small" href="${esc(ch.url)}" target="_blank" onclick="event.stopPropagation()">открыть ↗</a>` : ""}`;
  const fieldRow = (f, j) => `<div class="mc-field" data-j="${j}"><input type="text" data-ff="label" value="${esc(f.label)}" placeholder="Что (например, подписчики)"><input type="text" data-ff="value" value="${esc(f.value)}" placeholder="Значение"><button class="sm danger" data-fdel title="Удалить поле">✕</button></div>`;
  const draw = () => {
    const counts = {}; list.forEach(c => { counts[c.status || ""] = (counts[c.status || ""] || 0) + 1; });
    const shown = list.map((c, i) => [c, i]).filter(([c]) => filter === "all" || (c.status || "") === filter);
    main.innerHTML = `<h1>📺 Мои каналы</h1>
    <div class="card">
      <p class="muted small" style="margin-top:0">Ваша записная книжка по каналам: ниша, статус, заметки и любые свои данные. Всё сохраняется само и попадает в резервную копию.</p>
      <div class="row"><button class="primary" id="mc-add">＋ Добавить канал</button>
        <button class="sm" id="mc-open">Развернуть все</button><button class="sm" id="mc-close">Свернуть все</button>
        <span id="mc-saved" class="muted small"></span></div>
      <div class="row mc-filter" style="margin-top:10px">
        <button class="sm ${filter === "all" ? "on" : ""}" data-flt="all">Все (${list.length})</button>
        ${Object.entries(CH_STATUS).filter(([k]) => counts[k]).map(([k, [n]]) => `<button class="sm ${filter === k ? "on" : ""}" data-flt="${k}">${n} (${counts[k]})</button>`).join("")}
      </div>
    </div>
    ${list.length ? "" : `<div class="card muted">Каналов пока нет. Нажмите «Добавить канал».</div>`}
    <div id="mc-list">${shown.map(([ch, i]) => `<details class="card mc ${CH_STATUS[ch.status || ""][1]}" data-i="${i}" ${ch.open ? "open" : ""}>
      <summary class="mc-head">${head(ch)}</summary>
      <div class="grid2"><div>
        <label class="f">Название канала</label><input type="text" data-f="name" value="${esc(ch.name)}">
        <label class="f">Ниша</label><input type="text" data-f="niche" value="${esc(ch.niche)}" placeholder="например, истории, загадки истории">
      </div><div>
        <label class="f">Ссылка на канал</label><input type="text" data-f="url" value="${esc(ch.url)}" placeholder="https://youtube.com/@...">
        <label class="f">Статус</label><select data-f="status">${Object.entries(CH_STATUS).map(([k, [n]]) => `<option value="${k}" ${(ch.status || "") === k ? "selected" : ""}>${n}</option>`).join("")}</select>
      </div></div>
      <label class="f">Заметка</label><textarea data-f="note" rows="4" placeholder="Что угодно: идеи, что сработало, пароли не храните">${esc(ch.note)}</textarea>
      <label class="f">Мои данные <span class="hint">Любые поля: подписчики, доход, дата создания, почта, частота роликов…</span></label>
      <div class="mc-fields">${(ch.fields || []).map(fieldRow).join("")}</div>
      <div class="row" style="margin-top:8px"><button class="sm" data-fadd>＋ Поле</button><span style="flex:1"></span>
        <button class="sm" data-up title="Выше">▲</button><button class="sm" data-dn title="Ниже">▼</button>
        <button class="sm danger" data-del>Удалить канал</button></div>
    </details>`).join("")}</div>`;
    $("#mc-add").onclick = () => {
      list.unshift({ id: String(Date.now()), name: "", url: "", niche: "", note: "", status: "", open: true, fields: [] });
      filter = "all"; lsSet("ay_ch_filter", filter); save(true); draw();
      main.querySelector('#mc-list details [data-f="name"]')?.focus();
    };
    $("#mc-open").onclick = () => { list.forEach(c => c.open = true); save(); draw(); };
    $("#mc-close").onclick = () => { list.forEach(c => c.open = false); save(); draw(); };
    main.querySelectorAll("[data-flt]").forEach(b => b.onclick = () => { filter = b.dataset.flt; lsSet("ay_ch_filter", filter); draw(); });
    main.querySelectorAll("details.mc").forEach(box => {
      const i = +box.dataset.i, ch = list[i];
      box.addEventListener("toggle", () => { if (ch.open !== box.open) { ch.open = box.open; save(); } });
      box.querySelectorAll("[data-f]").forEach(el => el.addEventListener(el.tagName === "SELECT" ? "change" : "input", () => {
        ch[el.dataset.f] = el.value; save();
        box.querySelector(".mc-head").innerHTML = head(ch);
        if (el.dataset.f === "status") box.className = `card mc ${CH_STATUS[ch.status || ""][1]}`;
      }));
      const bindFields = () => box.querySelectorAll(".mc-field").forEach(row => {
        const j = +row.dataset.j;
        row.querySelectorAll("[data-ff]").forEach(el => el.oninput = () => { ch.fields[j][el.dataset.ff] = el.value; save(); });
        row.querySelector("[data-fdel]").onclick = () => { ch.fields.splice(j, 1); save(); redrawFields(); };
      });
      const redrawFields = () => { box.querySelector(".mc-fields").innerHTML = (ch.fields || []).map(fieldRow).join(""); bindFields(); };
      bindFields();
      box.querySelector("[data-fadd]").onclick = () => { (ch.fields = ch.fields || []).push({ label: "", value: "" }); save(); redrawFields(); box.querySelector(".mc-field:last-child input")?.focus(); };
      box.querySelector("[data-del]").onclick = () => { if (!confirm(`Удалить канал «${ch.name || "без названия"}» из списка?`)) return; list.splice(i, 1); save(true); draw(); };
      box.querySelector("[data-up]").onclick = () => { if (i > 0) { [list[i - 1], list[i]] = [list[i], list[i - 1]]; save(); draw(); } };
      box.querySelector("[data-dn]").onclick = () => { if (i < list.length - 1) { [list[i + 1], list[i]] = [list[i], list[i + 1]]; save(); draw(); } };
    });
  };
  draw();
}

// ------------------------------------------------------------------ router
async function route() {
  clearInterval(timer); timer = null;
  if (!META) { META = await api("/api/meta"); STYLE_PRESETS = META.image_styles; }
  const [, page, id] = (location.hash || "#/jobs").split("/");
  document.querySelectorAll("[data-nav]").forEach(a => a.classList.toggle("active", a.dataset.nav === page || (page === "job" && a.dataset.nav === "jobs")));
  try {
    if (page === "new") await viewNew();
    else if (page === "job") await viewJob(id);
    else if (page === "settings") await viewSettings(id);
    else if (page === "projects") await viewProjects(id);
    else if (page === "characters") await viewCharacters();
    else if (page === "items") await viewItems();
    else if (page === "prompts") await viewPrompts(id);
    else if (page === "music") await viewMusic();
    else if (page === "montage") await viewMontage();
    else if (page === "local-editor") await viewLocalEditor(id);
    else if (page === "remake") await viewRemake(id);
    else if (page === "producer") await viewProducer(id);
    else if (page === "library") await viewLibrary(id);
    else if (page === "insta") await viewInsta();
    else if (page === "help") viewHelp();
    else if (page === "balance") await viewBalance();
    else if (page === "channels") await viewMyChannels();
    else await viewJobs();
  } catch (e) { main.innerHTML = `<div class="banner bad">${esc(e.message)}</div>`; }
  draftRestore();
  rememberTab();
}
window.addEventListener("hashchange", route);

// ------------------------------------------------------------------ unsaved input survives leaving the page
// Everything typed on a page is kept per page address until it is saved, so switching tabs loses nothing.
const DRAFT_PAGES = ["new", "projects", "settings", "characters", "items", "prompts"];
function draftKey() { return "ay_draft:" + (location.hash || "#/jobs"); }
function draftOn() { return DRAFT_PAGES.includes((location.hash || "#/jobs").split("/")[1]); }
function draftFields() {
  const out = {}, seen = {};
  main.querySelectorAll("input, textarea, select").forEach(el => {
    if (el.type === "file" || el.type === "button" || el.closest("[data-nodraft]")) return;
    let k = el.id ? "#" + el.id : el.dataset.q ? "q:" + el.dataset.q : el.dataset.p ? "p:" + el.dataset.p : el.name ? "n:" + el.name : el.tagName + "." + el.className;
    if (!el.id && !el.dataset.q && !el.name) { seen[k] = (seen[k] || 0) + 1; k += "@" + seen[k]; }
    out[k] = el;
  });
  return out;
}
const fieldVal = el => el.type === "checkbox" || el.type === "radio" ? el.checked : el.value;
function draftClear() { try { localStorage.removeItem(draftKey()); } catch (e) { } }
function draftBaseReset() {
  main.dataset.draftBase = JSON.stringify(Object.fromEntries(Object.entries(draftFields()).map(([k, el]) => [k, fieldVal(el)])));
  $("#draft-bar")?.remove();
}
let draftTimer = null;
function draftSave() {
  if (!draftOn() || main.dataset.restoring) return;
  const d = {};
  Object.entries(draftFields()).forEach(([k, el]) => d[k] = fieldVal(el));
  const base = JSON.parse(main.dataset.draftBase || "{}");
  const changed = Object.fromEntries(Object.entries(d).filter(([k, v]) => base[k] !== v));
  if (Object.keys(changed).length) lsSet(draftKey(), JSON.stringify(changed)); else draftClear();
}
main.addEventListener("input", () => { clearTimeout(draftTimer); draftTimer = setTimeout(draftSave, 300); });
main.addEventListener("change", () => { clearTimeout(draftTimer); draftTimer = setTimeout(draftSave, 300); });
function draftRestore() {
  if (!draftOn()) return;
  const base = {};
  Object.entries(draftFields()).forEach(([k, el]) => base[k] = fieldVal(el));
  main.dataset.draftBase = JSON.stringify(base);
  let d = {};
  try { d = JSON.parse(lsGet(draftKey(), "{}")) || {}; } catch (e) { }
  if (!Object.keys(d).length) return;
  const apply = () => {
    const f = draftFields(); let changed = 0;
    main.dataset.restoring = 1;
    Object.entries(d).forEach(([k, v]) => {
      const el = f[k]; if (!el || fieldVal(el) === v) return;
      if (el.type === "checkbox" || el.type === "radio") el.checked = v; else el.value = v;
      if (el.tagName === "SELECT" && el.value !== v) return;  // options not loaded yet
      el.dispatchEvent(new Event("change", { bubbles: true }));
      changed++;
    });
    delete main.dataset.restoring;
    if (changed) showBar();
  };
  const showBar = () => {
    if ($("#draft-bar")) return;
    const bar = document.createElement("div");
    bar.id = "draft-bar";
    bar.className = "banner warn";
  bar.innerHTML = `На этой странице есть несохранённые изменения, я их вернул. Не забудьте сохранить. <button class="sm" id="draft-drop">Отменить изменения</button>`;
    main.prepend(bar);
    $("#draft-drop").onclick = () => { draftClear(); route(); };
  };
  const page = location.hash;
  apply();
  setTimeout(() => { if (location.hash === page) apply(); }, 1500);  // some lists (voices) appear a moment later
}

// ------------------------------------------------------------------ recent pages as tabs
const TAB_ICONS = { new: "＋", jobs: "🎬", job: "🎞️", "local-editor": "🎞️", projects: "📁", characters: "🧑‍🎨", items: "📦", settings: "⚙️", prompts: "📝", music: "🎵", remake: "🔁", producer: "🎓", library: "📚", help: "❓", balance: "💰" };
function getTabs() { try { return JSON.parse(lsGet("ay_tabs", "[]")) || []; } catch (e) { return []; } }
function rememberTab() {
  const hash = location.hash || "#/jobs";
  const page = hash.split("/")[1] || "jobs";
  const h1 = main.querySelector("h1");
  const title = ($("#le-title")?.value || (h1 ? h1.textContent : page)).trim().replace(/\s+/g, " ").slice(0, 60);
  let tabs = getTabs();
  const i = tabs.findIndex(t => t.hash === hash);
  if (i >= 0) tabs[i].title = title; else tabs.push({ hash, title, icon: TAB_ICONS[page] || "📄" });
  if (tabs.length > 8) tabs = tabs.slice(-8);
  lsSet("ay_tabs", JSON.stringify(tabs));
  renderTabs();
}
function renderTabs() {
  const cur = location.hash || "#/jobs";
  $("#tabbar").innerHTML = getTabs().map(t => `<a class="tb ${t.hash === cur ? "on" : ""}" href="${esc(t.hash)}" title="${esc(t.title)}">${t.icon} <span>${esc(t.title)}</span><b data-close="${esc(t.hash)}" title="Закрыть">×</b></a>`).join("")
    + `<a class="tnew" href="#/new">＋ Новый ролик</a>`;
  $("#tabbar").querySelectorAll("[data-close]").forEach(x => x.onclick = e => {
    e.preventDefault(); e.stopPropagation();
    const tabs = getTabs(), i = tabs.findIndex(t => t.hash === x.dataset.close);
    tabs.splice(i, 1); lsSet("ay_tabs", JSON.stringify(tabs));
    if (x.dataset.close === cur) location.hash = tabs.length ? tabs[Math.min(i, tabs.length - 1)].hash : "#/jobs";
    else renderTabs();
  });
}

// ------------------------------------------------------------------ new video
async function viewNew() {
  const s = await api("/api/settings");
  const yt = await api("/api/youtube").catch(() => ({ channels: [] }));
  const projs = await api("/api/projects").catch(() => []);
  let curProj = lsGet("ay_proj");
  if (!projs.find(p => p.id === curProj)) curProj = "";
  const missing = [];
  if (s.llm_provider === "anthropic" ? !s.anthropic_key : !s.openai_key) missing.push("нейросети для сценария");
  if (s.voice_provider === "royal" ? !s.royal_key : !s.elevenlabs_key) missing.push(s.voice_provider === "royal" ? "RoyalTechno (озвучка)" : "ElevenLabs (озвучка)");
  const prov = META.providers[s.image_provider];
  if (prov && !s[prov.key_field]) missing.push(`${prov.name} (картинки)`);
  main.innerHTML = `
  <h1>Новый ролик</h1>
  ${missing.length ? `<div class="banner warn">Не хватает ключей: ${missing.join(", ")}. Вставьте их в <a href="#/settings">Настройках</a>. Пока можно нажать «Проверить установку» внизу: соберётся тестовый ролик без ключей.</div>` : ""}
  <div class="card">
    <label class="f" style="margin-top:0">Проект <span class="hint">Одной кнопкой подставляются язык, ниша, голос, стиль и остальные настройки проекта. <a href="#/projects">Создать или изменить проекты</a></span></label>
    <div class="pgrid" id="projsel">
      <button class="pcard ${curProj ? "" : "on"}" data-proj=""><div class="pic">⚙️</div><div><b>Без проекта</b><div class="muted small">общие настройки</div></div></button>
      ${projs.map(p => `<button class="pcard ${p.id === curProj ? "on" : ""}" data-proj="${p.id}"><div class="pic">${esc(p.icon)}</div><div><b>${esc(p.name)}</b><div class="muted small">${LANG_RU[p.language] || "английский"}${p.platform === "instagram" ? " · Инстаграм" : ""}</div></div></button>`).join("")}
    </div>
    <div id="charsel"></div><div id="itemsel"></div><input type="hidden" id="fmtv" value="long"><input type="hidden" id="charsv" value=""><input type="hidden" id="itemsv" value="">
    <label class="f">Формат</label>
    <div class="pgrid" style="margin-bottom:4px">
      <button class="pcard on" data-fmt="long"><div class="pic">🎬</div><div><b>Видео + шортс</b><div class="muted small">длинное видео, шортс по желанию</div></div></button>
      <button class="pcard" data-fmt="short"><div class="pic">📱</div><div><b>Только шортс</b><div class="muted small">вертикальное видео до 60 секунд</div></div></button>
    </div>
    <label class="f">Тема ролика <span class="hint">Можно по-русски. Оставьте пустым, и программа сама придумает 5 тем и выберет самую цепляющую (ещё темы можно попросить кнопкой).</span></label>
    <textarea id="topic" placeholder="Например: загадочное исчезновение колонии Роанок"></textarea>
    <div id="series-hint" class="banner" style="display:none;margin-top:8px"></div>
    <div class="grid2">
      <div class="long-only">
        <label class="f">Длительность, минут</label>
        <input type="number" id="dur" min="1" max="30" step="1" value="${esc(s.duration_min)}">
      </div>
      <div class="short-only" style="display:none">
        <label class="f">Длина шортса, секунд <span class="hint">15–180. Лучше всего заходят 30–60 секунд</span></label>
        <input type="number" id="sec" min="15" max="180" step="5" value="50">
      </div>
      <div>
        <label class="f">Сколько роликов сделать <span class="hint">Каждый получит свою тему</span></label>
        <input type="number" id="count" min="1" max="20" value="1">
      </div>
    </div>
    ${yt.channels.length ? `<label class="f">Для какого канала <span class="hint">Берутся ниша, голос и стиль картинок этого канала</span></label>
    <select id="chan"><option value="">Без канала (общие настройки)</option>${yt.channels.map(c => `<option value="${c.id}">${esc(c.title)}</option>`).join("")}</select>` : ""}
    <div class="grid2"><div>
      <label class="f">Ниша <span class="hint">Берётся из проекта или общих настроек</span></label>
      <textarea id="niche" data-nodraft rows="3">${esc(s.niche)}</textarea>
    </div><div>
      <label class="f">Язык ролика <span class="hint">Сценарий, озвучка и субтитры</span></label>
      <select id="lang">${Object.entries(META.languages).map(([k, n]) => `<option value="${k}">${esc(n)}</option>`).join("")}</select>
    </div></div>
    <label class="check long-only"><input type="checkbox" id="short" checked> Сделать ещё и вертикальный шортс (до 60 секунд)</label>
    <label class="check"><input type="checkbox" id="mute"> Без озвучки, только музыка <span class="muted small">(без голоса и без текста на экране)</span></label>
    <div class="grid2">
      <div><label class="f">Анимация сцен <span class="hint">Оживить картинки нейросетью (fal.ai, платно за каждую сцену)</span></label>
        <select id="anim">${animModes().map(([k, n]) => `<option value="${k}" ${k === s.anim_mode ? "selected" : ""}>${esc(n)}</option>`).join("")}</select>
        <div id="anim-n-box"><label class="f">Сколько сцен оживить <span class="hint">Конкретные сцены можно выбрать потом на странице ролика</span></label><input type="number" id="anim-n" min="1" max="60" value="${s.anim_count || 3}"></div></div>
      <div><label class="f">&nbsp;</label><label class="check long-only"><input type="checkbox" id="anim-s" ${s.anim_short ? "checked" : ""}> Оживить и шортс <span class="muted small">(столько же первых сцен)</span></label>
        <label class="check"><input type="checkbox" id="img-p"> Свои картинки: пауза перед рисованием <span class="muted small">(после озвучки ролик остановится, вы загрузите картинки, сделанные в другом месте, и нажмёте «Продолжить»; недостающие программа дорисует сама)</span></label>
        <label class="check"><input type="checkbox" id="anim-p"> Пауза перед анимацией: я сам выберу сцены <span class="muted small">(когда картинки готовы, ролик остановится, вы отметите любые сцены и нажмёте «Продолжить»)</span></label></div>
    </div>
    <label class="f">Музыка <span class="hint">Сочинение новой платное, около $0.30 за минуту, трек сохранится в «Музыку»</span></label>
    <select id="music" style="max-width:520px">${Object.entries(META.music_modes).map(([k, n]) => `<option value="${k}">${esc(n)}</option>`).join("")}</select>
    <label class="f">Эффекты <span class="hint">Звуки перелистывания и ударов, наезды, тряска. Нейросеть ставит их по смыслу сценария. Бесплатно.</span></label>
    <select id="fx" style="max-width:520px">${Object.entries(META.fx_modes).map(([k, n]) => `<option value="${k}" ${k === (s.fx_mode || "light") ? "selected" : ""}>${esc(n)}</option>`).join("")}</select>
    <label class="check"><input type="checkbox" id="subs-v" ${s.subtitles_long ? "checked" : ""}> <span id="subs-v-l">Субтитры на длинном видео</span></label>
    <label class="check long-only"><input type="checkbox" id="subs-s" ${s.subtitles_short ? "checked" : ""}> Субтитры на шортсе</label>
    <label class="check"><input type="checkbox" id="subs-smart" checked> Субтитры в свободном месте кадра <span class="muted small">(если внизу кадра лицо, надпись или много деталей, строка переносится в спокойное место кадра)</span></label>
    <label class="check"><input type="checkbox" id="gfx" checked> Анимации данных <span class="muted small">(счётчики, деньги, проценты, таймеры, сравнения, галочки, стрелки, ключевые слова в момент, когда голос их называет; бесплатно, один короткий запрос к ИИ на ролик)</span></label>
    <label class="check"><input type="checkbox" id="ideapause" ${lsGet("ay_ideapause", "1") === "1" ? "checked" : ""} onchange="lsSet('ay_ideapause', this.checked ? '1' : '0')"> Выбирать тему вручную: показать лучшие темы и подождать, пока я отмечу одну <span class="muted small">(до сценария, почти бесплатно)</span></label>
    <label class="check"><input type="checkbox" id="pause" ${lsGet("ay_pause", "1") === "1" ? "checked" : ""} onchange="lsSet('ay_pause', this.checked ? '1' : '0')"> Ручная правка текста: остановиться сразу после проверки редактором, чтобы я прочитал и при желании исправил текст <span class="muted small">(дальше ничего не делается, пока вы не нажмёте «Продолжить»)</span></label>
    <div id="est" class="muted small"></div>
    <div class="row" style="margin-top:16px">
      <button class="primary big" id="go">▶ Запустить</button>
    </div>
  </div>
  <div class="card">
    <h2>Проверить установку</h2>
    <p class="muted">Соберёт короткий тестовый ролик с цветными заставками и гудками вместо голоса. Ключи не нужны и деньги не тратятся. Так видно, что сборка видео на вашем Mac работает.</p>
    <button id="demo">Проверить установку</button>
  </div>`;
  const upd = async () => {
    try {
      const e = await api(`/api/estimate?minutes=${$("#dur").value}&short=${$("#short").checked}&anim_mode=${$("#anim").value}&anim_short=${$("#anim-s").checked}&anim_count=${$("#anim-n").value}&language=${$("#lang").value}&format=${fmt}&short_seconds=${$("#sec").value}&music_mode=${$("#music").value}`);
      $("#anim-n-box").style.display = ["hook", "key"].includes($("#anim").value) ? "" : "none";
      const n = Math.max(1, +$("#count").value || 1);
      $("#est").textContent = `Примерная стоимость одного ролика: ~$${e.total} (сценарий ~$${e.llm_cost}, ${e.images} картинок ~$${e.image_cost}${e.anim_cost ? `, анимация ~$${e.anim_cost}` : ""}${e.music_cost ? `, музыка ~$${e.music_cost}` : ""}) + ~${e.tts_chars.toLocaleString("ru")} символов ElevenLabs из вашего тарифа.` + (n > 1 ? ` Всего роликов: ${n}.` : "");
    } catch (e) { }
  };
  ["#dur", "#sec", "#music", "#short", "#count", "#anim", "#anim-n", "#anim-s", "#lang"].forEach(id => $(id).addEventListener("change", upd)); upd();
  let fmt = "long";
  const setFmt = (f, fromUser) => {
    fmt = f; $("#fmtv").value = f;
    main.querySelectorAll("[data-fmt]").forEach(b => b.classList.toggle("on", b.dataset.fmt === f));
    main.querySelectorAll(".long-only").forEach(el => el.style.display = f === "short" ? "none" : "");
    main.querySelectorAll(".short-only").forEach(el => el.style.display = f === "short" ? "" : "none");
    $("#subs-v-l").textContent = f === "short" ? "Субтитры" : "Субтитры на длинном видео";
    const pj = projs.find(x => x.id === curProj);  // a chosen project keeps its own subtitles and effects
    if (fromUser) $("#subs-v").checked = pj ? !!(f === "short" ? pj.subs_short : pj.subs_video) : (f === "short" ? !!s.subtitles_short : !!s.subtitles_long);
    if (fromUser) $("#fx").value = pj ? pj.fx_mode || "light" : (f === "short" ? "strong" : (s.fx_mode || "light"));
    upd();
  };
  main.querySelectorAll("[data-fmt]").forEach(b => b.onclick = () => { setFmt(b.dataset.fmt, true); main.dispatchEvent(new Event("input")); });
  $("#fmtv").addEventListener("change", () => setFmt($("#fmtv").value));
  const syncChars = () => { $("#charsv").value = [...main.querySelectorAll("[data-char].on")].map(b => b.dataset.char).join(","); };
  $("#charsv").addEventListener("change", () => { const want = new Set($("#charsv").value.split(",")); main.querySelectorAll("[data-char]").forEach(b => b.classList.toggle("on", want.has(b.dataset.char))); });
  const syncItems = () => { $("#itemsv").value = [...main.querySelectorAll("[data-item].on")].map(b => b.dataset.item).join(","); };
  $("#itemsv").addEventListener("change", () => { const want = new Set($("#itemsv").value.split(",")); main.querySelectorAll("[data-item]").forEach(b => b.classList.toggle("on", want.has(b.dataset.item))); });
  const applyProj = () => {
    const p = projs.find(x => x.id === curProj);
    if ($("#charsel")) $("#charsel").style.display = p && p.ad_mode ? "none" : "";  // a commercial shows no people
    if ($("#itemsel")) $("#itemsel").dataset.ad = p && p.ad_mode ? "1" : "";
    main.querySelectorAll("[data-proj]").forEach(b => b.classList.toggle("on", b.dataset.proj === curProj));
    $("#niche").value = p ? (p.niche || "") : s.niche;  // a project never borrows the general (history) default
    $("#lang").value = p ? p.language : "en";
    $("#dur").value = p ? p.duration_min : s.duration_min;
    $("#sec").value = p ? p.short_seconds || 50 : 50;
    $("#music").value = p ? p.music_mode || "library" : "library";
    $("#short").checked = p ? p.make_short : true;
    $("#mute").checked = !!(p && p.voice_off);
    const take = !!(p && p.ad_mode && p.one_take);  // one take: the camera glides over one picture, nothing to animate
    $("#anim").value = take ? "off" : p ? p.anim_mode : s.anim_mode;
    $("#anim").disabled = take;
    $("#anim").title = take ? "Одним дублем: анимацией управляет настройка проекта «Облёт товара»" : "";
    $("#anim-s").checked = p ? p.anim_short : s.anim_short;
    $("#anim-n").value = (p && p.anim_count) || s.anim_count || 3;
    $("#anim-p").checked = !!(p && p.anim_pause);
    $("#img-p").checked = !!(p && p.images_pause);
    $("#subs-v").checked = p ? p.subs_video : s.subtitles_long;
    $("#subs-s").checked = p ? p.subs_short : s.subtitles_short;
    if ($("#chan")) $("#chan").value = (p && p.channel_id && yt.channels.find(c => c.id === p.channel_id)) ? p.channel_id : "";
    setFmt(p ? p.format || "long" : "long");
    const hint = $("#series-hint"); hint.style.display = "none";
    if (p && p.series) api(`/api/projects/${p.id}/episodes`).then(r => {
      if (curProj !== p.id) return;
      const lines = (p.season_plan || "").split("\n").map(l => l.trim()).filter(Boolean)
        .map(l => l.replace(/^\s*(серия|episode|ep\.?)?\s*\d+\s*[.):—-]*\s*/i, "").trim());
      const plan = lines[r.next - 1];
      hint.innerHTML = `📺 Это сериал: следующий ролик станет <b>серией ${r.next}</b>. ` + (plan
        ? `Если тему не писать, сюжет возьмётся из плана сезона: «${esc(plan)}», с учётом библии сериала и прошлых серий.`
        : `В плане сезона нет строки для этой серии, поэтому если тему не писать, программа сама придумает продолжение по библии сериала и прошлым сериям.`)
        + ` Если тему написать, серия будет про неё, но всё равно продолжит сюжет.`;
      hint.style.display = "";
    }).catch(() => { });
    const want = new Set(p ? p.characters || [] : []);
    $("#charsel").querySelectorAll("[data-char]").forEach(b => b.classList.toggle("on", want.has(b.dataset.char)));
    syncChars();
    const wantI = new Set(p ? p.items || [] : []);
    $("#itemsel").querySelectorAll("[data-item]").forEach(b => b.classList.toggle("on", wantI.has(b.dataset.item)));
    syncItems();
    $("#fx").value = p ? p.fx_mode || "light" : (s.fx_mode || "light");
    $("#gfx").checked = p ? p.graphics !== false : true;
    $("#subs-smart").checked = p ? p.subs_smart !== false : true;
    if (p && p.format === "short") $("#subs-v").checked = p.subs_short;
  };
  main.querySelectorAll("[data-proj]").forEach(b => b.onclick = () => { curProj = b.dataset.proj; lsSet("ay_proj", curProj); applyProj(); });
  const allChars = await api("/api/characters").catch(() => []);
  $("#charsel").innerHTML = `<label class="f">Персонажи в ролике <span class="hint">Нажмите, чтобы выбрать. Сценарий и картинки будут строиться вокруг них. Персонажи проекта отмечаются сами. <a href="#/characters">Добавить персонажа</a></span></label>
    ${allChars.length ? `<div class="row">${allChars.map(c => `<button class="cbtn" data-char="${c.id}" title="${esc(c.role)}">${charIcon(c, 48)}<span>${esc(c.name)}</span></button>`).join("")}</div>`
      : `<p class="muted small" style="margin:0">Персонажей пока нет. Их можно добавить в разделе «Персонажи» слева.</p>`}`;
  $("#charsel").querySelectorAll("[data-char]").forEach(b => b.onclick = () => { b.classList.toggle("on"); syncChars(); main.dispatchEvent(new Event("input")); });
  const allItems = await api("/api/items").catch(() => []);
  $("#itemsel").innerHTML = `<label class="f">Предметы в ролике <span class="hint">Товары и вещи, которые должны появиться в кадре точно как на ваших фото. Предметы проекта отмечаются сами. <a href="#/items">Добавить предмет</a></span></label>
    ${allItems.length ? `<div class="row">${allItems.map(it => `<button class="cbtn" data-item="${it.id}" title="${esc(it.kind)}">${itemIcon(it, 48)}<span>${esc(it.name)}</span></button>`).join("")}</div>`
      : `<p class="muted small" style="margin:0">Предметов пока нет. Их можно добавить в разделе «Предметы» слева.</p>`}`;
  $("#itemsel").querySelectorAll("[data-item]").forEach(b => b.onclick = () => { b.classList.toggle("on"); syncItems(); main.dispatchEvent(new Event("input")); });
  if (curProj) applyProj();
  if ($("#chan")) $("#chan").onchange = () => {
    const c = yt.channels.find(x => x.id === $("#chan").value);
    if (!curProj) $("#niche").value = (c && c.profile.niche) || s.niche;  // a chosen project keeps its own niche
  };
  $("#go").onclick = async () => {
    if (!curProj && projs.length && !confirm("Проект не выбран. Ролик возьмёт общую нишу из настроек и общий голос, а не нишу и голос вашего проекта. Всё равно запустить?\n\nЧтобы взять настройки проекта, нажмите «Отмена» и выберите проект вверху страницы.")) return;
    const jobs = await api("/api/jobs", { json: { topic: $("#topic").value, duration_min: +$("#dur").value, short_seconds: +$("#sec").value, music_mode: $("#music").value, count: +$("#count").value, niche: $("#niche").value, make_short: $("#short").checked, voice_off: $("#mute").checked, review_pause: $("#pause").checked, idea_pause: $("#ideapause").checked, channel_id: $("#chan") ? $("#chan").value : undefined, subs_video: $("#subs-v").checked, subs_short: $("#subs-s").checked, anim_mode: $("#anim").value, anim_short: $("#anim-s").checked, anim_count: +$("#anim-n").value, anim_pause: $("#anim-p").checked, images_pause: $("#img-p").checked, project_id: curProj, language: $("#lang").value, format: fmt, fx_mode: $("#fx").value, graphics: $("#gfx").checked, subs_smart: $("#subs-smart").checked, characters: [...main.querySelectorAll("[data-char].on")].map(b => b.dataset.char), items: [...main.querySelectorAll("[data-item].on")].map(b => b.dataset.item) } });
    draftClear(); toast("Запущено"); location.hash = jobs.length === 1 ? `#/job/${jobs[0].id}` : "#/jobs";
  };
  $("#demo").onclick = async () => {
    const jobs = await api("/api/jobs", { json: { demo: true, make_short: true } });
    location.hash = `#/job/${jobs[0].id}`;
  };
}

// ------------------------------------------------------------------ list
function lsGet(k, d = "") { try { return localStorage.getItem(k) ?? d; } catch (e) { return d; } }
function lsSet(k, v) { try { localStorage.setItem(k, v); } catch (e) { } }

async function viewJobs() {
  const projs = await api("/api/projects");
  let filter = lsGet("ay_jobs_filter");
  if (filter && filter !== "none" && !projs.find(p => p.id === filter)) filter = "";
  const render = async () => {
    const jobs = await api(`/api/jobs?project=${encodeURIComponent(filter)}`);
    const tabs = projs.length ? `<div class="tabs">
      <button class="${filter ? "" : "on"}" data-f="">Все</button>
      ${projs.map(p => `<button class="${filter === p.id ? "on" : ""}" data-f="${p.id}">${esc(p.icon)} ${esc(p.name)}</button>`).join("")}
      <button class="${filter === "none" ? "on" : ""}" data-f="none">Без проекта</button></div>` : "";
    main.innerHTML = `<div class="row"><h1 class="grow">Ролики</h1><button id="openvids" title="Фильмы → Авто ютуб: папка на каждый проект, внутри папка на каждый ролик">📂 Папка с роликами</button><a class="btn primary" href="#/new">＋ Новый ролик</a></div>
    ${tabs}
    ${jobs.length ? "" : `<div class="card muted">${filter ? "В этом проекте пока нет роликов." : "Пока нет ни одного ролика. Нажмите «Новый ролик»."}</div>`}
    <div class="jobs">${jobs.map(j => `
      <a class="jobcard" href="#/job/${j.id}">
        <div class="thumb" style="${j.thumb ? `background-image:url('/files/${j.id}/${j.thumb}')` : ""}">${j.thumb ? "" : "🎬"}<span class="tpill">${badge(j.status)}</span></div>
        <div class="body">
          <div class="t">${j.options.episode ? `Серия ${j.options.episode}. ` : ""}${esc(j.options.title_ru || j.title || j.topic || "Тема ещё выбирается…")}${j.options.demo ? " <span class='muted small'>(тест)</span>" : ""}</div>
          <div class="row small">${badge(j.status)} <span class="muted">${esc(j.status === "running" ? j.stage_name : new Date(j.created * 1000).toLocaleString("ru"))}</span></div>
          ${j.project || j.channel_title ? `<div class="muted small" style="margin-top:4px">${j.project ? `${esc(j.project.icon)} ${esc(j.project.name)}` : ""}${j.project && j.channel_title ? " · " : ""}${j.channel_title ? `📺 ${esc(j.channel_title)}` : ""}${j.options.language && j.options.language !== "en" ? " · " + j.options.language.toUpperCase() : ""}</div>` : ""}
          ${["running", "queued", "paused"].includes(j.status) ? `<div class="bar" style="margin-top:8px"><div style="width:${j.progress}%"></div></div>` : ""}
          ${j.status === "error" ? `<div class="small" style="color:var(--bad);margin-top:6px">${esc(j.error.slice(0, 140))}</div>` : ""}
        </div>
      </a>`).join("")}</div>`;
    main.querySelectorAll("[data-f]").forEach(b => b.onclick = () => { filter = b.dataset.f; lsSet("ay_jobs_filter", filter); render(); });
    $("#openvids").onclick = () => api("/api/open", { json: { what: "videos" } }).catch(e => toast(e.message, true));
  };
  await render();
  timer = setInterval(() => render().catch(() => { }), 3000);
}

// ------------------------------------------------------------------ projects
function charIcon(c, size = 56) {
  return c.has_portrait
    ? `<img class="cicon" style="width:${size}px;height:${size}px" src="/portraits/${c.id}.png?v=${Date.now()}">`
    : `<div class="cicon" style="width:${size}px;height:${size}px;font-size:${size / 2.4}px">${esc((c.name || "?")[0].toUpperCase())}</div>`;
}

async function renderChars() {
  const box = $("#chars");
  const list = await api("/api/characters");
  const projs = await api("/api/projects").catch(() => []);
  const oldStyle = c => c.style || (projs.find(p => p.id === c.style_project) || {}).image_style || "";
  const projSel = (cur) => `<div class="row" style="gap:6px">${Object.entries(STYLE_PRESETS).map(([k, v]) => `<button class="sm ${v.text === cur ? "on" : ""}" data-cstyle="${k}" title="${esc(v.desc)}">${esc(v.name)}</button>`).join("")}</div>
    <div class="small c-style-desc" style="margin-top:6px">${styleDesc(cur)}</div>
    <details style="margin-top:4px"><summary class="muted small">Точный текст стиля для нейросети (по-английски, можно поправить)</summary><textarea class="c-style" rows="3">${esc(cur)}</textarea></details>`;
  const form = (c = {}) => `<div class="cform" data-cid="${c.id || ""}">
    <div class="grid2"><div>
      <label class="f">Имя</label><input type="text" class="c-name" value="${esc(c.name)}" placeholder="Например: Дед Архип">
    </div><div>
      <label class="f">Роль <span class="hint">рассказчик, ведущий, главный герой…</span></label><input type="text" class="c-role" value="${esc(c.role)}">
    </div></div>
    <label class="f">Стиль портрета <span class="hint">Как будет нарисован персонаж. Наведите на кнопку, чтобы прочитать описание.</span></label>${projSel(oldStyle(c))}
    <label class="f">Описание по-русски <span class="hint">Возраст, характер, чем занимается. Если загружаете фото, внешность программа опишет сама строго по фото.</span></label>
    <textarea class="c-desc">${esc(c.description_ru)}</textarea>
    <label class="f">Дополнения для сцен <span class="hint">Необязательно. Другая одежда, вещи, детали, которые можно добавлять в некоторых сценах, например: «зимой — тёплая куртка и шапка», «в офисе — костюм». Основная внешность при этом не меняется.</span></label>
    <textarea class="c-extra" rows="2">${esc(c.extra_ru || "")}</textarea>
    <label class="f">Манера речи <span class="hint">Необязательно. Как говорит персонаж: тон, любимые словечки, присказки, 2–3 примера фраз. Сценарист будет писать его реплики и рассказ именно так.</span></label>
    <textarea class="c-speech" rows="4" placeholder="Например: говорит спокойно и с ухмылкой, коротко. Словечки: «блин», «короче», «бабло». Фразы: «Вёз я вчера одного…», «Ладно, поехали дальше.»">${esc(c.speech_ru || "")}</textarea>
    <label class="f">Голос персонажа <span class="hint">Если выбрать, персонаж будет сам говорить своим голосом: сценарий напишет ему реплики, а озвучка прочитает их этим голосом. Без голоса его слова пересказывает рассказчик.</span></label>
    <div class="row" style="gap:6px;flex-wrap:nowrap"><select class="c-voice"><option value="">Без своего голоса</option>${c.voice_id ? `<option value="${esc(c.voice_id)}" selected>${esc(c.voice_name || c.voice_id)}</option>` : ""}</select>
      <button class="sm c-vprev" type="button">▶</button></div>
    <input type="text" class="c-voice-id" placeholder="…или вставьте ID голоса из ElevenLabs" style="margin-top:6px">
    ${c.id ? "" : `<label class="f">Фото персонажа <span class="hint">Необязательно. Можно выбрать сразу несколько (до 9): спереди, сбоку, со спины, детали. Первое станет главным портретом, остальные — фото с разных сторон.</span></label><input type="file" accept="image/*" multiple class="c-newfile">`}
    ${c.id ? `<label class="f">Внешность для картинок (по-английски) <span class="hint">Составлена автоматически, можно поправить</span></label><textarea class="c-app">${esc(c.appearance)}</textarea>` : ""}
    <div class="row" style="margin-top:10px">
      <button class="primary sm c-save">${c.id ? "Сохранить" : "Добавить персонажа"}</button>
      ${c.id ? `<button class="sm c-desc-btn">🔍 Описать внешность по фото</button>
        <button class="sm c-draw">🎨 Нарисовать портрет</button>
        <label class="btn sm" style="cursor:pointer">📤 Загрузить свой<input type="file" accept="image/*" class="c-file" style="display:none"></label>
        <span class="grow"></span><button class="sm danger c-del">Удалить</button>` : ""}
    </div></div>`;
  box.innerHTML = (list.length ? `<div class="clist tiles">${list.map(c => `<details class="citem ctile"><summary>${charIcon(c, 64)}<b>${esc(c.name)}</b><span class="muted small">${esc(c.role)}</span></summary><div class="cbody">
      ${charIcon(c, 72)}<div class="grow"><b>${esc(c.name)}</b> <span class="muted small">${esc(c.role)}</span>
      <div class="small">${esc(c.description_ru)}</div>${c.appearance ? `<div class="en">${esc(c.appearance)}</div>` : ""}${c.extra_ru ? `<div class="small" style="margin-top:2px">➕ Дополнения для сцен: ${esc(c.extra_ru)}</div>` : ""}${c.speech_ru ? `<div class="small" style="margin-top:2px">💬 Манера речи: ${esc(c.speech_ru)}</div>` : ""}<div class="small" style="margin-top:2px">${c.voice_id ? `🗣 Свой голос: ${esc(c.voice_name || c.voice_id)}` : `<span class="muted">🗣 Своего голоса нет, его слова пересказывает рассказчик</span>`}</div><div class="small muted" style="margin-top:2px">${styleDesc(oldStyle(c)).replace("Выбрано", "Стиль портрета")}</div>
      <div class="row" style="margin-top:6px;gap:6px"><button class="sm c-edit" data-cid="${c.id}">Изменить</button>
        <label class="btn sm" style="cursor:pointer">📤 ${c.has_portrait ? "Заменить портрет" : "Загрузить портрет"}<input type="file" accept="image/*" class="c-qfile" data-cid="${c.id}" style="display:none"></label>
        <button class="sm c-qdraw" data-cid="${c.id}">🎨 Нарисовать портрет</button>
        <label class="btn sm" style="cursor:pointer">📷 Фото с разных сторон (${(c.refs || []).length}/8)<input type="file" accept="image/*" multiple class="c-refs" data-cid="${c.id}" style="display:none"></label></div>
      ${(c.refs || []).length ? `<div class="refstrip">${c.refs.map(r => `<div class="ref"><img src="/charrefs/${c.id}/${r}?v=${Date.now()}">
        <b data-rmain="${c.id}/${r}" title="Сделать главным портретом">★</b><b data-rdel="${c.id}/${r}" title="Удалить фото">×</b></div>`).join("")}</div>` : ""}
      </div></div></details>`).join("")}</div>` : `<p class="muted">Персонажей пока нет.</p>`)
    + `<details class="cnew" ${list.length ? "" : "open"}><summary><b>＋ Новый персонаж</b></summary>` + form() + `</details>`;
  const bind = (root) => {
    const cid = root.dataset.cid;
    const val = cls => root.querySelector(cls)?.value ?? "";
    const vsel = root.querySelector(".c-voice");
    const voiceVal = () => {
      const manual = val(".c-voice-id").trim();
      if (manual) return { voice_id: manual, voice_name: `Свой голос (${manual.slice(0, 6)}…)` };
      const o = vsel.options[vsel.selectedIndex];
      return { voice_id: vsel.value, voice_name: vsel.value ? (o.dataset.name || o.text) : "" };
    };
    loadVoices().then(vs => { const cur = vsel.value; vsel.innerHTML = vsel.options[0].outerHTML + voiceOptions(vs, cur, ""); vsel.value = cur; }).catch(() => { });
    addLibButton(vsel, "");
    root.querySelector(".c-vprev").onclick = () => {
      const v = (VOICES || []).find(x => x.voice_id === vsel.value);
      if (!v || !v.preview_url) return toast("Выберите голос из списка (для своего ID образца нет)", true);
      const a = new Audio(v.preview_url); a.play();
    };
    root.querySelectorAll("[data-cstyle]").forEach(b => b.onclick = () => {
      const v = STYLE_PRESETS[b.dataset.cstyle];
      root.querySelector(".c-style").value = v.text;
      root.querySelector(".c-style-desc").innerHTML = styleDesc(v.text);
      root.querySelectorAll("[data-cstyle]").forEach(x => x.classList.toggle("on", x === b));
      root.querySelector(".c-style").dispatchEvent(new Event("input", { bubbles: true }));
    });
    root.querySelector(".c-style").oninput = () => { root.querySelector(".c-style-desc").innerHTML = styleDesc(root.querySelector(".c-style").value); };
    root.querySelector(".c-save").onclick = async e => {
      e.target.disabled = true;
      const files = [...(root.querySelector(".c-newfile")?.files || [])];
      const body = { name: val(".c-name"), role: val(".c-role"), description_ru: val(".c-desc"), extra_ru: val(".c-extra"), speech_ru: val(".c-speech"), style: val(".c-style"), ...voiceVal(), ...(cid ? { appearance: val(".c-app") } : {}) };
      try {
        let c = await api(`/api/characters${cid ? "/" + cid : ""}`, { json: { ...body, later: !cid && files.length > 0 } });
        if (!cid && files.length) {
          // Photos first, then the look is described from them.
          for (const [i, f] of files.slice(0, 9).entries())
            await api(`/api/characters/${c.id}/${i ? "refs" : "upload"}`, { method: "POST", body: f });
          toast("Фото загружены, описываю внешность по фото…");
          c = await api(`/api/characters/${c.id}`, { json: { ...body, describe: true } });
        }
        draftClear(); if (c.warning) toast(c.warning, true); else toast("Персонаж сохранён");
      } catch (err) { toast(err.message, true); }
      renderChars();
    };
    if (!cid) return;
    root.querySelector(".c-desc-btn").onclick = async e => {
      e.target.disabled = true;
      toast("Смотрю на фото и описываю внешность…");
      await api(`/api/characters/${cid}`, { json: { name: val(".c-name"), role: val(".c-role"), description_ru: val(".c-desc"), extra_ru: val(".c-extra"), speech_ru: val(".c-speech"), style: val(".c-style"), ...voiceVal(), describe: true } })
        .then(c => c.warning ? toast(c.warning, true) : toast("Описание обновлено по фото")).catch(err => toast(err.message, true));
      renderChars();
    };
    root.querySelector(".c-draw").onclick = async e => {
      e.target.disabled = true; e.target.textContent = "Рисую…";
      await api(`/api/characters/${cid}/portrait`, { json: {} }).then(() => toast("Портрет готов")).catch(err => toast(err.message, true));
      renderChars();
    };
    root.querySelector(".c-file").onchange = async e => {
      const f = e.target.files[0]; if (!f) return;
      await api(`/api/characters/${cid}/upload`, { method: "POST", body: f }).then(() => toast("Портрет загружен")).catch(err => toast(err.message, true));
      renderChars();
    };
    root.querySelector(".c-del").onclick = async () => {
      if (!confirm("Удалить персонажа?")) return;
      await api(`/api/characters/${cid}`, { method: "DELETE" }); renderChars();
    };
  };
  box.querySelectorAll(".cform").forEach(bind);
  box.querySelectorAll(".c-qfile").forEach(inp => inp.onchange = async () => {
    const f = inp.files[0]; if (!f) return;
    await api(`/api/characters/${inp.dataset.cid}/upload`, { method: "POST", body: f }).then(() => toast("Портрет загружен")).catch(err => toast(err.message, true));
    renderChars();
  });
  box.querySelectorAll(".c-refs").forEach(inp => inp.onchange = async () => {
    const files = [...inp.files]; if (!files.length) return;
    toast(`Загружаю фото: ${files.length}…`);
    for (const f of files) {
      const ok = await api(`/api/characters/${inp.dataset.cid}/refs`, { method: "POST", body: f }).then(() => true).catch(err => { toast(err.message, true); return false; });
      if (!ok) break;
    }
    toast("Фото добавлены. Нажмите «Изменить» → «Описать внешность по фото», чтобы описание учло новые фото.");
    renderChars();
  });
  box.querySelectorAll("[data-rdel]").forEach(x => x.onclick = async () => {
    if (!confirm("Удалить это фото?")) return;
    await api(`/api/characters/${x.dataset.rdel.replace("/", "/refs/")}`, { method: "DELETE" }); renderChars();
  });
  box.querySelectorAll("[data-rmain]").forEach(x => x.onclick = async () => {
    await api(`/api/characters/${x.dataset.rmain.replace("/", "/refs/")}/main`, { method: "POST" }).then(() => toast("Главный портрет заменён")).catch(err => toast(err.message, true));
    renderChars();
  });
  box.querySelectorAll(".c-qdraw").forEach(b => b.onclick = async () => {
    b.disabled = true; b.textContent = "Рисую…";
    await api(`/api/characters/${b.dataset.cid}/portrait`, { json: {} }).then(() => toast("Портрет готов")).catch(err => toast(err.message, true));
    renderChars();
  });
  box.querySelectorAll(".c-edit").forEach(b => b.onclick = () => {
    const c = list.find(x => x.id === b.dataset.cid);
    const item = b.closest(".citem");
    item.outerHTML = `<div class="citem">${charIcon(c, 72)}<div class="grow">${form(c)}</div></div>`;
    bind(box.querySelector(`.cform[data-cid="${c.id}"]`));
  });
}

async function viewCharacters() {
  main.innerHTML = `<h1>Персонажи</h1>
  <p class="muted">Ваша библиотека постоянных героев: рассказчики, ведущие, герои мультиков и сериалов. Опишите персонажа по-русски, программа сама составит описание внешности для картинок. Потом нарисуйте портрет или загрузите свою картинку, а ещё до 8 фото с разных сторон (спина, профиль, детали): они складываются в один лист-подсказку, и нейросеть рисует персонажа одинаково со всех сторон. Персонажи хранятся всегда и подходят для любого проекта: при запуске ролика их выбирают кнопками, а в проекте можно отметить, кто выбирается сам по умолчанию. На картинках они выглядят как на портрете (через fal.ai, ~$0.04 за такую картинку).</p>
  <div class="card" id="chars">Загружаю…</div>`;
  await renderChars();
}

// ------------------------------------------------------------------ items
function itemIcon(it, size = 56) {
  return it.has_photo
    ? `<img class="cicon iicon" style="width:${size}px;height:${size}px" src="/itemphotos/${it.id}.png?v=${Date.now()}">`
    : `<div class="cicon iicon" style="width:${size}px;height:${size}px;font-size:${size / 2.4}px">📦</div>`;
}

async function renderItems() {
  const box = $("#items");
  const list = await api("/api/items");
  const form = (it = {}) => `<div class="cform" data-iid="${it.id || ""}">
    <div class="grid2"><div>
      <label class="f">Название</label><input type="text" class="i-name" value="${esc(it.name)}" placeholder="Например: Бритва Philips S5000">
    </div><div>
      <label class="f">Что это <span class="hint">товар, техника, игрушка, упаковка…</span></label><input type="text" class="i-kind" value="${esc(it.kind)}">
    </div></div>
    <label class="f">Описание по-русски <span class="hint">Что это за вещь и как ей пользуются. Как она выглядит, программа опишет сама строго по фото.</span></label>
    <textarea class="i-desc">${esc(it.description_ru)}</textarea>
    <label class="f">Как показывать в кадре <span class="hint">Необязательно. Например: «всегда в руке героя», «стоит на столе логотипом к зрителю», «показывать в коробке».</span></label>
    <textarea class="i-extra" rows="2">${esc(it.extra_ru || "")}</textarea>
    ${it.id ? "" : `<label class="f">Фото предмета <span class="hint">Можно выбрать сразу несколько (до 9): спереди, сбоку, сзади, упаковка, логотип крупно. Первое станет главным фото. Лучше на однотонном фоне.</span></label><input type="file" accept="image/*" multiple class="i-newfile">`}
    ${it.id ? `<label class="f">Описание для картинок (по-английски) <span class="hint">Составлено автоматически по фото, можно поправить</span></label><textarea class="i-app">${esc(it.appearance)}</textarea>` : ""}
    <div class="row" style="margin-top:10px">
      <button class="primary sm i-save">${it.id ? "Сохранить" : "Добавить предмет"}</button>
      ${it.id ? `<button class="sm i-desc-btn">🔍 Описать по фото</button><span class="grow"></span><button class="sm danger i-del">Удалить</button>` : ""}
    </div></div>`;
  box.innerHTML = (list.length ? `<div class="clist tiles">${list.map(it => `<details class="citem ctile"><summary>${itemIcon(it, 64)}<b>${esc(it.name)}</b><span class="muted small">${esc(it.kind)}</span></summary><div class="cbody">
      ${itemIcon(it, 72)}<div class="grow"><b>${esc(it.name)}</b> <span class="muted small">${esc(it.kind)}</span>
      <div class="small">${esc(it.description_ru)}</div>${it.appearance ? `<div class="en">${esc(it.appearance)}</div>` : ""}${it.extra_ru ? `<div class="small" style="margin-top:2px">🎬 В кадре: ${esc(it.extra_ru)}</div>` : ""}
      ${it.has_photo ? "" : `<div class="small" style="margin-top:2px;color:var(--bad, #b91c1c)">Нет фото: без него предмет рисуется только по описанию и может отличаться.</div>`}
      <div class="row" style="margin-top:6px;gap:6px"><button class="sm i-edit" data-iid="${it.id}">Изменить</button>
        <label class="btn sm" style="cursor:pointer">📤 ${it.has_photo ? "Заменить главное фото" : "Загрузить фото"}<input type="file" accept="image/*" class="i-qfile" data-iid="${it.id}" style="display:none"></label>
        <label class="btn sm" style="cursor:pointer">📷 Фото с разных сторон (${(it.refs || []).length}/8)<input type="file" accept="image/*" multiple class="i-refs" data-iid="${it.id}" style="display:none"></label></div>
      ${(it.refs || []).length ? `<div class="refstrip">${it.refs.map(r => `<div class="ref"><img src="/itemrefs/${it.id}/${r}?v=${Date.now()}">
        <b data-rmain="${it.id}/${r}" title="Сделать главным фото">★</b><b data-rdel="${it.id}/${r}" title="Удалить фото">×</b></div>`).join("")}</div>` : ""}
      </div></div></details>`).join("")}</div>` : `<p class="muted">Предметов пока нет.</p>`)
    + `<details class="cnew" ${list.length ? "" : "open"}><summary><b>＋ Новый предмет</b></summary>` + form() + `</details>`;
  const bind = (root) => {
    const iid = root.dataset.iid;
    const val = cls => root.querySelector(cls)?.value ?? "";
    const body = () => ({ name: val(".i-name"), kind: val(".i-kind"), description_ru: val(".i-desc"), extra_ru: val(".i-extra"), ...(iid ? { appearance: val(".i-app") } : {}) });
    root.querySelector(".i-save").onclick = async e => {
      e.target.disabled = true;
      const files = [...(root.querySelector(".i-newfile")?.files || [])];
      try {
        let it = await api(`/api/items${iid ? "/" + iid : ""}`, { json: { ...body(), later: !iid && files.length > 0 } });
        if (!iid && files.length) {
          for (const [i, f] of files.slice(0, 9).entries())
            await api(`/api/items/${it.id}/${i ? "refs" : "upload"}`, { method: "POST", body: f });
          toast("Фото загружены, описываю предмет по фото…");
          it = await api(`/api/items/${it.id}`, { json: { ...body(), describe: true } });
        }
        draftClear(); if (it.warning) toast(it.warning, true); else toast("Предмет сохранён");
      } catch (err) { toast(err.message, true); }
      renderItems();
    };
    if (!iid) return;
    root.querySelector(".i-desc-btn").onclick = async e => {
      e.target.disabled = true;
      toast("Смотрю на фото и описываю предмет…");
      const { appearance, ...rest } = body();
      await api(`/api/items/${iid}`, { json: { ...rest, describe: true } })
        .then(it => it.warning ? toast(it.warning, true) : toast("Описание обновлено по фото")).catch(err => toast(err.message, true));
      renderItems();
    };
    root.querySelector(".i-del").onclick = async () => {
      if (!confirm("Удалить предмет?")) return;
      await api(`/api/items/${iid}`, { method: "DELETE" }); renderItems();
    };
  };
  box.querySelectorAll(".cform").forEach(bind);
  box.querySelectorAll(".i-qfile").forEach(inp => inp.onchange = async () => {
    const f = inp.files[0]; if (!f) return;
    await api(`/api/items/${inp.dataset.iid}/upload`, { method: "POST", body: f }).then(() => toast("Фото загружено")).catch(err => toast(err.message, true));
    renderItems();
  });
  box.querySelectorAll(".i-refs").forEach(inp => inp.onchange = async () => {
    const files = [...inp.files]; if (!files.length) return;
    toast(`Загружаю фото: ${files.length}…`);
    for (const f of files) {
      const ok = await api(`/api/items/${inp.dataset.iid}/refs`, { method: "POST", body: f }).then(() => true).catch(err => { toast(err.message, true); return false; });
      if (!ok) break;
    }
    toast("Фото добавлены. Нажмите «Изменить» → «Описать по фото», чтобы описание учло новые фото.");
    renderItems();
  });
  box.querySelectorAll("[data-rdel]").forEach(x => x.onclick = async () => {
    if (!confirm("Удалить это фото?")) return;
    await api(`/api/items/${x.dataset.rdel.replace("/", "/refs/")}`, { method: "DELETE" }); renderItems();
  });
  box.querySelectorAll("[data-rmain]").forEach(x => x.onclick = async () => {
    await api(`/api/items/${x.dataset.rmain.replace("/", "/refs/")}/main`, { method: "POST" }).then(() => toast("Главное фото заменено")).catch(err => toast(err.message, true));
    renderItems();
  });
  box.querySelectorAll(".i-edit").forEach(b => b.onclick = () => {
    const it = list.find(x => x.id === b.dataset.iid);
    b.closest(".citem").outerHTML = `<div class="citem">${itemIcon(it, 72)}<div class="grow">${form(it)}</div></div>`;
    bind(box.querySelector(`.cform[data-iid="${it.id}"]`));
  });
}

async function viewItems() {
  main.innerHTML = `<h1>Предметы</h1>
  <p class="muted">Ваша библиотека товаров и вещей, которые появляются в кадре: продукт, который вы рекламируете, фирменная кружка ведущего, машина героя. Загрузите фото предмета (лучше несколько, с разных сторон и с логотипом крупно), программа сама составит по ним точное описание. При запуске ролика нажмите на нужные предметы: сценарий найдёт им место в истории, а на картинках они будут как на ваших фото (через fal.ai, ~$0.04 за такую картинку). В проекте можно отметить, какие предметы выбираются сами.</p>
  <div class="card" id="items">Загружаю…</div>`;
  await renderItems();
}

const AUD = { ru: "🇷🇺 Для русской аудитории", en: "🇺🇸 Для английской аудитории", de: "🇩🇪 Для немецкой аудитории", es: "🇪🇸 Для испанской аудитории", fr: "🇫🇷 Для французской аудитории", both: "🌍 Не определено (можно пометить в Настройках)" };
// The project's niche is still a template text (e.g. the history default) that has nothing to do with the project.
const nicheIsLeftover = p => { const n = x => (x || "").split(/\s+/).join(" ").trim().toLowerCase(), d = META.default_niches || {};
  return !!p && !!n(p.niche) && Object.values(d).some(v => n(v) === n(p.niche)) && n(d[p.preset]) !== n(p.niche); };
const LEFTOVER_NICHE = `<div class="banner bad small">⚠️ Описание ниши здесь стандартное, оно осталось от шаблона про историю, а не про ваш канал. Из-за него сценарист придумывает исторические темы. Сотрите его и опишите свою нишу своими словами, или сохраните в хранилище разборы и нажмите «✨ Обновить правила и описание ниши»: продюсер напишет описание по ним.</div>`;
const LANG_RU = { ru: "русский", en: "английский", de: "немецкий", es: "испанский", fr: "французский" };
const LANG_IN = { ru: "на русском", en: "на английском", de: "на немецком", es: "на испанском", fr: "на французском" };
const LANG_FLAG = { ru: "🇷🇺", en: "🇺🇸", de: "🇩🇪", es: "🇪🇸", fr: "🇫🇷" };
const LIB_LANGS = { ru: "Русские", en: "Английские", de: "Немецкие", es: "Испанские", fr: "Французские" };
let VOICES = null;
async function loadVoices(force) { if (!VOICES || force) VOICES = await api("/api/voices"); return VOICES; }
const KIND = { male: "👨 Мужские", female: "👩 Женские", child: "🧒 Детские", other: "🎙️ Другие" };
const voiceLabel = v => `${esc(v.name)} — ${v.flag || ""} ${esc(v.country || "")}${v.description ? ", " + esc(v.description) : ""}`;
function voiceOptions(vs, cur, lang) {
  const all = ["ru", "en", "de", "es", "fr"];
  const order = AUD[lang] && lang !== "both" ? [lang, "both", ...all.filter(a => a !== lang)] : [...all, "both"];
  let html = order.map(a => Object.keys(KIND).map(k => {
    const g = vs.filter(v => v.audience === a && (v.kind || "other") === k);
    return g.length ? `<optgroup label="${AUD[a].split(" (")[0]} · ${KIND[k]}">${g.map(v => `<option value="${v.voice_id}" data-name="${esc(v.name)}" ${v.voice_id === cur ? "selected" : ""}>${voiceLabel(v)}</option>`).join("")}</optgroup>` : "";
  }).join("")).join("");
  if (cur && !vs.find(v => v.voice_id === cur)) html = `<option value="${esc(cur)}" selected>Свой голос (${esc(cur.slice(0, 6))}…)</option>` + html;
  return html;
}

// Voices of one language from the public ElevenLabs library. onPick(voice_id, name) gets a voice already added to the account.
function openVoiceLibrary(onPick, lang) {
  lang = LIB_LANGS[lang] ? lang : "ru";
  const wrap = document.createElement("div");
  wrap.className = "vlib"; wrap.dataset.nodraft = 1;
  wrap.innerHTML = `<div class="box"><button class="x" title="Закрыть">×</button>
    <h2>Голоса из библиотеки ElevenLabs</h2>
    <p class="muted small">Выберите язык: в списке будут носители этого языка, поэтому ударения и интонации у них естественные. Нажмите ▶, чтобы послушать. Кнопка «Выбрать» добавит голос в ваш аккаунт ElevenLabs и поставит его. После этого не забудьте нажать «Сохранить».</p>
    <div class="row" style="gap:8px;margin:10px 0">
      <select data-f="language" style="width:auto">${Object.entries(LIB_LANGS).map(([k, n]) => `<option value="${k}" ${k === lang ? "selected" : ""}>${LANG_FLAG[k]} ${n}</option>`).join("")}</select>
      <select data-f="gender" style="width:auto"><option value="">Любой пол</option><option value="male">👨 Мужские</option><option value="female">👩 Женские</option></select>
      <select data-f="use_case" style="width:auto"><option value="">Для чего угодно</option><option value="narrative_story">Рассказы и истории</option><option value="informative_educational">Обучающие, научпоп</option><option value="social_media">Соцсети, шортсы</option><option value="entertainment_tv">ТВ, развлечения</option><option value="characters_animation">Персонажи, мультфильмы</option><option value="advertisement">Реклама</option></select>
      <input data-f="search" placeholder="поиск: низкий, спокойный, диктор…" style="width:240px">
      <button class="sm" data-go>Найти</button></div>
    <div data-list>Загружаю…</div><audio data-audio></audio>
    <div class="row" style="margin-top:10px"><button class="sm" data-more style="display:none">Показать ещё</button></div></div>`;
  document.body.appendChild(wrap);
  const close = () => { wrap.querySelector("[data-audio]").pause(); wrap.remove(); };
  wrap.querySelector(".x").onclick = close;
  wrap.addEventListener("click", e => { if (e.target === wrap) close(); });
  const list = wrap.querySelector("[data-list]"), more = wrap.querySelector("[data-more]");
  let page = 0, items = [];
  const f = k => wrap.querySelector(`[data-f="${k}"]`).value;
  const draw = () => {
    list.innerHTML = items.length ? items.map((v, i) => `<div class="vrow">
      <button class="sm" data-play="${i}" ${v.preview_url ? "" : "disabled"}>▶</button>
      <div class="grow"><b>${esc(v.name)}</b> <span class="muted small">${KIND[v.kind || "other"].split(" ")[0]} ${esc(v.description)}${v.users ? ` · выбрали ${v.users.toLocaleString("ru")} чел.` : ""}</span>
        ${v.about ? `<div class="muted small">${esc(v.about)}</div>` : ""}</div>
      <button class="sm ${v.added ? "" : "primary"}" data-pick="${i}">${v.added ? "✓ Уже у вас · выбрать" : "Выбрать"}</button></div>`).join("")
      : `<p class="muted">Ничего не нашлось. Попробуйте убрать фильтры.</p>`;
    list.querySelectorAll("[data-play]").forEach(b => b.onclick = () => { const a = wrap.querySelector("[data-audio]"); a.src = items[+b.dataset.play].preview_url; a.play(); });
    list.querySelectorAll("[data-pick]").forEach(b => b.onclick = async () => {
      const v = items[+b.dataset.pick]; b.disabled = true; b.textContent = "Добавляю…";
      try {
        const r = await api("/api/voices/library/add", { json: { owner: v.owner, voice_id: v.voice_id, name: v.name, language: f("language") } });
        await loadVoices(true).catch(() => null);
        onPick(r.voice_id, v.name); close(); toast(`Голос «${v.name}» выбран. Нажмите «Сохранить».`);
      } catch (e) { toast(e.message, true); b.disabled = false; b.textContent = "Выбрать"; }
    });
  };
  const load = async (reset) => {
    if (reset) { page = 0; items = []; list.innerHTML = "Загружаю…"; }
    try {
      const q = new URLSearchParams({ language: f("language"), gender: f("gender"), use_case: f("use_case"), search: f("search"), page });
      const d = await api(`/api/voices/library?${q}`);
      items = items.concat(d.voices); draw(); more.style.display = d.has_more ? "" : "none";
    } catch (e) { list.innerHTML = `<div class="banner bad">${esc(e.message)}</div>`; }
  };
  wrap.querySelector("[data-go]").onclick = () => load(true);
  wrap.querySelectorAll("select[data-f]").forEach(s => s.onchange = () => load(true));
  wrap.querySelector('[data-f="search"]').onkeydown = e => { if (e.key === "Enter") load(true); };
  more.onclick = () => { page++; load(false); };
  load(true);
}
// A button next to a voice list that opens the library with native speakers of any language (Spanish, German…).
function addLibButton(sel, lang) {
  const b = document.createElement("button");
  b.type = "button"; b.className = "sm"; b.textContent = "🌍 Голоса других языков";
  b.title = "Испанские, немецкие, английские, французские и русские голоса из библиотеки ElevenLabs";
  b.onclick = () => openVoiceLibrary((vid, name) => pickIntoSelect(sel, vid, name), lang);
  sel.insertAdjacentElement("afterend", b);
}

function pickIntoSelect(sel, vid, name) {
  const opt = sel.querySelector(`option[value="${CSS.escape(vid)}"]`);
  if (!opt) sel.insertAdjacentHTML("beforeend", `<option value="${esc(vid)}" data-name="${esc(name)}">${esc(name)}</option>`);
  else if (!opt.dataset.name) { opt.dataset.name = name; opt.textContent = name; }
  sel.value = vid; sel.dispatchEvent(new Event("change", { bubbles: true }));
}

const ICONS = ["🎬", "🏛️", "🕯️", "🔍", "⚽", "🚀", "🏆", "🐉", "📜", "👁️", "💰", "🧠", "🌍", "⚔️", "🎵", "🍳", "🐾", "💡"];

async function viewProjects(id) {
  if (id) return viewProject(id);
  const projs = (await api("/api/projects")).filter(p => p.platform !== "instagram");
  const niches = await api("/api/niches").catch(() => META.presets);
  main.innerHTML = `<h1>Проекты и ниши</h1>
  <p class="muted small">Ниши для Инстаграма живут отдельно, в разделе <a href="#/insta">«Инстаграм»</a>.</p>
  <p class="muted">Проект — это ниша со своими готовыми настройками: язык, тема канала, стиль картинок, голос, анимация, субтитры. Ролики каждого проекта хранятся отдельно. При запуске ролика проект выбирается одной кнопкой.</p>
  ${projs.length ? `<h2>Мои проекты</h2><div class="pgrid sm">${projs.map(p => `<a class="pcard" href="#/projects/${p.id}">
      <div class="pic">${esc(p.icon)}</div><div><b>${esc(p.name)}</b>
      <div class="muted small">${esc(LANG_RU[p.language] || p.language)} · ${p.count} ${p.count % 10 === 1 && p.count % 100 !== 11 ? "ролик" : [2, 3, 4].includes(p.count % 10) && ![12, 13, 14].includes(p.count % 100) ? "ролика" : "роликов"}</div></div>
      <b class="pdel" data-del="${p.id}" data-count="${p.count}" title="Удалить проект">×</b></a>`).join("")}</div>` : ""}
  <div class="card"><h2>Новый проект из ниши</h2>
    <p class="muted small">Выберите нишу: все настройки подставятся сами, потом их можно поменять. Если проект с этой нишей уже есть, откроется он, а не новая копия. Ненужную нишу уберите крестиком в углу: готовые ниши скрываются (их можно вернуть внизу), ваши удаляются. Проекты при этом не трогаются. Свой проект можно сделать нишей кнопкой «⭐ Сохранить как свою нишу» в проекте: тогда он появится здесь с пометкой «моя ниша», и из него можно быстро делать новые проекты.</p>
    <div class="pgrid sm">${Object.entries(niches).filter(([k, p]) => !p.hidden).sort((a, b) => (b[1].mine ? 1 : 0) - (a[1].mine ? 1 : 0)).map(([k, p]) => `<button class="pcard" data-preset="${k}"><div class="pic">${esc(p.icon)}</div><div><b>${esc(p.name)}</b><div class="muted small">${p.mine ? "⭐ моя ниша · " : ""}${LANG_IN[p.language] || "на английском"}${p.project || projs.some(x => x.preset === k) ? " · ✓ уже есть" : ""}</div></div><b class="pdel" data-ndel="${k}" data-mine="${p.mine ? 1 : ""}" title="Убрать из списка ниш">×</b></button>`).join("")}
      <button class="pcard" data-preset="custom"><div class="pic">＋</div><div><b>Свой проект</b><div class="muted small">с нуля</div></div></button></div>
    ${Object.values(niches).some(p => p.hidden) ? `<details style="margin-top:14px"><summary class="muted">Скрытые ниши (${Object.values(niches).filter(p => p.hidden).length})</summary>
      <div class="row" style="gap:6px;margin-top:8px">${Object.entries(niches).filter(([k, p]) => p.hidden).map(([k, p]) => `<button class="sm" data-nshow="${k}" title="Вернуть в список">${esc(p.icon)} ${esc(p.name)} · вернуть</button>`).join("")}</div></details>` : ""}
  </div>`;
  main.querySelectorAll("[data-del]").forEach(x => x.onclick = async e => {
    e.preventDefault(); e.stopPropagation();
    const n = +x.dataset.count;
    if (!confirm(n ? `Удалить проект? Его ролики (${n}) останутся, они перейдут в «Без проекта».` : "Удалить проект?")) return;
    await api(`/api/projects/${x.dataset.del}`, { method: "DELETE" }).catch(err => toast(err.message, true));
    const tabs = getTabs().filter(t => t.hash !== `#/projects/${x.dataset.del}`); lsSet("ay_tabs", JSON.stringify(tabs));
    viewProjects(); renderTabs();
  });
  main.querySelectorAll("[data-ndel]").forEach(x => x.onclick = async e => {
    e.preventDefault(); e.stopPropagation();
    if (x.dataset.mine) {
      if (!confirm("Удалить вашу нишу из списка? Проекты, созданные из неё, останутся.")) return;
      await api(`/api/niches/${x.dataset.ndel}`, { method: "DELETE" });
    } else {
      await api(`/api/niches/${x.dataset.ndel}/hidden`, { json: { hidden: true } });
      toast("Ниша скрыта. Вернуть её можно внизу, в «Скрытые ниши».");
    }
    viewProjects();
  });
  main.querySelectorAll("[data-nshow]").forEach(x => x.onclick = async () => {
    await api(`/api/niches/${x.dataset.nshow}/hidden`, { json: { hidden: false } }); viewProjects();
  });
  main.querySelectorAll("[data-preset]").forEach(b => b.onclick = async () => {
    const n = niches[b.dataset.preset] || {};
    const have = projs.find(x => b.dataset.preset !== "custom" && (x.preset === b.dataset.preset || x.id === n.project));
    if (have) { toast(`Проект «${have.name}» уже есть, открываю его`); location.hash = `#/projects/${have.id}`; return; }
    const p = await api("/api/projects", { json: { preset: b.dataset.preset } }).catch(e => toast(e.message, true));
    if (p) { toast("Проект создан"); location.hash = `#/projects/${p.id}`; }
  });
}

async function viewProject(id) {
  const projs = await api("/api/projects");
  const p = projs.find(x => x.id === id);
  if (!p) { main.innerHTML = `<div class="banner bad">Проект не найден. <a href="#/projects">К списку проектов</a></div>`; return; }
  const yt = await api("/api/youtube").catch(() => ({ channels: [] }));
  const gs = await api("/api/settings").catch(() => ({}));
  const allChars = await api("/api/characters").catch(() => []);
  const allItems = await api("/api/items").catch(() => []);
  const opt = (v, cur) => String(v) === String(cur) ? "selected" : "";
  const sel = (key, options) => `<select data-q="${key}">${options.map(([v, n]) => `<option value="${esc(v)}" ${opt(v, p[key])}>${esc(n)}</option>`).join("")}</select>`;
  if (p.platform === "instagram") navActive("insta");
  main.innerHTML = `<a href="${p.platform === "instagram" ? "#/insta" : "#/projects"}" class="small">← ${p.platform === "instagram" ? "Инстаграм" : "Все проекты"}</a>
  <div class="row"><h1 class="grow">${esc(p.icon)} ${esc(p.name)}</h1>
    <a class="btn" href="#/jobs" id="pj-jobs">Ролики проекта (${p.count})</a>
    <a class="btn primary" href="#/new" id="pj-new">＋ Новый ролик в проекте</a></div>
  <div class="card">
    <div class="grid2"><div>
      <label class="f">Название</label><input type="text" data-q="name" value="${esc(p.name)}">
    </div><div>
      <label class="f">Значок</label><input type="text" data-q="icon" value="${esc(p.icon)}" style="max-width:90px">
      <div class="row" style="gap:4px;margin-top:6px">${ICONS.map(i => `<button class="sm" data-icon="${i}">${i}</button>`).join("")}</div>
    </div></div>
    <label class="f">Язык сценария, озвучки и субтитров <span class="hint">Для русского языка выберите ниже русскоязычный голос (в ElevenLabs есть фильтр по языку).</span></label>
    ${sel("language", Object.entries(META.languages))}
    <label class="f">Формат роликов</label>
    ${sel("format", [["long", "Видео + шортс"], ["short", "Только шортс (вертикальные до 60 секунд)"]])}
    <label class="f">Ниша и тематика канала <span class="hint">Можно по-русски. Чем конкретнее, тем лучше темы.</span></label>
    ${nicheIsLeftover(p) ? LEFTOVER_NICHE : ""}
    <textarea data-q="niche">${esc(p.niche)}</textarea>
    <label class="f">Стиль картинок <span class="hint">Пусто — как в общих настройках. По-английски.</span></label>
    <textarea data-q="image_style">${esc(p.image_style)}</textarea>
    <div class="row" style="margin-top:6px">${Object.entries(STYLE_PRESETS).map(([k, v]) => `<button class="sm" data-style="${k}" title="${esc(v.desc)}">${esc(v.name)}</button>`).join("")}</div>
    <div class="grid2"><div>
      <label class="f">Голос <span class="hint">Голоса разделены по языку аудитории: русский, английский, немецкий, испанский, французский. Сверху — под язык проекта.</span></label>
      <select data-q="voice_id" id="pj-voice"><option value="">Как в общих настройках (${esc(gs.elevenlabs_voice_name || "не выбран")})</option>${p.voice_id ? `<option value="${esc(p.voice_id)}" selected>${esc(p.voice_name || p.voice_id)}</option>` : ""}</select>
      <div class="row" style="margin-top:6px"><button class="sm" id="pj-voice-prev">▶ Образец</button><button class="sm primary" id="pj-voice-lib">🌍 Подобрать голос под язык проекта</button><audio id="pj-voice-audio"></audio></div>
      <input type="text" id="pj-voice-id" placeholder="…или вставьте ID голоса из ElevenLabs" style="margin-top:6px">
    </div><div>
      <label class="f">Канал YouTube по умолчанию</label>
      ${sel("channel_id", [["", "Не выбран"], ...yt.channels.map(c => [c.id, c.title])])}
    </div></div>
    <label class="f">Как звучат персонажи <span class="hint">Работает для персонажей, у которых в разделе «Персонажи» выбран свой голос.</span></label>
    ${sel("voice_mode", [["mixed", "Рассказчик + реплики героев их голосами"], ["dialogue", "Мультик: в основном диалоги героев"], ["host", "Герой-ведущий: весь ролик рассказывает главный герой своим голосом"], ["narrator", "Только рассказчик (герои не говорят сами)"]])}
    <h3 id="pj-voice-h">Озвучка проекта</h3>
    <p class="muted small">Пустые поля берутся из общих настроек. Для русского языка нажмите «Настройки для русского», для шортсов — «Под шортс» (бодрее и чуть быстрее).</p>
    <div class="grid2"><div>
      <label class="f">Модель озвучки</label>${sel("tts_model", [["", "Как в общих настройках"], ...META.tts_models.map(m => [m.id, m.name])])}
      <label class="f">Стабильность (0–1) <span class="hint">меньше — эмоциональнее</span></label><input type="number" step="0.05" min="0" max="1" data-q="voice_stability" value="${esc(p.voice_stability)}">
      <label class="f">Похожесть на оригинал (0–1)</label><input type="number" step="0.05" min="0" max="1" data-q="voice_similarity" value="${esc(p.voice_similarity)}">
    </div><div>
      <label class="f">Выразительность (0–1)</label><input type="number" step="0.05" min="0" max="1" data-q="voice_style" value="${esc(p.voice_style)}">
      <label class="f">Скорость (0.7–1.2)</label><input type="number" step="0.01" min="0.7" max="1.2" data-q="voice_speed" value="${esc(p.voice_speed)}">
      <label class="f">Темп речи (0.8–1.6) <span class="hint">ускоряет саму речь сверх 1.2, голос не становится выше. Паузы тоже короче. Картинки идут под голос, анимации не ускоряются. 1 — как есть, 1.15–1.3 — бодро</span></label><input type="number" step="0.05" min="0.8" max="1.6" data-q="voice_tempo" value="${esc(p.voice_tempo)}" placeholder="1">
      <div class="row" style="margin-top:14px"><button class="sm" id="pj-ru-voice">Настройки для русского</button><button class="sm" id="pj-short-voice">Под шортс</button><button class="sm" id="pj-test-voice">▶ Проверить голос проекта</button></div>
      <audio id="pj-audio" controls style="display:none;margin-top:8px;width:100%"></audio>
    </div></div>
    <div class="grid2"><div>
      <div class="pj-long"><label class="f">Длительность, минут</label><input type="number" data-q="duration_min" min="1" max="30" value="${esc(p.duration_min)}"></div>
      <div class="pj-short"><label class="f">Длина шортса, секунд <span class="hint">15–180. Лучше всего заходят 30–60</span></label><input type="number" data-q="short_seconds" min="15" max="180" step="5" value="${esc(p.short_seconds || 50)}"></div>
      <label class="f">Анимация сцен <span class="hint">платно, считается за каждую оживлённую сцену</span></label>${sel("anim_mode", animModes())}
      <div id="pj-anim-n"><label class="f">Сколько сцен оживлять <span class="hint">Конкретные сцены можно выбрать на странице ролика</span></label><input type="number" data-q="anim_count" min="1" max="60" value="${esc(p.anim_count || 3)}"></div>
      <div id="pj-anim-est" class="muted small" style="margin-top:4px"></div>
      <label class="f">Музыка по умолчанию <span class="hint">В «Новом ролике» можно поменять для каждого ролика</span></label>${sel("music_mode", Object.entries(META.music_modes))}
      <label class="f">Стиль музыки <span class="hint">своими словами, можно по-русски. Его слушаются и подбор из раздела «Музыка», и сочинение новой. Пусто — стиль под каждый сценарий</span></label><input type="text" data-q="music_style" value="${esc(p.music_style || "")}" placeholder="например: тихий тревожный эмбиент, без барабанов">
      <label class="check"><input type="checkbox" data-q="music_smart" ${p.music_smart !== false ? "checked" : ""}> Музыка по сценарию <span class="muted small">(в длинных роликах: нейросеть делит ролик на части по настроению, под каждую ставит трек из «Музыки» нужной энергии, с плавными переходами и паузами перед поворотами; бесплатно)</span></label>
      <label class="f">Эффекты</label>${sel("fx_mode", Object.entries(META.fx_modes))}
      <label class="f">Призыв на шортсах <span class="hint">анимированные кнопки «Подписаться» и «Нравится» в стиле YouTube во второй половине каждого шортса</span></label>${sel("cta_short", Object.entries(META.cta_modes))}
      <label class="f">Язык кнопок призыва</label>${sel("cta_lang", Object.entries(META.cta_langs))}
    </div><div>
      <label class="check pj-long" style="margin-top:38px"><input type="checkbox" data-q="make_short" ${p.make_short ? "checked" : ""}> Делать шортс</label>
      <label class="check pj-long"><input type="checkbox" data-q="anim_short" ${p.anim_short ? "checked" : ""}> Оживлять шортс</label>
      <label class="check"><input type="checkbox" data-q="anim_pause" ${p.anim_pause ? "checked" : ""}> Пауза перед анимацией: выбирать сцены самому</label>
      <label class="check"><input type="checkbox" data-q="images_pause" ${p.images_pause ? "checked" : ""}> Свои картинки: пауза перед рисованием <span class="muted small">(загружаете картинки из другого сервиса, программа озвучивает и монтирует по сценарию)</span></label>
      <label class="check pj-long"><input type="checkbox" data-q="subs_video" ${p.subs_video ? "checked" : ""}> Субтитры на длинном видео</label>
      <label class="check"><input type="checkbox" data-q="subs_short" ${p.subs_short ? "checked" : ""}> <span id="pj-subs-l">Субтитры на шортсе</span></label>
      <label class="check"><input type="checkbox" data-q="subs_smart" ${p.subs_smart !== false ? "checked" : ""}> Субтитры в свободном месте кадра <span class="muted small">(если внизу кадра лицо, надпись или много деталей, строка переносится в спокойное место кадра)</span></label>
      <label class="check"><input type="checkbox" data-q="graphics" ${p.graphics !== false ? "checked" : ""}> Анимации данных на видео <span class="muted small">(счётчики, деньги, проценты, таймеры, сравнения, галочки, стрелки, ключевые слова в момент, когда голос их называет; бесплатно, один короткий запрос к ИИ на ролик)</span></label>
      <label class="check"><input type="checkbox" data-q="made_for_kids" ${p.made_for_kids ? "checked" : ""}> Ролики для детей <span class="muted small">(сказочный добрый тон; на YouTube ставится отметка «для детей», по закону это обязательно для детского контента)</span></label>
      <label class="check"><input type="checkbox" data-q="same_place" ${p.same_place !== false ? "checked" : ""}> Каждое место выглядит одинаково во всех своих кадрах <span class="muted small">(сначала рисуется каждое место действия, и все сцены там рисуются по этому образцу; нужен ключ fal.ai; дороже: каждая сцена рисуется по образцу, ~$0.04 с Nano Banana или ~$0.02 с FLUX.2 Dev Edit (выбор в Настройках → Картинки) вместо ~$0.003 у Flux Schnell; в экономном режиме крупные планы и детали без персонажей рисуются без образца)</span></label>
      <label class="check" style="margin-left:24px"><input type="checkbox" data-q="keep_places" ${p.keep_places ? "checked" : ""}> Сохранять локации <span class="muted small">(для сериалов: место, нарисованное в одной серии, сохраняется в проекте, и следующие серии берут его готовым, бесплатно и в том же виде)</span></label>
      <div id="pj-places" class="muted small" style="margin-left:52px"></div>
      <label class="check"><input type="checkbox" data-q="fiction" ${p.fiction ? "checked" : ""}> Выдуманные истории <span class="muted small">(мультики, сказки, притчи: сюжеты придумываются, а не берутся из реальных событий)</span></label>
      <label class="check"><input type="checkbox" data-q="voice_off" ${p.voice_off ? "checked" : ""}> Без озвучки <span class="muted small">(ролик идёт только под музыку: без голоса и без текста на экране)</span></label>
      <label class="check"><input type="checkbox" data-q="ad_mode" ${p.ad_mode ? "checked" : ""}> Рекламный ролик товара <span class="muted small">(без людей: товар в каждом кадре, макро, наезды и облёт камеры; товар выбирается в «Предметах в ролике»)</span></label>
      <label class="check" style="margin-left:24px"><input type="checkbox" data-q="one_take" ${p.one_take ? "checked" : ""}> Одна сцена, как одним дублем <span class="muted small">(для рекламы: товар рисуется один раз, камера плавно едет по кадру: наезд, макро деталей, отъезд. Товар не искажается)</span></label>
      <label class="f" style="margin-left:24px">Облёт товара <span class="hint">Облёт делает Kling 2.5, около $0.35 за сцену. Если облёт не получится, сцена будет обычной камерой по кадру</span></label>
      <div style="margin-left:24px">${sel("take_orbit", [["one", "Одна сцена облёта (рекомендую)"], ["all", "Облёт в каждой сцене"], ["off", "Без облёта, бесплатно"]])}</div>
    </div></div>
    <div class="row" style="margin-top:16px"><button class="primary" id="pj-save">Сохранить проект</button><button id="pj-tpl" title="Проект появится в списке ниш, из него можно будет быстро создавать новые проекты с такими же настройками">⭐ Сохранить как свою нишу</button><span class="grow"></span><button class="danger" id="pj-del">Удалить проект</button></div>
  </div>
  <div class="card"><h2>Персонажи проекта</h2>
    <p class="muted small">Отметьте героев, которые будут выбраны сами при запуске ролика в этом проекте (при запуске их можно поменять). Сами персонажи хранятся в разделе <a href="#/characters">«Персонажи»</a> слева: там их добавляют, рисуют и загружают портреты.</p>
    ${allChars.length ? `<div class="row" id="pj-chars">${allChars.map(c => `<button class="cbtn ${(p.characters || []).includes(c.id) ? "on" : ""}" data-pchar="${c.id}" title="${esc(c.role)}">${charIcon(c, 48)}<span>${esc(c.name)}</span></button>`).join("")}</div>`
      : `<p class="muted">Персонажей пока нет. <a href="#/characters">Добавить персонажа</a></p>`}
  </div>
  <div class="card"><h2>Предметы проекта</h2>
    <p class="muted small">Отметьте товары и вещи, которые будут выбраны сами при запуске ролика в этом проекте (при запуске их можно поменять). Сами предметы с фото хранятся в разделе <a href="#/items">«Предметы»</a> слева.</p>
    ${allItems.length ? `<div class="row" id="pj-items">${allItems.map(it => `<button class="cbtn ${(p.items || []).includes(it.id) ? "on" : ""}" data-pitem="${it.id}" title="${esc(it.kind)}">${itemIcon(it, 48)}<span>${esc(it.name)}</span></button>`).join("")}</div>`
      : `<p class="muted">Предметов пока нет. <a href="#/items">Добавить предмет</a></p>`}
  </div>
  <div class="card" id="pj-golden"><h2>⭐ Копилка удачных сценариев</h2>
    <p class="muted small">Сценарии этого проекта, которые сработали. Перед каждым новым роликом проекта сценарист изучает последние 6 (отдельно для видео и для шортсов): какие темы, первые фразы, ритм и повороты здесь заходят. Добавляйте кнопкой «⭐ В копилку удачных» на странице ролика. Ниже программа сама подсказывает хиты по статистике YouTube.</p>
    <div id="pj-golden-list" class="muted small">Загружаю…</div>
  </div>
  <div class="card"><h2>🔎 Поиск на YouTube</h2>
    <p class="muted small">Название, описание и теги программа составляет сама под поиск: главная фраза темы в начале названия, описание по схеме: цепляющие первые 2 строки с ключевыми словами, SEO-блок из 3–5 предложений с синонимами темы, вопрос зрителям для комментариев, призыв подписаться на канал, реальные источники для исторических и научных тем, 5 хештегов и 10–15 тегов. Здесь можно добавить свои постоянные теги и фразы, которые нужны в каждом ролике проекта: через запятую. Они всегда попадут в теги, а подходящие и в описание.</p>
    <textarea data-q="seo_ru" rows="3" placeholder="Например: таксист, жизненно, юмор, горькая правда, бритва, мужской уход">${esc(p.seo_ru || "")}</textarea>
    <p class="muted small">Не забудьте нажать «Сохранить проект».</p>
  </div>
  <div class="card"><h2>🎯 Образцы удачных шортсов</h2>
    <p class="muted small">Вставьте сюда тексты шортсов, которые вам нравятся и набирают просмотры: что говорят в ролике, от первой фразы до последней. Можно описать своими словами, что происходит и в чём поворот. Каждый образец отделяйте пустой строкой или чертой. Сценарист шортсов изучит, как они цепляют в первую секунду, где поворот и как бьёт концовка, и будет писать на том же уровне. Сюжеты и фразы он не копирует. Для длинных роликов это поле не используется.</p>
    <textarea data-q="short_examples" rows="8" placeholder="Например:&#10;«Мой хозяин решил побриться тёркой для сыра…» (дальше весь текст ролика)&#10;———&#10;Второй образец…">${esc(p.short_examples || "")}</textarea>
    <p class="muted small">Не забудьте нажать «Сохранить проект».</p>
  </div>
  <div class="card"><h2>Сериал</h2>
    <p class="muted small">Включите, если ролики проекта — серии одной истории. Каждая серия получает номер, а после сценария программа сама записывает, что в ней произошло. Следующая серия читает библию сериала, план сезона и краткое содержание прошлых серий, поэтому продолжает сюжет, помнит, что пережили герои, и заканчивается крючком на следующую серию.</p>
    <label class="check"><input type="checkbox" data-q="series" ${p.series ? "checked" : ""}> Это сериал</label>
    <label class="f">Библия сериала <span class="hint">По-русски. О чём сериал, правила мира, герои и как они меняются, главный вопрос сезона, тон, фирменные фразы.</span></label>
    <textarea data-q="series_bible" rows="8">${esc(p.series_bible || "")}</textarea>
    <label class="f">План сезона <span class="hint">Одна строка — одна серия: «1. Название — что происходит». Если тема ролика не задана, серия берёт свою строку отсюда. Можно оставить пустым, тогда сюжет придумывается по ходу.</span></label>
    <textarea data-q="season_plan" rows="8">${esc(p.season_plan || "")}</textarea>
    <div class="row" style="margin-top:8px"><button id="pj-series-plan">✨ Придумать библию и план сезона</button>
      <span class="muted small">На чём основывается: ниша проекта, персонажи проекта (отмечены ниже), всё, что уже написано в библии, и вышедшие серии. Писать заранее ничего не обязательно. Но если у вас есть идея, впишите её в библию хоть одной строкой (например: «мошенник Лис обманывает весь город, пока его не находит прошлое»), и программа разовьёт именно её. Результат появится в полях выше, поправьте и нажмите «Сохранить проект».</span></div>
    <h3>Вышедшие серии</h3>
    <div id="episodes" class="muted small">Загружаю…</div>
  </div>
  <div class="card" id="pj-stats"><h2>📈 Что работает на канале</h2><p class="muted small">Загружаю…</p></div>
  </div>`;
  const animEst = async () => {
    const box = $("#pj-anim-est"); if (!box) return;
    const q = k => main.querySelector(`[data-q="${k}"]`);
    const fmtP = q("format").value, mode = q("anim_mode").value, animS = fmtP === "long" && q("anim_short").checked;
    $("#pj-anim-n").style.display = ["hook", "key"].includes(mode) ? "" : "none";
    if (mode === "off" && !animS) { box.textContent = "Анимация выключена: бесплатно, в видео будет плавное движение камеры по картинкам."; return; }
    try {
      const e = await api(`/api/estimate?minutes=${q("duration_min").value}&short=${q("make_short").checked}&anim_mode=${mode}&anim_short=${animS}&anim_count=${q("anim_count").value}&language=${q("language")?.value || "ru"}&format=${fmtP}&short_seconds=${q("short_seconds")?.value || 50}`);
      const m = META.video_models.find(x => x.id === (SETTINGS_CACHE || {}).video_model) || META.video_models.find(x => x.id === "kling25");
      box.innerHTML = `⚠️ Анимация в одном ролике обойдётся примерно в <b>$${e.anim_cost}</b> (~$${m.clip} за каждую оживлённую сцену).`;
    } catch (err) { }
  };
  ["anim_mode", "anim_short", "anim_count", "format", "duration_min", "short_seconds", "make_short"].forEach(k => main.querySelector(`[data-q="${k}"]`)?.addEventListener("change", animEst));
  animEst();
  const collect = () => {
    const out = {};
    main.querySelectorAll("[data-q]").forEach(i => out[i.dataset.q] = i.type === "checkbox" ? i.checked : i.value);
    const vs = $("#pj-voice"); out.voice_name = vs.value ? (vs.options[vs.selectedIndex].dataset.name || vs.options[vs.selectedIndex].text) : "";
    const manual = $("#pj-voice-id").value.trim();
    if (manual) { out.voice_id = manual; out.voice_name = `Свой голос (${manual.slice(0, 6)}…)`; }
    out.characters = [...main.querySelectorAll("[data-pchar].on")].map(b => b.dataset.pchar);
    out.items = [...main.querySelectorAll("[data-pitem].on")].map(b => b.dataset.pitem);
    return out;
  };
  main.querySelectorAll("[data-pchar]").forEach(b => b.onclick = async () => {
    b.classList.toggle("on");
    await api(`/api/projects/${id}`, { json: { characters: [...main.querySelectorAll("[data-pchar].on")].map(x => x.dataset.pchar) } })
      .then(() => toast("Персонажи проекта сохранены")).catch(e => toast(e.message, true));
  });
  main.querySelectorAll("[data-pitem]").forEach(b => b.onclick = async () => {
    b.classList.toggle("on");
    await api(`/api/projects/${id}`, { json: { items: [...main.querySelectorAll("[data-pitem].on")].map(x => x.dataset.pitem) } })
      .then(() => toast("Предметы проекта сохранены")).catch(e => toast(e.message, true));
  });
  const loadGolden = async () => {
    const box = $("#pj-golden-list"); if (!box) return;
    try {
      const g = await api(`/api/projects/${id}/golden`);
      const kindRu = k => k === "short" ? "шортс" : "видео";
      box.className = "";
      box.innerHTML = (g.items.length ? `<table>${g.items.slice().reverse().map(x => `<tr><td>${x.kind === "short" ? "📱" : "🎬"}</td><td><b>${esc(x.title_ru || x.title)}</b>${x.title_ru ? `<div class="en">${esc(x.title)}</div>` : ""}${x.note_ru ? `<div class="small">💬 ${esc(x.note_ru)}</div>` : ""}<details><summary class="muted small">Текст</summary><pre class="text">${esc(x.text)}</pre></details></td><td class="small muted" style="white-space:nowrap">${kindRu(x.kind)}${x.views != null ? `<br>${x.views.toLocaleString("ru")} просм.` : ""}<br>${new Date(x.added * 1000).toLocaleDateString("ru")}</td><td><a href="#/job/${x.job}" class="small">ролик</a> <button class="sm danger" data-gdel="${x.id}">×</button></td></tr>`).join("")}</table>`
        : `<p class="muted">Пока пусто. Откройте удачный ролик этого проекта и нажмите «⭐ В копилку удачных».</p>`)
        + (g.suggest.length ? `<h3>Хиты по статистике, которых нет в копилке</h3><table>${g.suggest.map(x => `<tr><td>${esc(x.title)}</td><td class="small">${x.views.toLocaleString("ru")} просм. (обычно ${x.median.toLocaleString("ru")})${x.avg_view_pct ? `, досматривают ${x.avg_view_pct}%` : ""}</td><td><button class="sm" data-gadd="${x.job}:${x.kind}">⭐ Добавить</button></td></tr>`).join("")}</table>` : "");
      box.querySelectorAll("[data-gdel]").forEach(b => b.onclick = async () => { if (!confirm("Убрать из копилки?")) return; await api(`/api/projects/${id}/golden/${b.dataset.gdel}`, { method: "DELETE" }); loadGolden(); });
      box.querySelectorAll("[data-gadd]").forEach(b => b.onclick = async () => { const [jid, kind] = b.dataset.gadd.split(":"); await api(`/api/jobs/${jid}/golden`, { json: { kind, note: "хит по статистике" } }).catch(e => toast(e.message, true)); loadGolden(); });
    } catch (e) { box.textContent = e.message; }
  };
  loadGolden();
  const loadPlaces = async () => {
    const box = $("#pj-places"); if (!box) return;
    try {
      const r = await api(`/api/projects/${id}/places`);
      box.innerHTML = r.items.length ? `Сохранено мест: ${r.items.length} (${r.items.map(x => esc(x.name)).join(", ")}) <button class="sm" id="pj-places-clear">Забыть сохранённые места</button>` : "";
      const b = $("#pj-places-clear");
      if (b) b.onclick = async () => { if (!confirm("Забыть все сохранённые места проекта? Следующие серии нарисуют их заново.")) return; await api(`/api/projects/${id}/places`, { method: "DELETE" }); loadPlaces(); };
    } catch (e) { box.textContent = ""; }
  };
  loadPlaces();
  const langSel = main.querySelector('[data-q="language"]'), fmtSel = main.querySelector('[data-q="format"]');
  const fillVoices = async () => {
    const vsel = $("#pj-voice"); const cur = vsel.value;
    try { const vs = await loadVoices(); vsel.innerHTML = vsel.options[0].outerHTML + voiceOptions(vs, cur, langSel.value); vsel.value = cur; }
    catch (e) { vsel.title = "Список голосов не загрузился: " + e.message; }
  };
  fillVoices(); langSel.addEventListener("change", fillVoices);
  $("#pj-voice-lib").onclick = () => openVoiceLibrary((vid, name) => { $("#pj-voice-id").value = ""; pickIntoSelect($("#pj-voice"), vid, name); }, langSel.value);
  $("#pj-voice-prev").onclick = () => {
    const v = (VOICES || []).find(x => x.voice_id === ($("#pj-voice").value || gs.elevenlabs_voice_id));
    if (!v || !v.preview_url) return toast("Для этого голоса нет образца. Нажмите «Проверить голос проекта».", true);
    const a = $("#pj-voice-audio"); a.src = v.preview_url; a.play();
  };
  const applyFmt = () => {
    const short = fmtSel.value === "short";
    main.querySelectorAll(".pj-long").forEach(el => el.style.display = short ? "none" : "");
    main.querySelectorAll(".pj-short").forEach(el => el.style.display = short ? "" : "none");
    $("#pj-subs-l").textContent = short ? "Субтитры" : "Субтитры на шортсе";
    $("#pj-voice-h").textContent = short ? "Озвучка проекта (шортсы)" : "Озвучка проекта";
  };
  fmtSel.addEventListener("change", applyFmt); applyFmt();
  $("#pj-short-voice").onclick = () => {
    const set = (k, v) => { main.querySelector(`[data-q="${k}"]`).value = v; };
    set("voice_stability", 0.35); set("voice_similarity", 0.8); set("voice_style", 0.35); set("voice_speed", 1.08);
    toast("Подставлено: бодрее и чуть быстрее, как принято в шортсах. Нажмите «Сохранить проект».");
  };
  main.querySelectorAll("[data-icon]").forEach(b => b.onclick = () => { main.querySelector('[data-q="icon"]').value = b.dataset.icon; });
  main.querySelectorAll("[data-style]").forEach(b => b.onclick = () => { main.querySelector('[data-q="image_style"]').value = STYLE_PRESETS[b.dataset.style].text; });
  $("#pj-save").onclick = async () => {
    await api(`/api/projects/${id}`, { json: collect() }).then(() => { draftClear(); draftBaseReset(); toast("Проект сохранён"); }).catch(e => toast(e.message, true));
  };
  $("#pj-tpl").onclick = async () => {
    try {
      await api(`/api/projects/${id}`, { json: collect() }); draftClear(); draftBaseReset();
      await api(`/api/projects/${id}/template`, { method: "POST" });
      toast("Готово: проект появился в «Проекты и ниши» → «Новый проект из ниши» с пометкой «моя ниша»");
    } catch (e) { toast(e.message, true); }
  };
  $("#pj-del").onclick = async () => {
    if (!confirm("Удалить проект? Его ролики останутся, они перейдут в «Без проекта».")) return;
    await api(`/api/projects/${id}`, { method: "DELETE" });
    location.hash = "#/projects";
  };
  $("#pj-ru-voice").onclick = () => {
    const set = (k, v) => { main.querySelector(`[data-q="${k}"]`).value = v; };
    set("tts_model", "eleven_multilingual_v2"); set("voice_stability", 0.45); set("voice_similarity", 0.8); set("voice_style", 0.15); set("voice_speed", 1.0);
    toast("Подставлено. Не забудьте выбрать русскоязычный голос и сохранить проект.");
  };
  $("#pj-test-voice").onclick = async () => {
    try {
      await api(`/api/projects/${id}`, { json: collect() });
      toast("Озвучиваю пробную фразу…");
      const b = await api("/api/test/tts", { json: { project_id: id } });
      const a = $("#pj-audio"); a.style.display = ""; a.src = URL.createObjectURL(b); a.play();
    } catch (e) { toast(e.message, true); }
  };
  $("#pj-jobs").onclick = () => lsSet("ay_jobs_filter", id);
  $("#pj-series-plan").onclick = async () => {
    const b = $("#pj-series-plan"); b.disabled = true; b.textContent = "Придумываю…";
    try {
      const c = collect();
      const r = await api(`/api/projects/${id}/series/plan`, { json: { niche: c.niche, series_bible: c.series_bible, characters: c.characters, count: 10 } });
      main.querySelector('[data-q="series_bible"]').value = r.series_bible;
      main.querySelector('[data-q="season_plan"]').value = r.season_plan;
      main.querySelector('[data-q="series"]').checked = true;
      toast("Готово. Проверьте и нажмите «Сохранить проект».");
    } catch (e) { toast(e.message, true); }
    b.disabled = false; b.textContent = b.dataset.label || "✨ Придумать библию и план сезона";
  };
  renderEpisodes(id);
  renderStats(id);
  $("#pj-new").onclick = async e => {
    e.preventDefault();
    await api(`/api/projects/${id}`, { json: collect() }).catch(() => { });
    lsSet("ay_proj", id); location.hash = "#/new";
  };
}

async function renderStats(pid) {
  const box = $("#pj-stats"); if (!box) return;
  const r = await api(`/api/projects/${pid}/stats`).catch(() => null);
  if (!r) { box.innerHTML = `<h2>📈 Что работает на канале</h2><p class="muted">Не удалось загрузить статистику.</p>`; return; }
  const L = r.lessons || {}, rules = L.rules || [];
  const fmtN = n => (n || 0).toLocaleString("ru");
  let h = `<h2>📈 Что работает на канале</h2>
    <p class="muted small">Программа раз в 6 часов берёт с YouTube статистику опубликованных роликов этого проекта: просмотры и сколько процентов ролика досматривают. Когда наберётся ${r.ready.need} роликов старше ${r.min_age_days} дней, она сравнит лучшие и худшие и запишет правила, что работает. Сценарист учитывает их в каждом новом ролике проекта. Любое правило можно выключить или удалить.</p>`;
  if (!r.channels) h += `<div class="banner info small">Подключите канал в <a href="#/settings/youtube">Настройках → YouTube</a>. Ролики, загруженные вручную, тоже можно учитывать: вставьте их ссылку на странице ролика.</div>`;
  if (r.error) h += `<div class="banner warn small">${esc(r.error)}</div>`;
  h += `<div class="row" style="margin:8px 0"><button class="sm" id="st-refresh">↻ Обновить статистику</button>
    <button class="sm ${r.ready.ok ? "primary" : ""}" id="st-learn" ${r.ready.ok ? "" : "disabled"}>✨ Сделать выводы сейчас</button>
    <span class="muted small">${r.ready.ok ? `Роликов для анализа: ${r.ready.videos}` : `Роликов со статистикой: ${r.ready.videos} из ${r.ready.need}`}${r.last_run ? ` · обновлено ${new Date(r.last_run * 1000).toLocaleString("ru")}` : ""}</span></div>`;
  if (L.summary_ru) h += `<div class="banner ok small"><b>Вывод:</b> ${esc(L.summary_ru)}<br><span class="muted">Сделан ${new Date(L.learned_at * 1000).toLocaleString("ru")} по ${L.videos} роликам</span></div>`;
  if (rules.length) h += `<h3>Правила для сценариста</h3>` + rules.map(x => `<div class="citem" style="align-items:flex-start;${x.off ? "opacity:.5" : ""}">
      <div class="grow"><b>${esc(x.rule_ru)}</b> <span class="muted small">(${{ high: "уверенно", medium: "скорее да", low: "пока догадка" }[x.confidence] || ""})</span>
      <div class="muted small">${esc(x.evidence_ru || "")}</div></div>
      <button class="sm" data-roff="${x.id}" data-v="${x.off ? 0 : 1}">${x.off ? "Включить" : "Выключить"}</button>
      <button class="sm danger" data-rdel="${x.id}">×</button></div>`).join("");
  if (r.videos.length) h += `<h3>Опубликованные ролики</h3><table class="small"><tr><th>Ролик</th><th>Просмотры</th><th>Досматривают</th><th>Лайки</th><th>Дней</th></tr>
    ${r.videos.map(v => `<tr><td><a href="#/job/${v.job_id}">${esc(v.title || "без названия")}</a> <span class="muted">${v.kind === "shorts" ? "шортс" : "видео"}</span></td><td>${fmtN(v.views)}</td><td>${v.avg_view_pct != null ? v.avg_view_pct + "%" : "—"}</td><td>${fmtN(v.likes)}</td><td>${v.age_days}</td></tr>`).join("")}</table>`;
  box.innerHTML = h;
  $("#st-refresh").onclick = async e => {
    e.target.disabled = true; e.target.textContent = "Обновляю…";
    const res = await api("/api/stats/refresh", { method: "POST" }).catch(err => { toast(err.message, true); return null; });
    if (res) toast(res.errors && res.errors.length ? res.errors[0] : `Обновлено роликов: ${res.videos}`, !!(res.errors && res.errors.length));
    renderStats(pid);
  };
  $("#st-learn").onclick = async e => {
    e.target.disabled = true; e.target.textContent = "Анализирую…";
    await api(`/api/projects/${pid}/lessons`, { method: "POST" }).then(() => toast("Выводы готовы")).catch(err => toast(err.message, true));
    renderStats(pid);
  };
  box.querySelectorAll("[data-roff]").forEach(b => b.onclick = async () => { await api(`/api/projects/${pid}/lessons/${b.dataset.roff}`, { json: { off: b.dataset.v === "1" } }); renderStats(pid); });
  box.querySelectorAll("[data-rdel]").forEach(b => b.onclick = async () => { if (!confirm("Удалить это правило?")) return; await api(`/api/projects/${pid}/lessons/${b.dataset.rdel}`, { json: { delete: true } }); renderStats(pid); });
}

async function renderEpisodes(pid) {
  const box = $("#episodes"); if (!box) return;
  const r = await api(`/api/projects/${pid}/episodes`).catch(() => ({ episodes: [], next: 1 }));
  const planBtn = $("#pj-series-plan");
  if (planBtn && r.episodes.length) planBtn.dataset.label = planBtn.textContent = `✨ Придумать следующие 10 серий (с ${r.next}-й)`;
  box.innerHTML = (r.episodes.length ? r.episodes.map(e => `<div class="citem" style="align-items:flex-start">
      <div class="grow"><b>Серия ${e.num}. ${esc(e.title_ru || e.title)}</b>
        <div>${esc(e.summary_ru || e.summary || "")}</div>
        ${e.cliffhanger ? `<div class="muted small">Чем закончилась: ${esc(e.cliffhanger)}</div>` : ""}
        ${e.job_id ? `<a class="small" href="#/job/${e.job_id}">Открыть ролик</a>` : ""}</div>
      <button class="sm danger" data-ep="${e.num}" title="Следующие серии забудут её сюжет">Забыть</button></div>`).join("")
    : `<p>Пока ни одной. Сюжет серии запоминается сам, когда готов её сценарий.</p>`)
    + `<p class="muted small">Следующий ролик проекта станет серией ${r.next}.</p>`;
  box.querySelectorAll("[data-ep]").forEach(b => b.onclick = async () => {
    if (!confirm("Забыть эту серию? Следующие серии не будут знать, что в ней было.")) return;
    await api(`/api/projects/${pid}/episodes/${b.dataset.ep}`, { method: "DELETE" });
    renderEpisodes(pid);
  });
}

// ------------------------------------------------------------------ job page
const openStages = new Set();
let lastStagesKey = "";

// The big countdown while a video is assembled. The numbers tick every second between the page's refreshes.
const clock = sec => { sec = Math.max(0, Math.round(sec)); const h = Math.floor(sec / 3600), m = Math.floor(sec % 3600 / 60), s = sec % 60;
  return h ? `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}` : `${m}:${String(s).padStart(2, "0")}`; };
function etaCard(e, stage) {
  const now = Date.now();
  return `<div class="eta" data-eta-end="${now + e.remaining * 1000}" data-eta-start="${now - e.elapsed * 1000}">
    <div class="lbl">⏱ ${stage === "short_video" ? "До конца монтажа шортса" : "До конца монтажа ролика"} примерно</div>
    <div class="num" data-eta-num>${clock(e.remaining)}</div>
    <div class="sub">Прошло <span data-eta-el>${clock(e.elapsed)}</span> · готово ${Math.round(e.frac * 100)}%</div>
    <div class="track"><div style="width:${Math.round(e.frac * 100)}%"></div></div></div>`;
}
setInterval(() => document.querySelectorAll("[data-eta-end]").forEach(x => {
  const left = (+x.dataset.etaEnd - Date.now()) / 1000;
  x.querySelector("[data-eta-num]").textContent = left > 0 ? clock(left) : "почти готово…";
  x.querySelector("[data-eta-el]").textContent = clock((Date.now() - +x.dataset.etaStart) / 1000);
}), 1000);

async function viewJob(id) {
  lastStagesKey = "";
  main.innerHTML = `<div id="jhead"></div><div id="jstages"></div>
    <details class="stage" id="logbox"><summary><span class="ic">📜</span><span class="nm">Журнал работы</span></summary><div class="content"><pre class="log" id="jlog"></pre></div></details>`;
  const render = async () => {
    const d = await api(`/api/jobs/${id}`);
    renderHead(d);
    const key = JSON.stringify([d.stages, d.images, d.files, d.thumb, d.subs, d.anim, d.fx_mode, d.job.options.graphics, d.job.options.subs_smart, d.job.status, d.job.stage, d.job.error]);
    if (key !== lastStagesKey) { lastStagesKey = key; lastUpKey = ""; renderStages(d); }
    renderUploads(d);
    const log = $("#jlog"); const atBottom = log.scrollTop + log.clientHeight >= log.scrollHeight - 20;
    if (log.textContent !== d.log) { log.textContent = d.log; if (atBottom) log.scrollTop = log.scrollHeight; }
  };
  await render();
  timer = setInterval(() => render().catch(() => { }), 2500);
}

function renderHead(d) {
  const j = d.job, u = d.usage || {};
  const cost = (u.llm_cost || 0) + (u.image_cost || 0) + (u.anim_cost || 0) + (u.music_cost || 0);
  const act = [];
  if (["running", "queued"].includes(j.status)) act.push(`<button data-act="pause">⏸ Пауза</button>`);
  if (j.status === "paused") act.push(`<button class="primary" data-act="resume">▶ Продолжить</button>`);
  if (j.status === "error") act.push(`<button class="primary" data-act="retry">↻ Попробовать ещё раз</button>`);
  const ideaWait = j.status === "review" && j.options.idea_pause && !j.options.idea_picked;
  const animWait = d.anim && d.anim.waiting;
  const imgWait = d.images_waiting;
  const ownPending = !imgWait && ((d.own_images || []).length || (d.own_clips || []).length) && ["done", "error", "paused"].includes(j.status) && !d.stages.video;
  if (imgWait) act.push(`<button class="primary" data-own-go="1">${d.images_manual ? "🎬 Собрать видео с моими картинками" : "▶ Продолжить: дорисовать недостающие и смонтировать"}</button>`);
  if (imgWait && d.images_manual) act.push(`<button data-img-ai="1" title="Только для этого ролика">🎨 Передумал: пусть нарисует нейросеть</button>`);
  if (ownPending) act.push(`<button class="primary" data-own-go="1">🎬 Собрать видео с моими ${(d.own_clips || []).length && !(d.own_images || []).length ? "клипами" : "картинками"}</button>`);
  if (j.status === "review" && !ideaWait && !animWait && !imgWait) act.push(`<button class="primary" data-act="approve">✓ Сценарий хороший, продолжить</button>`);
  if (j.options.project_id && d.stages.review && j.status !== "running") act.push(`<button data-gold="video" title="Сценарист будет изучать этот текст перед новыми роликами проекта">⭐ ${d.format === "short" ? "Шортс" : "Сценарий"} в копилку удачных</button>`);
  if (j.options.project_id && d.format !== "short" && d.stages.short_script && j.status !== "running") act.push(`<button data-gold="short">⭐ Шортс в копилку</button>`);
  if (d.stages.images && j.status !== "running" && !j.options.translate_from) act.push(`<button data-tr="1" title="Те же картинки и анимация, текст, голос, субтитры и описание на другом языке: английском, немецком, испанском, французском">🌐 Версия на другом языке</button>`);
  act.push(`<button data-open="1">📂 Открыть папку</button>`);
  act.push(`<button class="danger" data-act="delete">Удалить</button>`);
  $("#jhead").innerHTML = `
  <div class="card">
    <div class="row"><a href="#/jobs" class="muted small">← Все ролики</a></div>
    <h1 style="margin:6px 0 2px">${j.options.episode ? `Серия ${j.options.episode}. ` : ""}${esc(j.options.title_ru || j.title || j.topic || "Тема ещё выбирается…")}</h1>
    ${j.title ? `<div class="en">${esc(j.title)}</div>` : ""}
    <div class="row" style="margin:10px 0">${badge(j.status)}
      <span class="muted small">${j.status === "running" ? "Сейчас: " + esc(META.stages.find(s => s.id === j.stage)?.name || "") : ""}</span>
      <span class="grow"></span>
      <span class="muted small" title="Текст (ИИ): $${(u.llm_cost || 0).toFixed(2)}${u.llm_by_stage ? " (" + Object.entries(u.llm_by_stage).map(([k, v]) => `${META.stages.find(s => s.id === k)?.name || k}: $${v.toFixed(2)}`).join(", ") + ")" : ""} · Картинки: $${(u.image_cost || 0).toFixed(2)} (${u.images || 0} шт.) · Анимация: $${(u.anim_cost || 0).toFixed(2)}">Потрачено: ~$${cost.toFixed(2)} (картинки $${(u.image_cost || 0).toFixed(2)}${u.anim_cost ? `, анимация $${u.anim_cost.toFixed(2)}` : ""}${u.music_cost ? `, музыка $${u.music_cost.toFixed(2)}` : ""}, текст $${(u.llm_cost || 0).toFixed(2)})${u.tts_chars ? ` + ${Math.round(u.tts_chars).toLocaleString("ru")} символов ElevenLabs` : ""}</span>
    </div>
    ${j.status !== "done" ? `<div class="bar"><div style="width:${j.progress}%"></div></div>` : ""}
    ${d.render_eta ? etaCard(d.render_eta, j.stage) : ""}
    ${d.stopping ? `<div class="banner info">⏳ Останавливаю прошлую попытку: она ждёт ответа от сервиса (Claude, ElevenLabs или fal.ai). Как только он ответит или выйдет время, ролик сам продолжится. Обычно это до нескольких минут, нажимать ничего не нужно.</div>` : ""}
    ${d.live ? `<div class="banner info">✍️ Claude ${d.live.words ? `пишет ответ: уже ${d.live.words.toLocaleString("ru")} слов` : d.live.think ? `обдумывает: ${d.live.think.toLocaleString("ru")} слов размышлений` : "получил задание и начинает"} · идёт ${clock(d.live.secs)}</div>` : ""}
    ${j.status === "error" ? `<div class="banner bad">${nl(j.error)}</div>` : ""}
    ${d.images_waiting && d.images_manual ? `<div class="banner info">⏸ Сценарий, сцены и озвучка готовы. Картинки программа не рисует. Откройте шаг «Сцены и описания картинок»: кнопка «📋 Описания картинок для другого сервиса» даст описание для каждой сцены. Сделайте картинки и загрузите их пачкой (номер сцены в имени файла: 1.png, 2.png…), потом нажмите «Собрать видео с моими картинками». Загружено: ${(d.own_images || []).length}.</div>` : ""}
    ${d.images_waiting && !d.images_manual ? `<div class="banner info">⏸ Сценарий и озвучка готовы. Откройте шаг «Сцены и описания картинок»: кнопка «📋 Описания картинок для другого сервиса» даст готовые описания для каждой сцены. Загрузите свои картинки по одной кнопкой «📤 Своя» или все сразу, потом нажмите «Продолжить». Сцены без вашей картинки программа нарисует сама. Загружено ваших: ${(d.own_images || []).length}.</div>` : ""}
    ${j.options.translate_from ? `<div class="banner info">🌐 Версия ролика ${LANG_IN[j.options.language] || ""} (из ролика <a href="#/job/${esc(j.options.translate_from)}">${esc(j.options.translate_from)}</a>): те же картинки и анимация${(j.options.flipped || []).length ? ", кадры отражены и камера движется по-другому" : ""}, новый текст, голос, субтитры, описание и обложка.</div>` : ""}
    ${ideaWait ? `<div class="banner info">${(j.topic || "").trim() && !j.options.episode ? "Ваша тема оформлена: название, хук и суть. Откройте шаг «Выбор темы», проверьте и нажмите «Взять эту тему». Если не то, нажмите «Переделать с этого шага»." : "Темы готовы, программа ждёт вашего выбора. Откройте шаг «Выбор темы», отметьте понравившуюся тему и нажмите «Взять эту тему»."} Сценарий ещё не писался, деньги почти не потрачены.</div>` : ""}
    ${animWait ? `<div class="banner info">🎬 Картинки и озвучка готовы, программа ждёт вашего выбора анимации. Откройте шаг «Анимация сцен» ниже: программа уже отметила сцены, которые оживила бы сама. Добавьте или снимите любые галочки и нажмите «Оживить выбранные и продолжить». Перед оплатой покажется цена.</div>` : ""}
    ${j.status === "review" && !ideaWait && !animWait && !d.images_waiting ? `<div class="banner info">Текст готов и проверен редактором. Программа остановилась и ждёт вас: сцены, картинки и озвучка ещё не делались. Прочитайте текст в шаге «Проверка редактором» → «Итоговый текст для озвучки». Если нужно, исправьте его там же и нажмите «Сохранить мой текст». Когда всё устраивает, нажмите «Сценарий хороший, продолжить». Или нажмите «Переделать» у шага «Текст сценария», чтобы ИИ написал заново.</div>` : ""}
    <div class="row" style="margin-top:12px">${act.join("")}</div>
  </div>`;
  $("#jhead").querySelectorAll("[data-own-go]").forEach(b => b.onclick = async () => {
    b.disabled = true;
    await api(`/api/jobs/${j.id}/own-images-done`, { method: "POST" }).then(() => toast(d.images_manual ? "Собираю видео с вашими картинками" : "Продолжаю: дорисую недостающие картинки и смонтирую видео")).catch(e => { toast(e.message, true); b.disabled = false; });
    lastStagesKey = "";
  });
  $("#jhead").querySelector("[data-img-ai]")?.addEventListener("click", async e => {
    const b = e.currentTarget;
    const prov = META.providers[(SETTINGS_CACHE || {}).image_provider] || {};
    if (!confirm(`Картинки этого ролика нарисует нейросеть${prov.name ? ` (${prov.name})` : ""}, это платно. Картинки, которые вы уже загрузили, останутся. Потом ролик сам смонтируется. Продолжить?`)) return;
    b.disabled = true;
    await api(`/api/jobs/${j.id}/images-ai`, { method: "POST" }).then(() => toast("Рисую картинки нейросетью, потом смонтирую видео")).catch(err => { toast(err.message, true); b.disabled = false; });
    lastStagesKey = "";
  });
  $("#jhead").querySelectorAll("[data-act]").forEach(b => b.onclick = async () => {
    const a = b.dataset.act;
    if (a === "delete" && !confirm("Удалить этот ролик вместе со всеми файлами?")) return;
    await api(`/api/jobs/${j.id}/action`, { json: { action: a } }).catch(e => toast(e.message, true));
    if (a === "delete") location.hash = "#/jobs"; else lastStagesKey = "";
  });
  $("#jhead").querySelectorAll("[data-gold]").forEach(b => b.onclick = async () => {
    const note = prompt("Чем этот текст хорош? Например: «сильный первый кадр», «смешная концовка». Можно оставить пустым.", "");
    if (note === null) return;
    await api(`/api/jobs/${j.id}/golden`, { json: { kind: b.dataset.gold, note } })
      .then(() => toast("Добавлено в копилку удачных сценариев проекта")).catch(e => toast(e.message, true));
  });
  const tr = $("#jhead [data-tr]");
  if (tr) tr.onclick = () => openTranslate(j, d);
  $("#jhead [data-open]").onclick = () => api("/api/open", { json: { what: "job", id: j.id } }).catch(e => toast(e.message, true));
}

async function openTranslate(j, d) {
  const proj = d.project || {};
  const from = j.options.language || "en";
  const langs = Object.keys(LANG_RU).filter(k => k !== from);
  const yt = await api("/api/youtube").catch(() => ({ channels: [] }));
  const scenes = ((d.stages.scenes || {}).scenes || []).length;
  const wrap = document.createElement("div");
  wrap.className = "vlib"; wrap.dataset.nodraft = 1;
  wrap.innerHTML = `<div class="box" style="max-width:560px"><button class="x" title="Закрыть">×</button>
    <h2>🌐 Версия на другом языке</h2>
    <p class="muted small">Программа возьмёт картинки и анимацию этого ролика, переведёт текст по сценам на живой язык зрителей, озвучит выбранным голосом, наложит субтитры и сделает название, описание, теги и новую обложку на этом языке. Этот ролик останется как был. Платится только перевод (центы), одна картинка обложки и символы ElevenLabs.</p>
    <label class="f">Язык</label>
    <select data-l>${langs.map(k => `<option value="${k}">${LANG_FLAG[k]} ${LANG_RU[k][0].toUpperCase() + LANG_RU[k].slice(1)}</option>`).join("")}</select>
    <label class="f">Голос <span class="hint">им говорит рассказчик или ведущий; персонажи со своими голосами в диалогах говорят своими. Сверху голоса под выбранный язык</span></label>
    <select data-v><option value="">Загружаю голоса…</option></select>
    <div class="row" style="margin-top:6px"><button class="sm" data-lib>🌍 Подобрать голос этого языка в библиотеке</button></div>
    <label class="f">Канал YouTube</label>
    <select data-ch><option value="">Без канала (загрузить вручную)</option>${yt.channels.map(c => `<option value="${c.id}">${esc(c.title)}</option>`).join("")}</select>
    <label class="check" style="margin-top:10px"><input type="checkbox" data-rs checked> Изменить вид кадров: отразить картинки и анимацию зеркально и повести камеру в другую сторону (бесплатно; кадры с товарами не отражаются, чтобы надписи не читались задом наперёд)</label>
    <label class="f">Перерисовать заново первые сцены (по тому же описанию, платно за каждую картинку)</label>
    <input type="number" data-rd min="0" max="${scenes}" value="0" style="width:100px">
    <div class="row" style="margin-top:14px"><button class="primary" data-go>Сделать версию</button></div></div>`;
  document.body.appendChild(wrap);
  const close = () => wrap.remove();
  wrap.querySelector(".x").onclick = close;
  wrap.addEventListener("click", e => { if (e.target === wrap) close(); });
  const vsel = wrap.querySelector("[data-v]"), lsel = wrap.querySelector("[data-l]"), chsel = wrap.querySelector("[data-ch]");
  if (langs.includes(proj.tr_lang)) lsel.value = proj.tr_lang;
  const fill = async (cur) => {
    const l = lsel.value;
    cur = cur ?? (proj[l + "_voice_id"] || "");
    chsel.value = proj[l + "_channel_id"] || "";
    try { const vs = await loadVoices(); vsel.innerHTML = `<option value="">— выберите голос —</option>` + voiceOptions(vs, cur, l); vsel.value = cur; }
    catch (e) { vsel.innerHTML = `<option value="">Голоса не загрузились: ${esc(e.message)}</option>`; }
  };
  fill(); lsel.onchange = () => fill();
  wrap.querySelector("[data-lib]").onclick = () => openVoiceLibrary((vid, name) => fill(vid).then(() => pickIntoSelect(vsel, vid, name)), lsel.value);
  wrap.querySelector("[data-go]").onclick = async () => {
    const o = vsel.options[vsel.selectedIndex];
    if (!vsel.value) return toast("Выберите голос", true);
    const r = await api(`/api/jobs/${j.id}/translate`, { json: { language: lsel.value, voice_id: vsel.value, voice_name: o.dataset.name || o.text,
      channel_id: chsel.value, restyle: wrap.querySelector("[data-rs]").checked,
      redraw: +wrap.querySelector("[data-rd]").value || 0 } }).catch(e => { toast(e.message, true); return null; });
    if (!r) return;
    close(); toast(`Версия ${LANG_IN[lsel.value]} запущена`); location.hash = `#/job/${r.id}`;
  };
}

function stageIcon(sid, d) {
  const j = d.job;
  if (!d.enabled[sid]) return "—";
  if (d.stages[sid]) return "✅";
  if (j.stage === sid && j.status === "running") return "⏳";
  if (j.stage === sid && j.status === "error") return "❌";
  if (sid === "approval" && j.status === "review" && !(d.anim && d.anim.waiting)) return "👀";
  if (sid === "animate" && d.anim && d.anim.waiting) return "👀";
  return "○";
}

function renderStages(d) {
  const el = $("#jstages");
  el.querySelectorAll("details[data-sid]").forEach(x => { if (x.open) openStages.add(x.dataset.sid); else openStages.delete(x.dataset.sid); });
  const typed = el.querySelector("#final-text");  // keep the owner's unsaved edit when the page refreshes
  const keepText = typed && typed.value !== typed.defaultValue ? typed.value : null;
  const j = d.job;
  el.innerHTML = META.stages.map(st => {
    const sid = st.id, data = d.stages[sid];
    const enabled = d.enabled[sid];
    const cur = j.stage === sid && ["running", "error"].includes(j.status);
    let body = "";
    try { body = enabled ? (RENDER[sid] ? RENDER[sid](data, d) : "") : (d.format === "short" ? `<p class="muted">Режим «Только шортс»: основное видео и есть шортс.</p>` : `<p class="muted">Шортс не заказан для этого ролика.</p>`); }
    catch (e) { body = `<p class="muted">Не удалось показать: ${esc(e.message)}</p>`; }
    if (!data && enabled && !body) body = `<p class="muted">${cur ? "Выполняется…" : "Ещё не начато."}</p>`;
    const writing = ["idea", "outline", "script", "review", "approval"].includes(sid);
    const redo = enabled && data && sid !== "approval" && !(j.options.montage && writing) ? `<button class="sm" data-redo="${sid}">↻ Переделать с этого шага</button>` : "";
    const ico = stageIcon(sid, d), stt = { "✅": "done", "⏳": "run", "❌": "err", "👀": "wait", "—": "off" }[ico] || "todo";
    return `<details class="stage ${enabled ? "" : "off"} ${cur ? "cur" : ""}" data-st="${stt}" data-sid="${sid}" ${openStages.has(sid) || (cur && j.status === "error") || (sid === "animate" && d.anim && d.anim.waiting) ? "open" : ""}>
      <summary><span class="ic">${ico}</span><span class="nm">${esc(st.name)}</span>${redo}</summary>
      <div class="content">${body}</div></details>`;
  }).join("");
  el.querySelectorAll("[data-redo]").forEach(b => b.onclick = async ev => {
    ev.preventDefault(); ev.stopPropagation();
    const name = META.stages.find(s => s.id === b.dataset.redo).name;
    if (!confirm(`Переделать шаг «${name}» и все шаги после него? Результаты этих шагов будут удалены и созданы заново (это снова потратит деньги на сервисах).`)) return;
    await api(`/api/jobs/${j.id}/action`, { json: { action: "restart_from", stage: b.dataset.redo } }).catch(e => toast(e.message, true));
    toast("Шаг поставлен в работу"); lastStagesKey = "";
  });
  const fSave = el.querySelector("#final-save");
  if (fSave) {
    const ta = el.querySelector("#final-text"), wc = el.querySelector("#final-wc");
    if (keepText !== null && !ta.disabled) ta.value = keepText;
    const count = () => { wc.textContent = `${(ta.value.match(/[\p{L}\p{N}]+/gu) || []).length} слов`; };
    ta.oninput = count; count();
    fSave.onclick = async () => {
      if (!confirm("Сохранить ваш текст? Сцены, озвучка и видео будут сделаны заново. Картинки абзацев, которые вы не меняли, останутся прежними, заново нарисуются только новые и изменённые.")) return;
      fSave.disabled = true;
      await api(`/api/jobs/${j.id}/script`, { json: { text: ta.value } })
        .then(() => toast("Текст сохранён, ролик собирается заново")).catch(e => { toast(e.message, true); fSave.disabled = false; });
      lastStagesKey = "";
    };
  }
  const chGo = el.querySelector("#ch-go");
  if (chGo) chGo.onclick = async () => {
    chGo.disabled = true; chGo.textContent = "⏳ Делаю тайм-коды…";
    await api(`/api/jobs/${j.id}/chapters`, { method: "POST" }).then(() => toast("Тайм-коды добавлены в описание"))
      .catch(e => { toast(e.message, true); chGo.disabled = false; chGo.textContent = "⏱ Сделать тайм-коды"; });
    lastStagesKey = "";
  };
  const impGo = el.querySelector("#imp-go");
  if (impGo) impGo.onclick = async () => {
    impGo.disabled = true; impGo.textContent = "⏳ Ищу слабые места, это минута…";
    await api(`/api/jobs/${j.id}/improve`, { json: { note: el.querySelector("#imp-note").value } })
      .then(() => toast("Готово: правки ниже")).catch(e => toast(e.message, true));
    impGo.disabled = false; impGo.textContent = "✨ Найти и исправить слабые места";
    lastStagesKey = "";
  };
  const impApply = el.querySelector("#imp-apply");
  if (impApply) impApply.onclick = () => {
    const all = d.improve.edits || [];
    const picked = [...el.querySelectorAll(".imp-pick")].filter(c => c.checked).map(c => all[+c.dataset.i]);
    if (!picked.length) return toast("Отметьте хотя бы одну правку", true);
    const ta = el.querySelector("#final-text");
    if (ta.disabled) return toast("Сначала поставьте ролик на паузу", true);
    const res = applyEdits(ta.value, picked);
    ta.value = res.text; ta.dispatchEvent(new Event("input"));
    ta.scrollIntoView({ behavior: "smooth", block: "center" });
    toast(res.missed ? `Вставлено правок: ${picked.length - res.missed}. ${res.missed} не нашли свой абзац (вы его уже меняли).` : "Правки вставлены в текст. Проверьте и нажмите «Сохранить мой текст»");
  };
  const ownUp = async (kind, idx, file) => {
    const r = await fetch(`/api/jobs/${j.id}/own-image?kind=${kind}&index=${idx}`, { method: "POST", body: file });
    if (!r.ok) { let m = "Не удалось загрузить картинку"; try { const x = await r.json(); m = x.error || x.detail || m; } catch (e) {} throw new Error(m); }
  };
  el.querySelectorAll("[data-own]").forEach(inp => inp.onchange = async () => {
    const [kind, idx] = inp.dataset.own.split(":");
    if (!inp.files[0]) return;
    try { await ownUp(kind, +idx, inp.files[0]); toast(kind === "thumbnail" ? "Ваша картинка поставлена в превью" : `Ваша картинка поставлена в сцену ${+idx + 1}`); } catch (e) { toast(e.message, true); }
    lastStagesKey = "";
  });
  const promptsBtn = el.querySelector("#own-prompts");
  if (promptsBtn) promptsBtn.onclick = async () => {
    let r;
    try { r = await api(`/api/jobs/${j.id}/scene-prompts`); } catch (e) { return toast(e.message, true); }
    const copy = async (text, btn) => {
      try { await navigator.clipboard.writeText(text); }
      catch (e) { const t = document.createElement("textarea"); t.value = text; document.body.appendChild(t); t.select(); document.execCommand("copy"); t.remove(); }
      if (btn) { btn.textContent = "✓ Скопировано"; setTimeout(() => btn.textContent = "Скопировать", 1500); }
    };
    const mo = new Set(r.motion || []);
    const all = [...r.video.map((p, i) => mo.has(i) ? "" : `Сцена ${i + 1}: ${p}`).filter(Boolean), ...r.short.map((p, i) => `Шортс, сцена ${i + 1}: ${p}`)].join("\n\n");
    const rows = (list, label, motionSet) => list.map((p, i) => motionSet && motionSet.has(i) ? `<div class="card" style="padding:10px;margin:6px 0"><b>${label} ${i + 1}</b> <span class="muted small">🗺 моушен: картинка не нужна</span></div>` : `<div class="card" style="padding:10px;margin:6px 0"><div class="row"><b>${label} ${i + 1}</b><span class="grow"></span><button class="sm" data-cp="${esc(p)}">Скопировать</button></div><div class="small" style="margin-top:4px">${esc(p)}</div></div>`).join("");
    const wrap = document.createElement("div");
    wrap.className = "vlib"; wrap.dataset.nodraft = 1;
    wrap.innerHTML = `<div class="box"><button class="x" title="Закрыть">×</button>
      <h2>Описания картинок для другого сервиса</h2>
      <p class="muted small">Только то, что нарисовать: стиль, сцена и запрет на надписи. Сгенерируйте картинку, сохраните её с номером сцены в имени (1.png, 2.png…) и загрузите кнопкой «📤 Загрузить свои картинки пачкой».</p>
      <div class="row" style="margin:8px 0"><button class="primary sm" data-cpall>Скопировать все</button></div>
      ${rows(r.video, "Сцена", mo)}${r.short.length ? `<h3>Шортс</h3>${rows(r.short, "Шортс, сцена")}` : ""}</div>`;
    document.body.appendChild(wrap);
    const close = () => wrap.remove();
    wrap.querySelector(".x").onclick = close;
    wrap.addEventListener("click", e => { if (e.target === wrap) close(); });
    wrap.querySelectorAll("[data-cp]").forEach(b => b.onclick = () => copy(b.dataset.cp, b));
    wrap.querySelector("[data-cpall]").onclick = e => { copy(all); e.target.textContent = "✓ Скопировано все"; };
  };
  el.querySelectorAll("#own-bulk, #own-bulk-short, #own-bulk-dir, #own-bulk-short-dir").forEach(bulk => bulk.onchange = async () => {
    const files = [...bulk.files].filter(f => /^image\//.test(f.type) || /\.(png|jpe?g|webp|heic|avif)$/i.test(f.name)).sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true }));
    let ok = 0, next = 0;
    for (const f of files) {
      const m = f.name.match(/\d+/);
      const idx = m ? +m[0] - 1 : next;
      next = idx + 1;
      try { await ownUp(bulk.dataset.kind, idx, f); ok++; } catch (e) { toast(`${f.name}: ${e.message}`, true); }
    }
    toast(`Загружено картинок: ${ok} из ${files.length}`);
    lastStagesKey = "";
  });
  const clipUp = async (kind, idx, file) => {
    const ext = (file.name.split(".").pop() || "mp4").toLowerCase();
    const r = await fetch(`/api/jobs/${j.id}/own-clip?kind=${kind}&index=${idx}&ext=${encodeURIComponent(ext)}`, { method: "POST", body: file });
    if (!r.ok) { let m = "Не удалось загрузить клип"; try { const x = await r.json(); m = x.error || x.detail || m; } catch (e) {} throw new Error(m); }
  };
  el.querySelectorAll("[data-clip]").forEach(inp => inp.onchange = async () => {
    const [kind, idx] = inp.dataset.clip.split(":");
    if (!inp.files[0]) return;
    toast("Загружаю клип…");
    try { await clipUp(kind, +idx, inp.files[0]); toast(`Ваш клип поставлен в сцену ${+idx + 1}. Нажмите «Собрать видео», когда загрузите всё`); } catch (e) { toast(e.message, true); }
    lastStagesKey = "";
  });
  const ownVid = el.querySelector("#own-video");
  if (ownVid) ownVid.onchange = async () => {
    const f = ownVid.files[0];
    if (!f) return;
    toast("Загружаю видео…");
    const ext = (f.name.split(".").pop() || "mp4").toLowerCase();
    const r = await fetch(`/api/jobs/${j.id}/own-video?ext=${encodeURIComponent(ext)}`, { method: "POST", body: f });
    if (!r.ok) { let m = "Не удалось загрузить видео"; try { const x = await r.json(); m = x.error || x.detail || m; } catch (e) {} return toast(m, true); }
    toast("Видео загружено: режу его по склейкам и свожу с озвучкой");
    lastStagesKey = "";
  };
  el.querySelectorAll("#clip-bulk, #clip-bulk-dir").forEach(clipBulk => clipBulk.onchange = async () => {
    const files = [...clipBulk.files].filter(f => /^video\//.test(f.type) || /\.(mp4|mov|webm|m4v)$/i.test(f.name)).sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true }));
    let ok = 0, next = 0;
    toast(`Загружаю клипы: ${files.length}…`);
    for (const f of files) {
      const m = f.name.match(/\d+/);
      const idx = m ? +m[0] - 1 : next;
      next = idx + 1;
      try { await clipUp("scene", idx, f); ok++; } catch (e) { toast(`${f.name}: ${e.message}`, true); }
    }
    toast(`Загружено клипов: ${ok} из ${files.length}`);
    lastStagesKey = "";
  });
  el.querySelectorAll("[data-regen]").forEach(b => b.onclick = async () => {
    const [kind, idx] = b.dataset.regen.split(":");
    const current = kind === "thumbnail" ? d.stages.extras.thumbnail_prompt
      : (kind === "short" ? d.stages.short_script.scenes : d.stages.scenes.scenes)[+idx].prompt;
    const fix = prompt("Что исправить на картинке? Напишите по-русски, например: «женщина сидит сзади, а не за рулём». Оставьте пустым, чтобы просто перерисовать." + (kind === "thumbnail" ? "" : " Видео потом пересоберётся."), "");
    if (fix === null) return;
    toast(fix.trim() ? "Исправляю описание и перерисовываю…" : "Перерисовываю…");
    await api(`/api/jobs/${j.id}/image`, { json: { kind, index: +idx, prompt: current, fix_ru: fix } }).then(() => toast("Картинка будет перерисована")).catch(e => toast(e.message, true));
    lastStagesKey = "";
  });
  el.querySelectorAll(".subs-pos").forEach(sel => sel.onchange = async () => {
    sel.disabled = true;
    await api(`/api/jobs/${j.id}/subtitles`, { json: { kind: sel.dataset.kind, pos: sel.value } })
      .then(() => toast("Высота субтитров изменена, видео пересобирается (это бесплатно)"))
      .catch(e => { toast(e.message, true); sel.disabled = false; });
    lastStagesKey = "";
  });
  el.querySelectorAll("[data-subs]").forEach(b => b.onclick = async () => {
    const [kind, on] = b.dataset.subs.split(":");
    b.disabled = true;
    await api(`/api/jobs/${j.id}/subtitles`, { json: { kind, on: on === "1" } })
      .then(() => toast(on === "1" ? "Субтитры включены, видео пересобирается (это бесплатно)" : "Субтитры выключены, видео пересобирается"))
      .catch(e => { toast(e.message, true); b.disabled = false; });
    lastStagesKey = "";
  });
  el.querySelectorAll(".speed-apply").forEach(b => b.onclick = async () => {
    const sel = b.parentElement.querySelector(".speed-sel");
    b.disabled = true; b.textContent = "Ускоряю…"; toast("Ускоряю видео, на длинном ролике это займёт пару минут…");
    await api(`/api/jobs/${j.id}/speed`, { json: { kind: sel.dataset.kind, speed: +sel.value } })
      .then(x => toast(x.speed === 1 ? "Вернул обычную скорость" : `Готово: быстрее в ${x.speed} раза`)).catch(e => toast(e.message, true));
    b.disabled = false; b.textContent = "Применить";
    lastStagesKey = "";
  });
  el.querySelectorAll("details.musicbox").forEach(box => {
    const sel = box.querySelector(".mb-track"), au = box.querySelector(".mb-audio"), o = j.options || {};
    const fill = (pick) => api("/api/music").then(fs => {
      sel.querySelectorAll("option.trk").forEach(x => x.remove());
      const cur = pick || o.music_track || "";
      sel.insertAdjacentHTML("beforeend", fs.map(f => `<option class="trk" value="${esc(f.name)}" ${f.name === cur ? "selected" : ""}>${esc(f.name)}${f.style ? " · " + esc(f.style) : ""}</option>`).join(""));
      if (cur) { sel.value = cur; sel.onchange(); }
    }).catch(e => toast(e.message, true));
    sel.onchange = () => {
      const v = sel.value;
      if (v && v !== "none") { au.src = `/music/${encodeURIComponent(v)}`; au.style.display = ""; } else { au.pause(); au.style.display = "none"; }
    };
    box.addEventListener("toggle", () => { if (box.open && !box.dataset.loaded) { box.dataset.loaded = "1"; fill(); } });
    box.querySelector(".mb-vol").oninput = e => { box.querySelector(".mb-vv").textContent = Math.round(e.target.value * 100) + "%"; };
    box.querySelector(".mb-up").onchange = async e => {
      const f = e.target.files[0]; if (!f) return;
      try { await api(`/api/music/upload?name=${encodeURIComponent(f.name)}`, { method: "POST", body: f }); toast("Трек загружен и выбран"); fill(f.name); }
      catch (er) { toast(er.message, true); }
    };
    box.querySelector(".mb-go").onclick = async e => {
      const b = e.target; b.disabled = true;
      await api(`/api/jobs/${j.id}/music`, { json: { track: sel.value, volume: box.querySelector(".mb-vol").value, style: box.querySelector(".mb-style").value } })
        .then(() => toast("Музыка выбрана, ролик пересобирается")).catch(er => { toast(er.message, true); b.disabled = false; });
      lastStagesKey = "";
    };
    box.querySelector(".mb-gen").onclick = async e => {
      const st = box.querySelector(".mb-style").value.trim() || (d.project && d.project.music_style) || "";
      if (!st && !confirm("Стиль не указан: программа сочинит музыку по сценарию. Продолжить?")) return;
      const b = e.target; b.disabled = true;
      await api(`/api/jobs/${j.id}/music`, { json: { track: "", compose: true, volume: box.querySelector(".mb-vol").value, style: box.querySelector(".mb-style").value } })
        .then(() => toast("Сочиняю музыку и пересобираю ролик")).catch(er => { toast(er.message, true); b.disabled = false; });
      lastStagesKey = "";
    };
  });
  el.querySelectorAll("details.revoice").forEach(box => {
    const sel = box.querySelector(".rv-voice");
    box.addEventListener("toggle", () => {
      if (!box.open || sel.dataset.loaded) return;
      sel.dataset.loaded = "1";
      loadVoices().then(vs => { sel.insertAdjacentHTML("beforeend", voiceOptions(vs, "", j.options.language || "ru")); sel.value = ""; }).catch(e => toast(e.message, true));
    });
    addLibButton(sel, j.options.language || "ru");
    box.querySelector(".rv-play").onclick = () => {
      const v = (VOICES || []).find(x => x.voice_id === sel.value);
      if (!v || !v.preview_url) return toast(sel.value ? "У этого голоса нет образца" : "Сначала выберите голос", true);
      const a = box.querySelector(".rv-audio"); a.src = v.preview_url; a.play();
    };
    box.querySelector(".rv-go").onclick = async e => {
      const b = e.target, o = sel.options[sel.selectedIndex];
      const body = { voice_id: sel.value, voice_name: sel.value ? (o.dataset.name || o.text) : "" };
      for (const k of ["voice_tempo", "voice_speed", "voice_stability", "voice_style", "voice_similarity"]) body[k] = box.querySelector(`.rv-${k}`).value;
      if (!confirm("Сделать озвучку заново и пересобрать ролик? Готовое видео заменится новым.")) return;
      b.disabled = true;
      await api(`/api/jobs/${j.id}/revoice`, { json: body }).then(() => toast("Переозвучиваю, потом пересоберу видео"))
        .catch(er => { toast(er.message, true); b.disabled = false; });
      lastStagesKey = "";
    };
  });
  el.querySelectorAll(".asm-opt").forEach(b => b.onchange = async () => {
    b.disabled = true;
    await api(`/api/jobs/${j.id}/assembly`, { json: { [b.dataset.k]: b.checked } })
      .then(() => toast("Видео пересобирается")).catch(e => { toast(e.message, true); b.checked = !b.checked; b.disabled = false; });
    lastStagesKey = "";
  });
  el.querySelectorAll(".atm-apply").forEach(b => b.onclick = async () => {
    b.disabled = true;
    await api(`/api/jobs/${j.id}/atmos`, { json: { mode: b.parentElement.querySelector(".atm-mode").value } })
      .then(() => toast("Атмосфера изменена, видео пересобирается")).catch(e => { toast(e.message, true); b.disabled = false; });
    lastStagesKey = "";
  });
  el.querySelectorAll("[data-motion]").forEach(b => b.onclick = async () => {
    const [i, on] = b.dataset.motion.split(":");
    b.disabled = true;
    await api(`/api/jobs/${j.id}/motion`, { json: { scene: +i, on: on === "1" } })
      .then(() => toast(on === "1" ? `В сцене ${+i + 1} снова моушен` : `В сцене ${+i + 1} будет картинка` + (d.images_manual ? ": загрузите её кнопкой «📤 Своя»" : ""))).catch(e => toast(e.message, true));
    b.disabled = false; lastStagesKey = "";
  });
  const replan = el.querySelector("#motion-replan");
  if (replan) replan.onclick = async () => {
    replan.disabled = true; replan.textContent = "⏳ Ищу места для карт и дат…";
    await api(`/api/jobs/${j.id}/motion`, { json: { replan: true } })
      .then(r => toast(r.found ? `Моушен в ${r.found} сценах${d.files.video ? ", видео пересобирается" : ""}` : "Подходящих мест для карт и дат не нашлось"))
      .catch(e => toast(e.message, true));
    replan.disabled = false; lastStagesKey = "";
  };
  el.querySelectorAll(".mot-apply").forEach(b => b.onclick = async () => {
    b.disabled = true;
    await api(`/api/jobs/${j.id}/motion`, { json: { mode: b.parentElement.querySelector(".mot-mode").value } })
      .then(() => toast("Сохранено")).catch(e => toast(e.message, true));
    b.disabled = false; lastStagesKey = "";
  });
  el.querySelectorAll(".atm-sel").forEach(sel => sel.onchange = async () => {
    sel.disabled = true;
    await api(`/api/jobs/${j.id}/atmos`, { json: { scene: +sel.dataset.i, kind: sel.value } })
      .then(() => toast("Эффект сцены изменён" + (d.files.video ? ", видео пересобирается" : ""))).catch(e => toast(e.message, true));
    sel.disabled = false; lastStagesKey = "";
  });
  el.querySelectorAll(".fx-apply").forEach(b => b.onclick = async () => {
    b.disabled = true;
    await api(`/api/jobs/${j.id}/effects`, { json: { mode: b.parentElement.querySelector(".fx-sel").value } })
      .then(() => toast("Эффекты изменены, видео пересобирается")).catch(e => { toast(e.message, true); b.disabled = false; });
    lastStagesKey = "";
  });
  const moreBtn = el.querySelector("#idea-more");
  if (moreBtn) moreBtn.onclick = async () => {
    moreBtn.disabled = true; moreBtn.textContent = "Придумываю…";
    await api(`/api/jobs/${j.id}/ideas/more`, { method: "POST" }).then(r => toast(`Добавлено новых тем: ${r.added}`)).catch(e => toast(e.message, true));
    moreBtn.disabled = false; moreBtn.textContent = "➕ Ещё темы";
    lastStagesKey = "";
  };
  const ideaBtn = el.querySelector("#idea-apply");
  if (ideaBtn) ideaBtn.onclick = async () => {
    const pick = el.querySelector('input[name="idea-pick"]:checked');
    if (!pick) return toast("Отметьте тему", true);
    const wait = j.status === "review" && j.options.idea_pause && !j.options.idea_picked;
    if (!wait && !confirm("Сменить тему? Сценарий, картинки и озвучка этого ролика сделаются заново.")) return;
    ideaBtn.disabled = true;
    try { await api(`/api/jobs/${j.id}/idea`, { json: { index: +pick.value } }); toast("Тема выбрана, пишу сценарий"); }
    catch (e) { toast(e.message, true); ideaBtn.disabled = false; }
    lastStagesKey = "";
  };
  const anMode = el.querySelector("#an-mode");
  if (anMode) {
    const sync = () => {
      const n = el.querySelectorAll(".an-pick:checked").length;
      const lbl = el.querySelector("#an-picked"); if (lbl) lbl.textContent = n ? `Отмечено: ${n}` : "";
      el.querySelector(".an-count-box").style.display = ["hook", "key"].includes(anMode.value) ? "" : "none";
    };
    el.querySelectorAll(".an-pick").forEach(c => c.addEventListener("change", () => { anMode.value = "custom"; sync(); }));
    anMode.addEventListener("change", () => { if (anMode.value === "custom") { const b = el.querySelector(".an-pick-box"); if (b) b.open = true; } sync(); });
    const none = el.querySelector("#an-none");
    if (none) none.onclick = () => { el.querySelectorAll(".an-pick").forEach(c => c.checked = false); sync(); };
    sync();
  }
  const anSkip = el.querySelector("#an-skip");
  if (anSkip) anSkip.onclick = async () => {
    anSkip.disabled = true;
    await api(`/api/jobs/${j.id}/animation`, { json: { mode: "off", short: false, count: +el.querySelector("#an-count").value, scenes: [] } })
      .then(() => toast("Продолжаю без анимации")).catch(e => { toast(e.message, true); anSkip.disabled = false; });
    lastStagesKey = "";
  };
  const anBtn = el.querySelector("#an-apply");
  if (anBtn) anBtn.onclick = async () => {
    anBtn.disabled = true;
    const picked = [...el.querySelectorAll(".an-pick:checked")].map(c => +c.value);
    if (anBtn.dataset.go && !picked.length) { anBtn.disabled = false; return toast("Отметьте хотя бы одну сцену или нажмите «Без анимации, продолжить»", true); }
    const body = { mode: anBtn.dataset.go ? "custom" : el.querySelector("#an-mode").value, short: el.querySelector("#an-short").checked,
      count: +el.querySelector("#an-count").value, scenes: picked };
    try {
      let r = await api(`/api/jobs/${j.id}/animation`, { json: body });
      if (r.confirm) {
        const ok = confirm(`Будет оживлено новых сцен: ${r.new}${r.kept ? ` (ещё ${r.kept} уже оживлены и бесплатны)` : ""}.\n\nЭто платно: примерно $${r.cost.toFixed(2)} на fal.ai.\n\nОживить?`);
        if (!ok) { anBtn.disabled = false; return; }
        r = await api(`/api/jobs/${j.id}/animation`, { json: { ...body, confirm: true } });
      }
      toast(anBtn.dataset.go ? "Оживляю выбранные сцены, ролик продолжается" : r.new === 0 && !r.confirm ? "Сохранено. Видео пересоберётся (новых оплат нет)." : "Сохранено. Видео пересоберётся.");
    } catch (e) { toast(e.message, true); anBtn.disabled = false; }
    lastStagesKey = "";
  };
  const thDraw = el.querySelector("#th-draw");
  if (thDraw) {
    let ref = (d.stages.extras || {}).thumbnail_ref || "";
    thDraw.querySelectorAll("[data-thref]").forEach(x => x.onclick = () => {
      ref = x.dataset.thref;
      thDraw.querySelectorAll("img.thref").forEach(i => { i.style.outline = i.dataset.thref === ref ? "3px solid var(--accent, #e33)" : "none"; });
      thDraw.querySelector("button.thref").classList.toggle("primary", !ref);
    });
    const go = thDraw.querySelector("#th-draw-go");
    go.onclick = async () => {
      const idea = thDraw.querySelector("#th-idea").value.trim(), pr = thDraw.querySelector("#th-prompt").value.trim();
      const changed = pr && pr !== ((d.stages.extras || {}).thumbnail_prompt || "");
      go.disabled = true; toast(idea ? "Делаю кликбейтный промт и рисую обложку…" : "Рисую обложку…");
      await api(`/api/jobs/${j.id}/thumb_prompt`, { json: { idea_ru: idea, prompt: changed ? pr : "", ref } })
        .then(() => toast("Обложка рисуется, через минуту появится здесь")).catch(e => { toast(e.message, true); go.disabled = false; });
      lastStagesKey = "";
    };
  }
  const thBtn = el.querySelector("#th-apply");
  if (thBtn) thBtn.onclick = async () => {
    thBtn.disabled = true;
    await api(`/api/jobs/${j.id}/thumbnail`, { json: { text: el.querySelector("#th-text").value, side: el.querySelector("#th-side").value, font: el.querySelector("#th-font").value, look: el.querySelector("#th-look").value } })
      .then(() => toast("Превью обновлено")).catch(e => toast(e.message, true));
    lastStagesKey = "";
  };
}

let lastUpKey = "";
const PRIVACY = [["private", "Приватно (видите только вы)"], ["unlisted", "По ссылке"], ["public", "Публично"]];
function statLine(s) {
  if (!s) return "";
  return `<div class="small" style="margin-top:6px">📈 Просмотров: <b>${(s.views || 0).toLocaleString("ru")}</b>${s.avg_view_pct != null ? ` · досматривают в среднем <b>${s.avg_view_pct}%</b> (${Math.round(s.avg_view_sec || 0)} сек)` : ""} · лайков ${s.likes || 0}${s.subs != null ? ` · подписчиков +${s.subs}` : ""} <span class="muted">(обновлено ${new Date(s.fetched_at * 1000).toLocaleString("ru")})</span></div>`;
}

function renderUploads(d) {
  const key = JSON.stringify([d.upload, d.channels, d.stats, d.instagram]);
  if (key === lastUpKey) return;
  lastUpKey = key;
  document.querySelectorAll(".igbox").forEach(box => {
    const st = (d.upload || {}).instagram || {};
    let h = `<h3>Instagram</h3>`;
    if (st.status === "done") h += `<div class="banner ok">✅ Рилс опубликован${st.username ? ` в @${esc(st.username)}` : ""}: <a href="${esc(st.url)}" target="_blank">${esc(st.url)}</a></div>`;
    else if (st.status === "queued" || st.status === "uploading") h += `<p>Выкладываю рилс в Instagram… ${esc(st.step || "")}</p>`;
    else if (!d.instagram) h += `<p class="muted">Чтобы выкладывать рилсы отсюда, подключите Instagram в <a href="#/settings/instagram">Настройках → Instagram</a>.</p>`;
    else h += (st.status === "error" ? `<div class="banner bad small">${nl(st.error)}</div>` : "")
      + `<div class="row"><button class="primary ig-go">📸 Выложить в Instagram (@${esc(d.instagram)})</button></div>`;
    box.innerHTML = h;
    const go = box.querySelector(".ig-go");
    if (go) go.onclick = async () => {
      go.disabled = true;
      await api(`/api/jobs/${d.job.id}/instagram`, { json: {} }).then(() => toast("Выкладываю в Instagram")).catch(e => { toast(e.message, true); go.disabled = false; });
      lastUpKey = "";
    };
  });
  document.querySelectorAll(".upbox").forEach(box => {
    const kind = box.dataset.kind, st = (d.upload || {})[kind] || {};
    const name = kind === "video" ? "видео" : "шортс";
    let h = `<h3>YouTube</h3>`;
    if (st.status === "done") {
      h += `<div class="banner ok">✅ Загружено на канал «${esc(st.channel_title)}»: <a href="${esc(st.url)}" target="_blank">${esc(st.url)}</a><br>
        <span class="small">${esc((PRIVACY.find(p => p[0] === st.privacy) || [, st.privacy])[1])}${st.publish_at ? ", публикация " + new Date(st.publish_at).toLocaleString("ru") : ""}. Проверить и поменять можно в <a href="https://studio.youtube.com" target="_blank">YouTube Studio</a>.</span></div>`
        + (st.note ? `<div class="banner warn small">${esc(st.note)}</div>` : "")
        + (kind === "video" && st.channel_id ? `<div class="row" style="margin-bottom:8px"><button class="sm up-thumb">🖼 ${st.note ? "Отправить превью ещё раз" : "Обновить превью на YouTube"}</button><span class="muted small">ставит текущую картинку превью из программы</span></div>` : "")
        + statLine((d.stats || {})[kind]);
    } else if (st.status === "queued" || st.status === "uploading") {
      h += `<p>Загружаю ${name} на «${esc(st.channel_title)}»… ${st.status === "queued" ? "(ждёт очереди)" : (st.progress || 0) + "%"}</p><div class="bar"><div style="width:${st.progress || 0}%"></div></div>`;
    } else if (!d.channels.length) {
      h += `<p class="muted">Чтобы загружать прямо отсюда, подключите канал в <a href="#/settings/youtube">Настройках → YouTube</a>.</p>`;
    } else {
      const def = d.job.options.channel_id && d.channels.find(c => c.id === d.job.options.channel_id) ? d.job.options.channel_id : d.channels[0].id;
      const prof = d.channels.find(c => c.id === def).profile;
      h += (st.status === "error" ? `<div class="banner bad small">${nl(st.error)}</div>` : "") + `
        <div class="grid2">
          <div><label class="f">Канал</label><select class="up-ch">${d.channels.map(c => `<option value="${c.id}" ${c.id === def ? "selected" : ""}>${esc(c.title)}</option>`).join("")}</select></div>
          <div><label class="f">Доступ</label><select class="up-pr">${PRIVACY.map(([v, n]) => `<option value="${v}" ${v === prof.privacy ? "selected" : ""}>${n}</option>`).join("")}</select></div>
        </div>
        <label class="f">Опубликовать по расписанию <span class="hint">Необязательно. Если указать время, ролик загрузится приватным и сам станет публичным в это время.</span></label>
        <input type="datetime-local" class="up-at" style="max-width:260px">
        <div class="row" style="margin-top:10px"><button class="primary up-go">⬆ Загрузить ${name} на YouTube</button></div>`;
    }
    if (st.status !== "done" && st.status !== "queued" && st.status !== "uploading" && d.job.status === "done") {
      h += `<details style="margin-top:10px"><summary class="small">Уже загрузили этот ${name} на YouTube сами? Вставьте ссылку, и программа будет учитывать его статистику</summary>
        <div class="row" style="margin-top:6px"><input type="text" class="up-link" placeholder="https://youtube.com/shorts/…" style="max-width:360px"><button class="sm up-link-go">Сохранить ссылку</button></div></details>`;
    }
    box.innerHTML = h;
    const th = box.querySelector(".up-thumb");
    if (th) th.onclick = async () => {
      th.disabled = true;
      await api(`/api/jobs/${d.job.id}/youtube_thumb`, { json: { kind } })
        .then(() => toast("Превью поставлено на YouTube")).catch(e => toast(e.message, true));
      th.disabled = false; lastUpKey = "";
    };
    const lk = box.querySelector(".up-link-go");
    if (lk) lk.onclick = async () => {
      await api(`/api/jobs/${d.job.id}/link`, { json: { kind, link: box.querySelector(".up-link").value } })
        .then(() => { toast("Ссылка сохранена. Статистика подтянется при следующем обновлении"); lastUpKey = ""; }).catch(e => toast(e.message, true));
    };
    const go = box.querySelector(".up-go");
    if (go) go.onclick = async () => {
      const at = box.querySelector(".up-at").value;
      go.disabled = true;
      await api(`/api/jobs/${d.job.id}/upload`, { json: { kind, channel_id: box.querySelector(".up-ch").value, privacy: box.querySelector(".up-pr").value, publish_at: at ? new Date(at).toISOString() : "" } })
        .then(() => toast("Загрузка началась")).catch(e => { toast(e.message, true); go.disabled = false; });
      lastUpKey = "";
    };
  });
}

const animModes = () => Object.entries(META.anim_modes).filter(([k]) => k !== "custom");
const img = (d, name, cls = "sc") => d.images.includes(name) ? `<a href="/files/${d.job.id}/images/${name}" target="_blank"><img class="${cls}" loading="lazy" src="/files/${d.job.id}/images/${name}?v=${d.job.updated}"></a>` : "";

const RENDER = {
  idea(r, d) {
    if (!r) return "";
    if (r.montage) return `<p>Монтаж по вашему тексту: тему не придумывали. Название ролика: <b>${esc(r.ideas[0].title_ru || r.ideas[0].title)}</b></p>`;
    const j = d.job, busy = j.status === "running";
    const wait = j.status === "review" && j.options.idea_pause && !j.options.idea_picked;
    const rate = x => x.viewer ? (+x.viewer.stop_scroll || 0) + (+x.viewer.unpredictable || 0) + (+x.viewer.payoff || 0) : x.total * 3;
    const order = r.ideas.map((x, i) => i).sort((a, b) => (b === r.chosen_index) - (a === r.chosen_index) || rate(r.ideas[b]) - rate(r.ideas[a]));
    const row = i => { const x = r.ideas[i]; return `<tr class="${i === r.chosen_index ? "chosen" : ""}">
      <td>${busy ? "" : `<input type="radio" name="idea-pick" value="${i}" ${i === r.chosen_index ? "checked" : ""}>`}${i === r.chosen_index ? " ★" : ""}</td>
      <td><b>${esc(x.title_ru)}</b><div class="en">${esc(x.title)}</div></td>
      <td class="small">${esc(x.premise_ru)}${x.twist_ru ? `<div><b>Поворот:</b> ${esc(x.twist_ru)}</div>` : ""}${x.viewer ? `<div class="muted">👀 Зритель: цепляет ${x.viewer.stop_scroll}/10, непредсказуемо ${x.viewer.unpredictable}/10, концовка ${x.viewer.payoff}/10. ${esc(x.viewer.comment_ru || "")}</div>` : ""}</td>
      <td class="small" style="white-space:nowrap">${Object.entries(x.scores || {}).map(([k, v]) => `<span title="${({ curiosity: "Любопытство", emotion: "Эмоции", clarity: "Понятность", uniqueness: "Новизна", visual: "Наглядность" })[k] || k}">${score(v)}</span>`).join(" ")}</td>
      <td>${score(x.total)}</td></tr>`; };
    const head = `<tr><th></th><th>Тема</th><th>Суть</th><th title="Любопытство / Эмоции / Понятность / Новизна / Наглядность">Оценки сценариста</th><th>Итог</th></tr>`;
    const who = r.picked_by_owner ? "Тему выбрали вы." : r.writer_choice !== undefined
      ? "Тему выбрал строгий зритель: он смотрит не на «Итог» сценариста, а на то, зацепит ли первая фраза, угадывается ли концовка и сработает ли поворот." : "Тему выбрал сценарист.";
    return `${wait ? `<div class="banner info">Отметьте тему и нажмите «Взять эту тему». ★ — тема, которую предлагает программа.</div>` : ""}
    <div class="banner ok"><b>${who}</b> ${esc(r.picked_by_owner ? "" : r.reason_ru || "")}</div>
    <table>${head}${order.slice(0, 10).map(row).join("")}</table>
    ${order.length > 10 ? `<details><summary>Ещё ${order.length - 10} тем</summary><table>${head}${order.slice(10).map(row).join("")}</table></details>` : ""}
    ${busy ? "" : `<div class="row" style="margin-top:8px"><button class="${wait ? "primary" : ""}" id="idea-apply">✓ Взять эту тему</button>
      <button id="idea-more" title="Сценарист придумает новые темы, не повторяя эти. Стоит как один запрос к ИИ, остальное не переделывается">➕ Ещё темы</button>
      ${wait ? "" : `<span class="muted small">Если тема сменится, сценарий, картинки и озвучка сделаются заново.</span>`}</div>`}
    <p class="muted small">«Итог» — средняя оценка самого сценариста (любопытство, эмоции, понятность, новизна, наглядность).</p>`;
  },
  outline(o, d) {
    if (!o) return "";
    if (d && d.job.options.montage) {
      const list = (t, xs) => (xs || []).length ? `<h3>${t}</h3><ul>${xs.map(x => `<li><b>${esc(x.name)}</b> <span class="en">${esc(x.visual)}</span></li>`).join("")}</ul>` : "";
      return `<p class="muted">Монтаж по вашему тексту: структуру не придумывали. Ниже места и люди из вашего текста, по ним картинки одного места рисуются одинаковыми.</p>`
        + (list("Места", o.locations) + list("Люди", o.characters) || `<p class="muted">Появятся на шаге «Сцены».</p>`);
    }
    return `<h3>Хук (первые 15 секунд)</h3><div class="banner info">${esc(o.hook?.why_ru)}<div class="en">${esc(o.hook?.text_idea)}<br>Главный вопрос: ${esc(o.hook?.big_question)}</div></div>
    <h3>Сюжет коротко</h3><p>${nl(o.summary_ru)}</p>
    <h3>Структура</h3>
    <table><tr><th>Время</th><th>Часть</th><th>Удерживающий крючок</th></tr>
    ${(o.sections || []).map(s => `<tr><td>${esc(s.start_time)}</td><td><b>${esc(s.purpose_ru)}</b><div class="en">${esc(s.name)} · ${(s.beats || []).map(esc).join(" · ")}</div></td><td class="en">${esc(s.rehook)}</td></tr>`).join("")}</table>
    ${(o.open_loops || []).length ? `<h3>Открытые вопросы, которые держат зрителя</h3><ul>${o.open_loops.map(l => `<li class="en">${esc(l.question)} (открыт: ${esc(l.opened_in)}, закрыт: ${esc(l.closed_in)})</li>`).join("")}</ul>` : ""}
    ${(o.characters || []).length ? `<h3>Герои (для одинаковой внешности на всех картинках)</h3><ul>${o.characters.map(c => `<li><b>${esc(c.name)}</b> <span class="en">${esc(c.visual)}</span></li>`).join("")}</ul>` : ""}`;
  },
  script(r, d) {
    if (!r) return "";
    if (d && d.job.options.montage) return `<p>Ваш текст: ${r.checks.word_count} слов, примерно ${r.checks.minutes} мин озвучки. Он озвучивается ровно как вставлен, его можно поправить в шаге «Проверка редактором».</p>`;
    return checksHtml(r.checks) + `<details><summary>Первый вариант текста${d && d.job.options.language !== "ru" ? ` (${LANG_RU[d.job.options.language || "en"] || ""})` : ""}</summary><pre class="text">${esc(r.script)}</pre></details>
    <p class="muted small">Этот текст дальше проверяет и улучшает редактор. Русский перевод итогового текста в шаге «Перевод и описание для YouTube».</p>`;
  },
  review(r, d) {
    const live = !r && d.stages.review_progress;
    if (!r && !live) return "";
    const rounds = (r || live).rounds;
    const thr = `порог ${esc(SETTINGS_CACHE?.quality_threshold ?? 8)}`;
    let head = "";
    if (r && r.montage) head = `<div class="banner info">Монтаж по вашему тексту: редактор его не проверял и не переписывал.</div>`;
    else if (r) head = r.passed ? `<div class="banner ok">✓ Сценарий прошёл проверку: итоговая оценка <b>${r.final_overall}</b> из 10 (${thr}).</div>`
      : `<div class="banner warn">Сценарий не дотянул до порога за отведённые раунды. Взята лучшая версия (оценка <b>${r.final_overall}</b>). Можно нажать «Переделать с этого шага» или поправить шаблон редактора.</div>`;
    return head + (rounds.length ? `<table><tr><th>Раунд</th><th>Оценка</th><th>Худший пункт</th><th>Слов</th><th>Решение</th></tr>
      ${rounds.map((x, i) => `<tr><td>${i + 1}</td><td>${score(x.overall)}</td><td>${score(x.min_score)}</td><td>${x.checks.word_count}</td><td>${x.passed ? "принято" : x.score_only ? "финальная проверка" : "переписан"}</td></tr>`).join("")}</table>` : "") + `
      ${rounds.map((x, i) => `<details ${i === rounds.length - 1 ? "open" : ""}><summary><b>Раунд ${i + 1}: подробно</b></summary>
        <table><tr><th>Критерий</th><th>Оценка</th><th>Комментарий редактора</th></tr>
        ${x.scores.map(s => `<tr><td>${esc(s.criterion_ru)}</td><td>${score(s.score)}</td><td class="small">${esc(s.comment_ru)}</td></tr>`).join("")}</table>
        ${x.retell_ru ? `<p><b>Как редактор понял историю на слух:</b> ${esc(x.retell_ru)}</p>` : ""}
        <p><b>Вердикт:</b> ${esc(x.verdict_ru)}</p>
        ${(x.issues_ru || []).length && !x.passed && !x.score_only ? `<p><b>Что исправлено в следующей версии:</b></p><ul>${x.issues_ru.map(t => `<li>${esc(t)}</li>`).join("")}</ul>` : ""}
        ${checksHtml(x.checks)}
      </details>`).join("")}
      ${r ? `<details ${d.job.status === "review" ? "open" : ""}><summary><b>✏️ Итоговый текст для озвучки — можно исправить вручную</b>${r.edited_by_owner ? " (исправлен вами)" : ""}</summary>
        <p class="muted small">Здесь ровно то, что будет прочитано вслух. Исправьте что хотите и нажмите «Сохранить мой текст»: программа заново разобьёт его на сцены и озвучит. Картинки неизменённых кусков останутся прежними (и их анимации тоже), платно рисуются только новые и изменённые. Пустая строка разделяет абзацы.${(d.job.options.characters || []).length ? " Реплика героя своим голосом пишется отдельным абзацем: «Имя: фраза»." : ""}</p>
        <textarea id="final-text" rows="14" style="width:100%" ${d.job.status === "running" ? "disabled" : ""}>${esc(r.final_script)}</textarea>
        <div class="row" style="margin-top:8px"><button class="primary" id="final-save" ${d.job.status === "running" ? "disabled title=\"Поставьте ролик на паузу\"" : ""}>Сохранить мой текст</button><span class="muted small" id="final-wc"></span></div>
        ${improveBox(d)}
      </details>` : ""}`;
  },
  scenes(r, d) {
    const busy = d.job.status === "running";
    r = r || {};
    const vidBox = d.job.options.montage ? `<div class="row" style="margin-bottom:8px"><label class="btn sm" style="cursor:pointer">🎞 ${r.own_video ? "Заменить" : "Загрузить"} готовое видео целиком<input type="file" accept="video/*" id="own-video" style="display:none" ${busy ? "disabled title=\"Поставьте ролик на паузу\"" : ""}></label><span class="muted small">${r.own_video ? "Сцены сделаны из склеек вашего видео." : "Все сцены одним файлом: программа разрежет его по склейкам и подгонит под озвучку, картинки не понадобятся."}</span></div>` : "";
    if (!r.scenes) return vidBox ? vidBox + (busy ? `<p class="muted small">Чтобы загрузить видео сейчас, поставьте ролик на паузу.</p>` : "") : "";
    const durs = d.stages.voice?.durations;
    const own = new Set(d.own_images || []);
    return vidBox + `<p class="muted">${r.scenes.length} сцен, по одной картинке на каждую. ${d.images_manual ? "Картинки вы делаете сами в другом сервисе: «📋 Описания картинок» даст описание для каждой сцены, загрузите готовые картинки пачкой или по одной кнопкой «📤 Своя» (картинка обрежется под кадр)." : "«Перерисовать» нарисует картинку заново, «📤 Своя» поставит вашу картинку (она обрежется под кадр)."}</p>
    ${d.format !== "short" ? `<div class="row" style="margin-bottom:8px"><button class="sm" id="motion-replan" ${busy ? "disabled" : ""}>🗺 ${(d.motion || []).length ? "Найти моушен заново" : "Добавить моушен"}</button><span class="muted small">${(d.motion || []).length ? `Моушен в сценах: ${d.motion.filter(m => m.on).map(m => m.index + 1).join(", ") || "выключен"}.` : "Программа найдёт в сценарии места, где лучше показать карту, хронологию, график, сравнение, цитату или список, и заменит там картинку анимацией. Бесплатно, кроме одного короткого запроса к нейросети."}</span></div>` : ""}
    <div class="row" style="margin-bottom:8px"><button class="sm" id="own-prompts">📋 Описания картинок для другого сервиса</button>
      <label class="btn sm" style="cursor:pointer">📤 Загрузить свои картинки пачкой<input type="file" accept="image/*" multiple id="own-bulk" data-kind="scene" style="display:none" ${busy ? "disabled" : ""}></label><label class="btn sm" style="cursor:pointer">📁 Папкой<input type="file" accept="image/*" multiple webkitdirectory id="own-bulk-dir" data-kind="scene" style="display:none" ${busy ? "disabled" : ""}></label>
      <span class="muted small">Номер сцены берётся из имени файла (1.png, scene_12.jpg, 03.webp); без номера по порядку.</span></div>
    <table><tr><th>#</th><th>Картинка</th><th>Текст сцены и что на картинке</th><th></th></tr>
    ${r.scenes.map((s, i) => `<tr><td>${i + 1}${durs ? `<div class="muted small">${durs[i].toFixed(1)}с</div>` : ""}</td><td>${img(d, `scene_${String(i).padStart(3, "0")}.png`, d.format === "short" ? "vsc" : "sc")}</td>
      <td><div>${esc(s.prompt_ru)}</div>${s.location || s.shot ? `<div class="muted small">${s.location ? `📍 ${esc(s.location)}` : ""}${s.shot ? ` 🎥 ${esc(({ wide: "общий план", medium: "средний план", pov: "от первого лица", closeup: "крупный план", ots: "из-за плеча", detail: "деталь крупно", low: "снизу", high: "сверху", profile: "в профиль" })[s.shot] || s.shot)}` : ""}</div>` : ""}<div class="en">${esc(s.text)}</div>${fxTag(s)}${motionTag(d, i, busy)}${atmSel(s, i, busy)}</td>
      <td>${d.images_manual ? "" : `<button class="sm" data-regen="scene:${i}">Перерисовать</button>`}<label class="btn sm" style="cursor:pointer;margin-top:4px">📤 Своя<input type="file" accept="image/*" data-own="scene:${i}" style="display:none" ${busy ? "disabled" : ""}></label>${own.has(`scene:${i}`) ? `<div class="muted small">🖼 ваша</div>` : ""}</td></tr>`).join("")}</table>`;
  },
  extras(r, d) {
    if (!r) return "";
    const t = d.thumb || {};
    const v = Date.now();
    const thumbBox = d.files.thumbnail
      ? `<a href="/files/${d.job.id}/output/thumbnail.jpg" target="_blank"><img style="width:${d.format === "short" ? "270px" : "480px"};max-width:100%;border-radius:8px;display:block" src="/files/${d.job.id}/output/thumbnail.jpg?v=${v}"></a>`
      : d.files.thumbnail_src ? `<div class="banner info">Картинка для превью готова, надписи пока нет. Нажмите «Обновить надпись».</div>`
      : `<p class="muted">Превью появится после шага «Картинки».</p>`;
    return `<h3>Превью (обложка)</h3>
    <div class="row" style="align-items:flex-start">
      <div>${thumbBox}</div>
      <div class="grow" style="min-width:260px">
        <label class="f">Надпись на превью <span class="hint">На языке ролика, 2–4 слова. Предложено: ${esc(r.thumbnail_text)} (${esc(r.thumbnail_text_ru)})</span></label>
        <input type="text" id="th-text" value="${esc(t.text ?? r.thumbnail_text)}">
        <label class="f">Где надпись</label>
        <select id="th-side"><option value="left" ${t.side !== "right" ? "selected" : ""}>${d.format === "short" ? "Сверху" : "Слева"}</option><option value="right" ${t.side === "right" ? "selected" : ""}>${d.format === "short" ? "Снизу" : "Справа"}</option></select>
        <label class="f">Шрифт</label>
        <select id="th-font"><option value="">Как предложил сценарист${r.thumbnail_font ? ` (${esc((META.thumb_fonts[r.thumbnail_font] || r.thumbnail_font).split(":")[0])})` : ""}</option>${Object.entries(META.thumb_fonts).map(([k, n]) => `<option value="${k}" ${t.font === k ? "selected" : ""}>${esc(n)}</option>`).join("")}</select>
        <label class="f">Оформление надписи</label>
        <select id="th-look"><option value="">Как предложил сценарист</option>${Object.entries(META.thumb_looks).map(([k, n]) => `<option value="${k}" ${t.look === k ? "selected" : ""}>${esc(n)}</option>`).join("")}</select>
        <p class="muted small">Шрифт без русских букв программа сама заменит на подходящий.</p>
        <div class="row" style="margin-top:10px">
          <button class="primary" id="th-apply" ${d.files.thumbnail_src ? "" : "disabled"}>Обновить надпись</button>
          ${d.files.thumbnail ? `<a class="btn" href="/files/${d.job.id}/output/thumbnail.jpg" download="thumbnail.jpg">⬇ Скачать превью</a>` : ""}
          <button data-regen="thumbnail:0" ${d.job.status === "running" ? "disabled" : ""}>Перерисовать картинку</button>
          <label class="btn" style="cursor:pointer">📤 Своя картинка<input type="file" accept="image/*" data-own="thumbnail:0" style="display:none" ${d.job.status === "running" ? "disabled" : ""}></label>
        </div>
        <p class="muted small">Надпись меняется бесплатно и сразу. «Перерисовать картинку» заново рисует саму картинку (стоит как одна картинка); можно написать, что исправить. «Своя картинка» ставит вашу картинку под надпись.${d.files.thumbnail_src ? "" : " <b>Картинки для превью сейчас нет:</b> нарисуйте её заново или загрузите свою."}</p>
      </div>
    </div>
    <div class="card" style="margin-top:12px;padding:14px" id="th-draw">
      <h3 style="margin-top:0">🎨 Своя обложка</h3>
      <label class="f">Идея обложки своими словами <span class="hint">по-русски: что на ней должно быть. Программа сама сделает из этого кликбейтный промт: крупное лицо с сильной эмоцией, шок, интрига</span></label>
      <textarea id="th-idea" rows="2" placeholder="например: Бальмис в ужасе держит ребёнка на палубе, за спиной шторм">${esc(r.thumbnail_idea_ru || "")}</textarea>
      <details style="margin-top:6px"><summary class="muted small">Промт для нейросети (английский, можно править вручную)</summary>
        <textarea id="th-prompt" rows="4" style="margin-top:6px">${esc(r.thumbnail_prompt || "")}</textarea></details>
      <label class="f">Образец <span class="hint">необязательно: выберите картинку ролика, обложка возьмёт с неё персонажей, стиль и место, но построит новый, более драматичный кадр</span></label>
      <div class="thref-grid" style="display:flex;gap:6px;overflow-x:auto;padding-bottom:6px">
        <button class="sm thref ${r.thumbnail_ref ? "" : "primary"}" data-thref="" style="flex:0 0 auto">Без образца</button>
        ${(d.images || []).filter(n => /^(scene|short)_\d{3}\.png$/.test(n)).map(n => `<img class="thref" data-thref="${n}" title="${n}" src="/files/${d.job.id}/images/${n}?v=${d.job.updated}" loading="lazy" style="flex:0 0 auto;height:${d.format === "short" ? 96 : 60}px;border-radius:6px;cursor:pointer;outline:${r.thumbnail_ref === n ? "3px solid var(--accent, #e33)" : "none"}">`).join("")}
      </div>
      <div class="row" style="margin-top:8px"><button class="primary" id="th-draw-go" ${d.job.status === "running" ? "disabled" : ""}>🎨 Нарисовать обложку</button>
        <span class="muted small">стоит как одна картинка, надпись сверху сохранится</span></div>
    </div>
    <h3>Для загрузки на YouTube</h3>
    <div class="kv">
      <div>Название</div><div><b>${esc(r.youtube_title)}</b> ${copyBtn(r.youtube_title)}<div class="muted small">${esc(r.youtube_title_ru)}</div></div>
      <div>Описание</div><div><div class="small" style="white-space:pre-wrap">${esc(d.chapters ? r.description + "\n\n" + d.chapters : r.description)}</div>${copyBtn(d.chapters ? r.description + "\n\n" + d.chapters : r.description)}
        ${d.chapters ? `<div class="muted small">Тайм-коды внизу описания посчитаны по озвучке: YouTube сам сделает из них главы.</div>` : d.files.video && d.format !== "short" ? `<div style="margin-top:6px"><button class="sm" id="ch-go">⏱ Сделать тайм-коды</button> <span class="muted small">главы ролика вопросами, по точному времени озвучки, около цента</span></div>` : ""}</div>
      <div>Теги</div><div class="tags">${(r.tags || []).map(t => `<span>${esc(t)}</span>`).join("")} ${copyBtn((r.tags || []).join(", "))}</div>
    </div>
    ${d.files.youtube_txt ? `<p><a class="btn" href="/files/${d.job.id}/output/youtube.txt" target="_blank">📄 Всё для YouTube одним файлом</a> <span class="muted small">Название, описание и теги для видео и шортса. Лежит в папке ролика рядом с видео.</span></p>` : ""}
    <h3>Сценарий на русском</h3><pre class="text">${esc(r.script_ru)}</pre>`;
  },
  short_script(r, d) {
    if (!r) return "";
    return `<div class="kv"><div>Название</div><div><b>${esc(r.title_ru)}</b><div class="en">${esc(r.title)}</div></div>
      <div>Сила первой фразы</div><div>${score(r.hook_score)}</div><div>Концовка</div><div>${score(r.payoff_score)}</div>
      <div>Почему этот момент</div><div>${esc(r.why_ru)}</div></div>
      <h3>Текст на русском</h3><pre class="text">${esc(r.script_ru)}</pre>
      <details><summary>Текст ${LANG_IN[d.job.options.language || "en"] || ""}</summary><pre class="text">${esc(r.script)}</pre></details>
      <h3>Сцены шортса</h3><div class="row" style="margin-bottom:8px"><label class="btn sm" style="cursor:pointer">📤 Загрузить картинки шортса пачкой<input type="file" accept="image/*" multiple id="own-bulk-short" data-kind="short" style="display:none" ${d.job.status === "running" ? "disabled" : ""}></label><label class="btn sm" style="cursor:pointer">📁 Папкой<input type="file" accept="image/*" multiple webkitdirectory id="own-bulk-short-dir" data-kind="short" style="display:none" ${d.job.status === "running" ? "disabled" : ""}></label><span class="muted small">Номер сцены шортса берётся из имени файла.</span></div><table>${r.scenes.map((s, i) => `<tr><td>${i + 1}</td><td>${img(d, `short_${String(i).padStart(3, "0")}.png`, "vsc")}</td><td>${esc(s.prompt_ru)}<div class="en">${esc(s.text)}</div></td><td>${d.images_manual ? "" : `<button class="sm" data-regen="short:${i}">Перерисовать</button>`}<label class="btn sm" style="cursor:pointer;margin-top:4px">📤 Своя<input type="file" accept="image/*" data-own="short:${i}" style="display:none"></label>${(d.own_images || []).includes(`short:${i}`) ? `<div class="muted small">🖼 ваша</div>` : ""}</td></tr>`).join("")}</table>`;
  },
  approval(r, d) {
    if (r) return `<p class="muted">Сценарий одобрен${d.job.options.review_pause ? " вами" : " автоматически (пауза для проверки не была включена)"}.</p>`;
    if (d.job.status === "review" && !d.anim.waiting) return `<div class="banner info">Ждёт вашего решения. <button class="primary" onclick="document.querySelector('[data-act=approve]').click()">✓ Сценарий хороший, продолжить</button></div>`;
    return d.job.options.review_pause ? `<p class="muted">Здесь программа остановится и подождёт вашей проверки.</p>` : `<p class="muted">Пауза не включена: шаг пройдёт автоматически.</p>`;
  },
  voice(r, d) {
    if (!r) return "";
    return `<p>Длительность: <b>${fmtTime(r.total)}</b>${r.short_total ? `, шортс: <b>${fmtTime(r.short_total)}</b>` : ""}</p>
      ${d.files.narration ? `<audio controls preload="none" src="/files/${d.job.id}/narration.wav"></audio>` : ""}
      ${revoiceBox(d)}`;
  },
  images(r, d) {
    if (!r) return d.images.length ? `<p class="muted">Готово картинок: ${d.images.length}</p>` : "";
    return `<p>Картинок: <b>${r.count}</b>${r.replaced ? `, из них ${r.replaced} не получились и заменены соседними (их можно перерисовать в шаге «Сцены»)` : ""}.</p>
      <div class="imgs">${d.images.filter(n => n.startsWith("scene_")).slice(0, 12).map(n => img(d, n)).join("")}</div>
      ${d.images.some(n => n.startsWith("loc_")) ? `<p><b>Места действия</b> <span class="muted small">(по ним рисуются все сцены в этом месте)</span></p><div class="imgs">${d.images.filter(n => n.startsWith("loc_")).map(n => img(d, n, n.includes("_v") ? "vsc" : "sc")).join("")}</div>` : ""}
      <p class="muted small">Все картинки с текстом сцен в шаге «Сцены и описания картинок».</p>`;
  },
  animate(r, d) {
    const a = d.anim;
    const busy = d.job.status === "running";
    const dis = busy ? "disabled" : "";
    const ownClips = new Set(d.own_clips || []);
    const ownNames = [...ownClips].map(k => { const [kind, i] = k.split(":"); return `${kind}_${String(+i).padStart(3, "0")}.mp4`; });
    const names = [...new Set([...(r ? [...r.scene.map(i => `scene_${String(i).padStart(3, "0")}.mp4`), ...r.short.map(i => `short_${String(i).padStart(3, "0")}.mp4`)] : []), ...ownNames])].filter(n => a.files.includes(n));
    const scenes = d.images.filter(n => /^scene_\d+\.png$/.test(n));
    const chosen = new Set(r ? r.scene : a.waiting ? a.suggest : (a.mode === "custom" ? a.scenes : []));
    const clip = (META.video_models.find(m => m.id === META.video_model) || META.video_models[0] || {}).clip;
    let h = `<div class="row">
      <select id="an-mode" style="max-width:300px" ${dis}>${Object.entries(META.anim_modes).map(([k, n]) => `<option value="${k}" ${k === a.mode ? "selected" : ""}>${esc(n)}</option>`).join("")}</select>
      <label class="check an-count-box" style="margin:0">сцен: <input type="number" id="an-count" min="1" max="60" value="${a.count}" style="width:70px" ${dis}></label>
      <label class="check" style="margin:0"><input type="checkbox" id="an-short" ${a.short ? "checked" : ""} ${dis}> и шортс</label>
      ${a.waiting ? "" : `<button class="sm" id="an-apply" ${busy ? "disabled title=\"Подождите, пока ролик доделается\"" : ""}>Применить</button>`}</div>
      <p class="muted small">Перед оплатой программа покажет, сколько новых сцен оживится и сколько это стоит${clip ? ` (примерно $${clip} за сцену, даже если сцена короткая: клип оплачивается минимум за 5 секунд)` : ""}. Уже оживлённые сцены сохраняются и второй раз не оплачиваются.</p>`;
    if (scenes.length) {
      if (a.waiting) h = `<div class="banner info">⏸ Выберите сцены для анимации. Отмечено то, что программа оживила бы сама${a.suggest.length ? ` (${a.suggest.length})` : ""}: можно добавить сколько угодно или снять. <div class="row" style="margin-top:8px"><button class="primary" id="an-apply" data-go="1">🎬 Оживить выбранные и продолжить</button><button id="an-skip">Без анимации, продолжить</button></div></div>` + h;
      h += `<details class="an-pick-box" ${a.mode === "custom" || a.waiting ? "open" : ""}><summary>Выбрать сцены вручную (${scenes.length} шт.)</summary>
        <p class="muted small">${a.waiting ? "Отметьте галочками сцены, которые нужно оживить, и нажмите «Оживить выбранные и продолжить» выше." : "Отметьте галочками сцены, которые нужно оживить, и нажмите «Применить». Режим сам переключится на «Выбранные вручную»."}</p>
        <div class="row" style="margin-bottom:6px"><button class="sm ghost" type="button" id="an-none" ${dis}>Снять все</button><span class="muted small" id="an-picked"></span></div>
        <div class="imgs an-grid">${scenes.map(n => { const i = +n.slice(6, 9); return `<label class="an-cell"><img loading="lazy" src="/files/${d.job.id}/images/${n}?v=${d.job.updated}"><span><input type="checkbox" class="an-pick" value="${i}" ${chosen.has(i) ? "checked" : ""} ${dis}> Сцена ${i + 1}${a.files.includes(`scene_${String(i).padStart(3, "0")}.mp4`) ? " ✨" : ""}</span></label>`; }).join("")}</div>
        <p class="muted small">✨ — уже оживлена, бесплатно.</p></details>`;
    }
    if (scenes.length) {
      h += `<details class="an-own-box" ${ownClips.size ? "open" : ""}><summary>📤 Свои анимированные кадры${ownClips.size ? ` (загружено: ${ownClips.size})` : ""}</summary>
        <p class="muted small">Скачайте картинку сцены (кнопка «⬇ Картинка»), оживите её где угодно (Google Flow, Kling, Runway…) и загрузите готовый клип кнопкой «📤 Клип». Он встанет в эту сцену вместо картинки, программа ничего за него не платит. Клип подгоняется под длину сцены: короткий чуть замедлится и задержится на последнем кадре. Звук из клипа не берётся.</p>
        <div class="row" style="margin-bottom:6px"><label class="btn sm" style="cursor:pointer">📤 Загрузить клипы пачкой<input type="file" accept="video/*" multiple id="clip-bulk" style="display:none" ${dis}></label><label class="btn sm" style="cursor:pointer">📁 Папкой<input type="file" accept="video/*" multiple webkitdirectory id="clip-bulk-dir" style="display:none" ${dis}></label>
          <span class="muted small">Номер сцены берётся из имени файла (1.mp4, scene_12.mov); без номера по порядку.</span></div>
        <div class="imgs an-grid">${scenes.map(n => { const i = +n.slice(6, 9); const has = ownClips.has(`scene:${i}`); return `<div class="an-cell"><img loading="lazy" src="/files/${d.job.id}/images/${n}?v=${d.job.updated}"><span>Сцена ${i + 1}${has ? " 🎞 ваш клип" : ""}</span>
          <span class="row" style="gap:4px"><a class="btn sm" href="/files/${d.job.id}/images/${n}" download="scene_${i + 1}.png">⬇ Картинка</a><label class="btn sm" style="cursor:pointer">📤 Клип<input type="file" accept="video/*" data-clip="scene:${i}" style="display:none" ${dis}></label></span></div>`; }).join("")}</div></details>`;
    }
    if (r && r.mode !== "off" || names.length) {
      h += `<p>Оживлено сцен: <b>${names.length}</b>${r && r.failed.length ? `, не получилось: ${r.failed.length} (там будет обычная картинка)` : ""}.</p>
        <div class="imgs">${names.map(n => `<video class="${n.startsWith("short") ? "vert" : ""}" muted loop preload="metadata" onmouseenter="this.play()" onmouseleave="this.pause()" src="/files/${d.job.id}/anim/${n}?v=${d.job.updated}#t=0.5"></video>`).join("")}</div>
        ${names.length ? `<p class="muted small">Наведите мышку на клип, чтобы посмотреть.</p>` : ""}`;
    }
    return h;
  },
  video(r, d) {
    if (!r || !d.files.video) return "";
    const vert = d.format === "short";
    return `<video class="${vert ? "vert" : ""}" controls preload="metadata" src="/files/${d.job.id}/output/video.mp4?v=${d.job.updated}"></video>
      <div class="row" style="margin-top:10px"><a class="btn primary" href="/files/${d.job.id}/output/video.mp4" download="${esc(((d.job.title || "").replace(/[^\p{L}\p{N}\- ]+/gu, "").trim() || "video"))}.mp4">⬇ Скачать видео</a>
      <span class="muted">${fmtTime(r.duration)} · ${vert ? "1080×1920, шортс" : "1920×1080"}${r.music ? " · музыка: " + esc(r.music) : " · без музыки"}</span></div>
      ${subsRow(d, "video", vert ? "short_srt" : "srt", vert ? "short_subtitles.srt" : "subtitles.srt")}
      ${speedRow(d, "video", r)}
      ${fxRow(d)}
      ${musicBox(d, r)}
      <div class="upbox" data-kind="video"></div>${vert ? `<div class="igbox"></div>` : ""}`;
  },
  short_video(r, d) {
    if (!r || !d.files.short) return "";
    return `<video class="vert" controls preload="metadata" src="/files/${d.job.id}/output/short.mp4?v=${d.job.updated}"></video>
      <div class="row" style="margin-top:10px"><a class="btn primary" href="/files/${d.job.id}/output/short.mp4" download="short.mp4">⬇ Скачать шортс</a><span class="muted">${fmtTime(r.duration)} · 1080×1920</span></div>
      ${subsRow(d, "short", "short_srt", "short_subtitles.srt")}
      ${speedRow(d, "short", r)}
      <div class="upbox" data-kind="short"></div>${d.format !== "short" ? `<div class="igbox"></div>` : ""}`;
  },
};

function motionTag(d, i, busy) {
  const m = (d.motion || []).find(x => x.index === i);
  if (!m) return "";
  return `<div class="row small" style="margin-top:4px;gap:6px"><span class="tag" style="background:${m.on ? "rgba(250,204,21,.22)" : "transparent"};border:1px solid #b8901a;border-radius:6px;padding:1px 6px">${esc(m.kind)}${m.title ? `: ${esc(m.title)}` : ""}</span>${m.on ? `<span class="muted">вместо картинки</span><button class="sm" data-motion="${i}:0" ${busy ? "disabled" : ""}>Вернуть картинку</button>` : `<span class="muted">выключен</span><button class="sm" data-motion="${i}:1" ${busy ? "disabled" : ""}>Включить моушен</button>`}</div>`;
}

function atmSel(s, i, busy) {
  const cur = s.atmosphere || "none";
  return `<div class="row small" style="margin-top:4px;gap:6px"><span class="muted">🌫 Атмосфера:</span><select class="atm-sel sm" data-i="${i}" style="width:auto;padding:2px 6px" ${busy ? "disabled" : ""}>${Object.entries(META.atmos_kinds).map(([k, n]) => `<option value="${k}" ${k === cur ? "selected" : ""}>${esc(n)}</option>`).join("")}</select></div>`;
}

function fxTag(s) {
  const parts = [META.effect_ru[s.effect], META.sfx_ru[s.sfx]].filter(Boolean);
  return (s.speaker_name ? `<div class="tag-mod">🗣 Говорит: ${esc(s.speaker_name)}</div>` : "")
    + (parts.length ? `<div class="tag-mod">✨ ${esc(parts.join(" + "))}</div>` : "");
}

const SPEEDS = [1, 1.05, 1.1, 1.15, 1.2, 1.25, 1.3, 1.4, 1.5];
function speedRow(d, kind, r) {
  const busy = d.job.status === "running";
  const cur = r.speed || 1, base = r.orig_duration || r.duration;
  return `<div class="row" style="margin-top:8px"><span>Скорость:</span>
    <select class="speed-sel" data-kind="${kind}" style="width:auto" ${busy ? "disabled" : ""}>${SPEEDS.map(s => `<option value="${s}" ${s === cur ? "selected" : ""}>${s === 1 ? "Обычная (оригинал)" : "Быстрее в " + s + " раза"} · ${fmtTime(base / s)}</option>`).join("")}</select>
    <button class="sm speed-apply" ${busy ? "disabled" : ""}>Применить</button><span class="muted small">картинка и голос ускоряются вместе, голос не становится писклявым; бесплатно, оригинал сохраняется</span></div>`;
}

const IMP_OP = { replace: "Переписать абзац", insert_after: "Добавить новый абзац", delete: "Убрать абзац" };
function improveBox(d) {
  const r = d.improve;
  const list = r ? (r.edits || []).map((e, i) => `<div class="imp-e">
      <label class="check" style="margin:0"><input type="checkbox" class="imp-pick" data-i="${i}" checked> <b>${IMP_OP[e.op] || ""} ${e.op === "insert_after" ? (e.index ? `после ${e.index}-го` : "в самое начало") : e.index}</b></label>
      <div class="small" style="margin:4px 0">${nl(e.why_ru)}</div>
      ${e.old ? `<div class="imp-old small">${esc(e.old)}</div>` : ""}
      ${e.op !== "delete" ? `<div class="imp-new small">${esc(e.text)}</div>${e.text_ru && e.text_ru !== e.text ? `<div class="muted small">${esc(e.text_ru)}</div>` : ""}` : ""}
    </div>`).join("") : "";
  return `<div class="card" style="margin-top:12px;background:var(--bg)"><h3 style="margin-top:0">✨ Улучшить только слабые места</h3>
    <p class="muted small">ИИ сверит текст с правилами ниши и разборами из хранилища и перепишет только слабые абзацы, остальное не тронет. Вы отмечаете, какие правки взять, они вставляются в текст выше, потом нажимаете «Сохранить мой текст». Картинки нетронутых абзацев останутся прежними. Стоит несколько центов.</p>
    <textarea id="imp-note" rows="2" style="width:100%" placeholder="Что поправить, если хотите подсказать (необязательно). Например: закрыть вопрос из хука, усилить финал"></textarea>
    <div class="row" style="margin-top:6px"><button id="imp-go">✨ Найти и исправить слабые места</button></div>
    ${r ? `<div style="margin-top:10px"><p>${nl(r.summary_ru)}</p>
      ${list || `<p class="muted">Слабых мест не нашлось, текст можно оставить как есть.</p>`}
      ${list ? `<div class="row" style="margin-top:8px"><button class="primary" id="imp-apply">Вставить отмеченные правки в текст</button></div>` : ""}
      ${(r.titles || []).length ? prSection("Варианты названия", prList(r.titles.map(t => t.title + (t.title_ru && t.title_ru !== t.title ? ` (${t.title_ru})` : "")))) : ""}
      ${(r.thumbnail_texts || []).length ? prSection("Варианты надписи на превью", prList(r.thumbnail_texts)) : ""}</div>` : ""}
  </div>`;
}

function applyEdits(text, edits) {
  let paras = text.split(/\n\s*\n/).map(p => p.trim()).filter(Boolean);
  const norm = t => t.replace(/\s+/g, " ").trim();
  const find = t => paras.findIndex(p => norm(p) === norm(t));
  let missed = 0;
  for (const e of edits) {
    if (e.op === "insert_after") {
      const at = e.anchor ? find(e.anchor) : -1;
      if (e.anchor && at < 0) { missed++; continue; }
      paras.splice(at + 1, 0, e.text.trim());
    } else {
      const at = find(e.old);
      if (at < 0) { missed++; continue; }
      if (e.op === "delete") paras.splice(at, 1); else paras[at] = e.text.trim();
    }
  }
  return { text: paras.join("\n\n"), missed };
}

function musicBox(d, r) {
  const o = d.job.options || {}, busy = d.job.status === "running";
  const vol = o.music_volume ?? META.music_volume ?? 0.12;
  return `<details class="musicbox" style="margin-top:10px"><summary><b>🎵 Музыка: ${r.music ? esc(r.music) : "без музыки"}</b></summary>
    <p class="muted small">Выберите трек из раздела «Музыка» или загрузите свой. Ролик и шортс пересоберутся бесплатно, картинки и голос не меняются. Выбранный трек остаётся и при следующих пересборках.</p>
    <select class="mb-track"><option value="">Подобрать автоматически по стилю ролика</option><option value="none" ${o.music_track === "none" ? "selected" : ""}>Без музыки</option></select>
    <audio class="mb-audio" controls preload="none" style="display:none;margin-top:6px;width:100%"></audio>
    <label class="f">Какую музыку хотите <span class="hint">своими словами, можно по-русски: «спокойное пианино», «эпичный оркестр без барабанов», «лоу-фай, медленно». Пусто — программа выберет по сценарию${d.project && d.project.music_style ? ` (сейчас из проекта: «${esc(d.project.music_style)}»)` : ""}</span></label>
    <input type="text" class="mb-style" value="${esc(o.music_style || "")}" placeholder="${esc((d.project && d.project.music_style) || "например: спокойное пианино, медленно")}">
    <label class="f">Громкость музыки: <b class="mb-vv">${Math.round(vol * 100)}%</b> <span class="hint">обычно 8–15%, голос всегда главнее</span></label>
    <input type="range" class="mb-vol" min="0" max="0.4" step="0.01" value="${esc(vol)}">
    <div class="row" style="margin-top:8px"><button class="primary mb-go" ${busy ? "disabled" : ""}>🎵 Поставить и пересобрать</button>
      <button class="mb-gen" ${busy ? "disabled" : ""} title="ElevenLabs сочинит новый трек в этом стиле, около $0.3–1">🎼 Сочинить новую в этом стиле</button>
      <label class="btn" style="display:inline-block;cursor:pointer">📤 Загрузить свой трек<input type="file" class="mb-up" accept="audio/*" style="display:none"></label>
      ${busy ? `<span class="muted small">Сначала дождитесь конца работы или поставьте на паузу</span>` : ""}</div></details>`;
}

function revoiceBox(d) {
  const o = d.job.options || {}, busy = d.job.status === "running";
  const num = (k, lo, hi, st, label) => `<div><label class="f">${label}</label><input type="number" class="rv-${k}" step="${st}" min="${lo}" max="${hi}" value="${esc(o[k] ?? "")}" placeholder="как в проекте"></div>`;
  return `<details class="revoice" style="margin-top:10px"><summary><b>🎙 Сменить голос и пересобрать</b></summary>
    <p class="muted small">Озвучка делается заново выбранным голосом, ролик и шортс пересобираются. Сценарий, картинки и анимации остаются, платите только за новую озвучку. Реплики героев со своими голосами звучат как раньше.</p>
    <div class="row" style="gap:6px;flex-wrap:nowrap"><select class="rv-voice"><option value="">Тот же голос (${esc(o.voice_name || "как в проекте")})</option></select><button class="sm rv-play" title="Послушать голос">▶</button></div>
    <div class="grid2">${num("voice_tempo", 0.8, 1.6, 0.05, "Темп речи (0.8–1.6): быстрее сверх 1.2. Если меняете только его, это бесплатно")}${num("voice_speed", 0.7, 1.2, 0.01, "Скорость голоса (0.7–1.2)")}${num("voice_stability", 0, 1, 0.05, "Стабильность (0–1), меньше — эмоциональнее")}${num("voice_style", 0, 1, 0.05, "Выразительность (0–1)")}${num("voice_similarity", 0, 1, 0.05, "Похожесть на оригинал (0–1)")}</div>
    <div class="row" style="margin-top:8px"><button class="primary rv-go" ${busy ? "disabled" : ""}>🎙 Переозвучить и пересобрать</button>${busy ? `<span class="muted small">Сначала дождитесь конца работы или поставьте на паузу</span>` : ""}</div>
    <audio class="rv-audio"></audio></details>`;
}

function fxRow(d) {
  const busy = d.job.status === "running", o = d.job.options;
  return `<div class="row" style="margin-top:8px">
    <label class="check" style="margin:0"><input type="checkbox" class="asm-opt" data-k="graphics" ${o.graphics ? "checked" : ""} ${busy ? "disabled" : ""}> Анимации данных</label>
    <label class="check" style="margin:0"><input type="checkbox" class="asm-opt" data-k="subs_smart" ${o.subs_smart ? "checked" : ""} ${busy ? "disabled" : ""}> Субтитры в свободном месте</label>
    <span class="muted small">видео пересоберётся</span></div>
  <div class="row" style="margin-top:8px"><span>Эффекты:</span>
    <select class="fx-sel" style="max-width:420px" ${busy ? "disabled" : ""}>${Object.entries(META.fx_modes).map(([k, n]) => `<option value="${k}" ${k === d.fx_mode ? "selected" : ""}>${esc(n)}</option>`).join("")}</select>
    <button class="sm fx-apply" ${busy ? "disabled" : ""}>Применить</button><span class="muted small">видео пересоберётся бесплатно</span></div>
  <div class="row" style="margin-top:8px"><span>Атмосфера:</span>
    <select class="atm-mode" style="max-width:420px" ${busy ? "disabled" : ""}>${[...Object.entries(META.atmos_modes), ...Object.entries(META.atmos_kinds).filter(([k]) => k !== "none").map(([k, n]) => [k, `${n}: на весь ролик`])].map(([k, n]) => `<option value="${k}" ${k === d.atmos_mode ? "selected" : ""}>${esc(n)}</option>`).join("")}</select>
    <button class="sm atm-apply" ${busy ? "disabled" : ""}>Применить</button><span class="muted small">туман, дождь, снег поверх картинок; у каждой сцены можно поменять на шаге «Сцены»</span></div>
  ${d.format !== "short" ? `<div class="row" style="margin-top:8px"><span>Моушен:</span>
    <select class="mot-mode" style="max-width:420px" ${busy ? "disabled" : ""}>${Object.entries(META.motion_modes).map(([k, n]) => `<option value="${k}" ${k === d.motion_mode ? "selected" : ""}>${esc(n)}</option>`).join("")}</select>
    <button class="sm mot-apply" ${busy ? "disabled" : ""}>Применить</button><span class="muted small">карты, даты, графики, сравнения, цитаты и списки вместо некоторых картинок; включить или выключить у сцены можно на шаге «Сцены»</span></div>` : ""}`;
}

function subsRow(d, kind, fileKey, fileName) {
  const on = d.subs[kind];
  const busy = d.job.status === "running" && d.job.stage === (kind === "video" ? "video" : "short_video");
  return `<div class="row" style="margin-top:10px">
    <span>Субтитры на видео: <b>${on ? "включены" : "выключены"}</b></span>
    <button class="sm" data-subs="${kind}:${on ? 0 : 1}" ${busy ? "disabled title=\"Подождите, пока ролик доделается\"" : ""}>${on ? "Выключить субтитры" : "Включить субтитры"}</button>
    ${on ? `<span>Высота:</span><select class="subs-pos" data-kind="${kind}" style="max-width:240px" ${busy ? "disabled" : ""}>${Object.entries(META.subs_positions || {}).map(([k, n]) => `<option value="${k}" ${k === d.subs_pos ? "selected" : ""}>${esc(n)}</option>`).join("")}</select>` : ""}
    ${d.files[fileKey] ? `<a class="small" href="/files/${d.job.id}/output/${fileName}" download>⬇ Файл субтитров .srt</a>` : ""}
  </div>`;
}

function checksHtml(c) {
  if (!c) return "";
  const items = [
    [c.length_ok, `Длина: ${c.word_count} слов ≈ ${c.minutes} мин (цель ${c.target_words} слов)`],
    [c.bad_openers.length === 0, c.bad_openers.length ? `Начало со штампа: «${c.bad_openers.join(", ")}»` : "Нет штампов в начале («welcome back», «in this video»)"],
    [c.long_sentences <= 3, `Длинных предложений (больше 30 слов): ${c.long_sentences}`],
    ...(c.avg_sentence !== undefined ? [[!c.choppy, c.choppy ? `Текст рубленый: в среднем ${c.avg_sentence} слова в предложении, на слух такое непонятно` : `Предложения нормальной длины: в среднем ${c.avg_sentence} слов`]] : []),
  ];
  return `<div class="small" style="margin:8px 0"><b>Автоматические проверки:</b> ${items.map(([ok, t]) => `<div>${ok ? "✅" : "⚠️"} ${esc(t)}</div>`).join("")}
    <div class="en">Первая фраза: “${esc(c.first_sentence)}”</div></div>`;
}

// ------------------------------------------------------------------ settings
let STYLE_PRESETS = {};  // picture styles, filled from the server (META.image_styles)
function styleDesc(text) {
  if (!text) return `<span class="muted">Стиль не выбран: портрет будет в стиле из общих настроек.</span>`;
  const v = Object.values(STYLE_PRESETS).find(x => x.text === text);
  return v ? `Выбрано: <b>${esc(v.name)}</b> — ${esc(v.desc)}` : `Выбрано: <b>свой стиль</b> (текст ниже)`;
}

let SETTINGS_CACHE = null;
api("/api/settings").then(s => SETTINGS_CACHE = s).catch(() => { });

// Keeps a model typed by hand earlier selectable after the field became a list.
const withCurrent = (cur, opts) => cur && !opts.some(([v]) => v === cur) ? [[cur, cur], ...opts] : opts;

// Cards whose heading opens and closes them; which ones are open is remembered per page.
function foldCards(root, key) {
  root.querySelectorAll(":scope > .card").forEach(c => {
    const h = c.querySelector(":scope > h2"); if (!h) return;
    const k = `ay_fold:${key}:${h.textContent.replace(/\(\d+\)/, "").trim()}`;
    c.classList.add("fold"); c.classList.toggle("open", lsGet(k) === "1");
    h.onclick = () => lsSet(k, c.classList.toggle("open") ? "1" : "");
  });
}
function field(key, label, s, opts = {}) {
  const hint = opts.hint ? `<span class="hint">${opts.hint}</span>` : "";
  if (opts.type === "secret") return `<label class="f">${label}${hint}</label><input type="password" data-k="${key}" placeholder="${s[key] ? "сохранён: " + esc(s[key]) + " (вставьте новый, чтобы заменить)" : "вставьте ключ сюда"}" autocomplete="off">`;
  if (opts.type === "select") return `<label class="f">${label}${hint}</label><select data-k="${key}">${opts.options.map(([v, n]) => `<option value="${esc(v)}" ${String(s[key]) === String(v) ? "selected" : ""}>${esc(n)}</option>`).join("")}</select>`;
  if (opts.type === "textarea") return `<label class="f">${label}${hint}</label><textarea data-k="${key}">${esc(s[key])}</textarea>`;
  if (opts.type === "range") return `<label class="f">${label}: <span id="rv-${key}">${esc(s[key])}</span>${hint}</label><input type="range" data-k="${key}" min="${opts.min}" max="${opts.max}" step="${opts.step}" value="${esc(s[key])}" oninput="document.getElementById('rv-${key}').textContent=this.value">`;
  return `<label class="f">${label}${hint}</label><input type="${opts.type || "text"}" data-k="${key}" value="${esc(s[key])}" ${opts.list ? `list="${opts.list}"` : ""} step="any">`;
}

async function viewSettings(id) {
  const s = await api("/api/settings"); SETTINGS_CACHE = s;
  const yt = await api("/api/youtube");
  let voices = [];
  const P = META.providers;
  main.innerHTML = `<h1>Настройки</h1>
  <div class="card"><h2>Резервная копия</h2>
    <p class="muted small">Сохраняет настройки, ключи, проекты, персонажей с портретами, серии, шаблоны, каналы, музыку и звуки в папку «Авто ютуб — резерв» на рабочем столе. Там же лежит файл «О программе Авто ютуб» с описанием всего проекта и «Восстановить из копии» для восстановления. Сами ролики в копию не входят (они большие). Копия делается и сама при каждом обновлении.</p>
    <div class="row"><button id="bk-make">💾 Сделать резервную копию сейчас</button><span id="bk-info" class="muted small"></span></div>
  </div>
  <div class="card"><h2>1. Сценарий (нейросеть)</h2>
    <p class="muted small">Пишет темы, структуру, текст и сама его проверяет. Нужен ключ API (это не то же самое, что подписка ChatGPT Plus или Claude Pro: API оплачивается отдельно по факту, примерно $0.3–1 за ролик).</p>
    ${field("llm_provider", "Какую нейросеть использовать", s, { type: "select", options: [["anthropic", "Claude (Anthropic) — рекомендую для историй"], ["openai", "GPT (OpenAI)"]] })}
    <div class="grid2"><div>
      ${field("anthropic_key", "Ключ Anthropic", s, { type: "secret", hint: `Получить: <a href="https://console.anthropic.com/settings/keys" target="_blank">console.anthropic.com</a>` })}
      ${field("anthropic_model", "Модель Claude", s, { type: "select", options: withCurrent(s.anthropic_model, [["claude-opus-5-5", "Claude Opus 5.5 — лучшее качество (дороже)"], ["claude-sonnet-5-5", "Claude Sonnet 5.5 — почти так же хорошо, вдвое дешевле (рекомендую)"], ["claude-haiku-5-5", "Claude Haiku 5.5 — очень дёшево, тексты проще"]]) })}
      ${field("opus_script_only", "Где работает Opus", s, { type: "select", options: [["true", "Только сам сценарий и его редактура, остальное (темы, план, описания картинок, тексты для YouTube) делает Sonnet: вдвое дешевле (рекомендую)"], ["false", "Везде, на всех шагах (дороже)"]], hint: "Действует, если выше выбран Opus" })}
      ${field("bait_pass", "Цепляющее начало, название и фраза для превью", s, { type: "select", options: [["true", "Да: после редактора ИИ отдельно делает первые 1–3 фразы, название и фразу на превью максимально цепляющими для этого рассказа (центы за ролик)"], ["false", "Нет"]] })}
      ${field("subscribe_ask", "Просьба подписаться в длинных роликах", s, { type: "select", options: [["true", "Да: на 30–40 секунде диктор просит подписаться и поставить лайк, чтобы поддержать новый канал"], ["false", "Нет"]] })}
      ${field("anthropic_effort", "Насколько глубоко думать", s, { type: "select", options: [["medium", "Средне (дешевле)"], ["high", "Глубоко (рекомендую)"], ["xhigh", "Очень глубоко (дороже)"]] })}
    </div><div>
      ${field("openai_key", "Ключ OpenAI", s, { type: "secret", hint: `Получить: <a href="https://platform.openai.com/api-keys" target="_blank">platform.openai.com</a>. Этот же ключ подходит для картинок OpenAI.` })}
      ${field("openai_model", "Модель GPT", s, { type: "select", options: withCurrent(s.openai_model, [["gpt-5", "GPT-5"], ["gpt-5-mini", "GPT-5 mini — дешевле"]]) })}
    </div></div>
    <div class="row" style="margin-top:12px"><button id="t-llm">Проверить нейросеть</button><span id="t-llm-r" class="muted small"></span></div>
    <h3>Качество сценария</h3>
    ${field("niche", "Ниша канала по умолчанию", s, { type: "textarea", hint: "Можно по-русски. Например: «мистические реальные истории», «истории выживания», «загадки истории»." })}
    <div class="grid2"><div>
      ${field("duration_min", "Длительность по умолчанию, минут", s, { type: "number" })}
      ${field("ideas_count", "Сколько тем придумывать за раз", s, { type: "number", hint: "От 3 до 10. Меньше тем — дешевле. На странице ролика можно попросить ещё столько же кнопкой «Ещё темы»" })}
      ${field("quality_threshold", "Порог качества (средняя оценка из 10)", s, { type: "number", hint: "Ниже порога редактор переписывает текст. 8 — строго, 7 — мягче." })}
    </div><div>
      ${field("min_criterion_score", "Минимум по любому пункту чек-листа", s, { type: "number" })}
      ${field("max_editor_rounds", "Сколько раз максимум переписывать", s, { type: "number" })}
    </div></div>
  </div>

  <div class="card"><h2>2. Озвучка (ElevenLabs)</h2>
    ${field("elevenlabs_key", "Ключ ElevenLabs", s, { type: "secret", hint: `Получить: <a href="https://elevenlabs.io/app/settings/api-keys" target="_blank">elevenlabs.io → Settings → API Keys</a>` })}
    <details class="el-keys" style="margin-top:8px"><summary>🔑 Запасные ключи ElevenLabs: когда на одном кончаются кредиты, программа сама берёт следующий</summary>
      <p class="muted small">Добавьте ключи других аккаунтов ElevenLabs. Озвучка идёт с рабочего ключа; как только на нём кончатся кредиты, программа сама переключится на следующий и продолжит с той же сцены. Голоса из библиотеки программа сама добавит в новый аккаунт. Свой клонированный голос есть только в том аккаунте, где его сделали.</p>
      <div data-el-list class="small">Загружаю…</div>
      <div class="row" style="margin-top:6px;gap:6px"><input type="password" data-el-new placeholder="вставьте ещё один ключ ElevenLabs (sk_…)" autocomplete="off" style="max-width:420px"><button class="sm primary" data-el-add type="button">＋ Добавить ключ</button></div>
    </details>
    <div class="row" style="margin-top:10px"><button id="load-voices">Загрузить список голосов</button><span id="el-acc" class="muted small"></span></div>
    <label class="f">Голос <span class="hint">Сейчас: ${esc(s.elevenlabs_voice_name)}. Для историй хорошо подходят спокойные низкие мужские голоса (George, Brian, Daniel).</span></label>
    <select id="voice-sel"><option value="${esc(s.elevenlabs_voice_id)}">${esc(s.elevenlabs_voice_name)}</option></select>
    <div class="row" style="margin-top:6px"><button class="sm" id="voice-preview">▶ Образец голоса</button><button class="sm primary" id="voice-lib">🌍 Библиотека голосов (любой язык)</button><audio id="voice-audio"></audio></div>
    <label class="f">…или ID голоса вручную <span class="hint">Если список голосов не загружается: на elevenlabs.io откройте голос, нажмите «…» → Copy voice ID и вставьте сюда. Если ошибка про разрешение (permission), откройте на сайте ElevenLabs ваш API-ключ → Edit и включите доступ «Voices: Read» и «User: Read», либо создайте новый ключ без ограничений.</span></label>
    <input type="text" id="voice-id" placeholder="например JBFqnCBsd6RMkjVDRZzb">
    <div id="voice-marks"></div>
    ${field("voice_provider", "Через что озвучивать", s, { type: "select", options: [["elevenlabs", "ElevenLabs напрямую, по вашему ключу"], ["royal", "Через RoyalTechno: те же голоса ElevenLabs в 5–10 раз дешевле ($0.03 за 1000 символов), ключ RoyalTechno"]], hint: "Через RoyalTechno доступны стандартные голоса и голоса из библиотеки ElevenLabs, но не все: если голос не подойдёт, программа скажет. Ваших личных клонов голоса там нет. Субтитры ложатся по паузам в речи" })}
    ${s.voice_provider === "royal" ? field("royal_key", "Ключ RoyalTechno", s, { type: "secret", hint: `Создаётся в Телеграм-боте <a href="https://t.me/royaltechno_ai_bot" target="_blank">@royaltechno_ai_bot</a> командой /api_key_new` }) : ""}
    ${field("elevenlabs_model", "Модель озвучки", s, { type: "select", options: META.tts_models.map(m => [m.id, m.name]) })}
    ${field("voice_tags", "Интонации по сюжету (только для модели v3)", s, { type: "select", options: [["true", "Да: ИИ расставляет в тексте пометки шёпот, удивление, грусть и т. п. там, где этого требует сюжет (центы за ролик)"], ["false", "Нет: голос читает текст как есть"]] })}
    <div class="grid2"><div>
      ${field("voice_stability", "Стабильность", s, { type: "range", min: 0, max: 1, step: 0.05, hint: "Меньше — эмоциональнее, больше — ровнее" })}
      ${field("voice_similarity", "Похожесть на оригинал", s, { type: "range", min: 0, max: 1, step: 0.05 })}
    </div><div>
      ${field("voice_style", "Выразительность", s, { type: "range", min: 0, max: 1, step: 0.05 })}
      ${field("voice_speed", "Скорость речи", s, { type: "range", min: 0.7, max: 1.2, step: 0.01 })}
    </div></div>
    <div class="row" style="margin-top:12px"><button id="t-tts">Проверить озвучку (сохраните настройки перед проверкой)</button><audio id="t-tts-a" controls style="display:none"></audio></div>
  </div>

  <div class="card"><h2>3. Картинки</h2>
    <p class="muted small">Выберите сервис и вставьте его ключ. Можно вставить ключи нескольких сервисов и переключаться.</p>
    ${Object.entries(P).map(([id, p]) => `<div class="provider ${s.image_provider === id ? "sel" : ""}">
      <label class="check" style="margin:0"><input type="radio" name="imgprov" value="${id}" ${s.image_provider === id ? "checked" : ""}> <b>${esc(p.name)}</b> <a class="small" href="${p.signup}" target="_blank">получить ключ</a></label>
      <div class="grid2">
        <div>${id === "openai" ? `<p class="small muted">Используется ключ OpenAI из раздела «Сценарий».</p>` : field(p.key_field, "Ключ", s, { type: "secret" })}</div>
        <div>${field(p.model_field, "Модель", s, { type: "select", options: p.models.map(m => [m.id, `${m.name} (~$${m.price} за картинку)`]) })}</div>
      </div>
      <div class="row"><button class="sm" data-timg="${id}">Проверить этот сервис</button></div>
    </div>`).join("")}
    ${field("openai_image_quality", "Качество для OpenAI", s, { type: "select", options: [["low", "Низкое (дёшево)"], ["medium", "Среднее"], ["high", "Высокое (дорого)"]] })}
    ${field("image_style", "Стиль всех картинок", s, { type: "textarea", hint: "Добавляется к каждой картинке, чтобы весь ролик был в одном стиле. По-английски. Можно взять готовый стиль кнопкой ниже." })}
    <div class="row" style="margin-top:6px">${Object.entries(STYLE_PRESETS).map(([k, v]) => `<button class="sm" data-style="${k}" title="${esc(v.desc)}">${esc(v.name)}</button>`).join("")}</div>
    ${field("images_manual", "Кто делает картинки", s, { type: "select", options: [["true", "Я сам в другом сервисе: программа останавливается после озвучки и ждёт мои картинки, сама ничего не рисует"], ["false", "Программа рисует сама через сервис выше"]] })}
    ${field("auto_check", "Автоконтроль логики и картинок", s, { type: "select", options: [["true", "Включён: ИИ проверяет описания всех сцен и каждую готовую картинку, явные ошибки перерисовывает сам (~$0.05–0.15 на шортс, ~$0.3–0.7 на длинный)"], ["false", "Выключен: дешевле, ошибки придётся ловить самому"]] })}
    ${field("ref_model", "Модель для картинок по образцу (персонажи, предметы, одинаковые места)", s, { type: "select", options: [["nano", "Nano Banana: лучше всего держит лица и места, ~$0.04 за картинку"], ["flux2", "Экономно: FLUX.2 Dev Edit, когда образцов 1–2 (место ~$0.025, место и персонаж ~$0.036), иначе Nano Banana; крупные планы и детали без персонажей без образца"]] })}
    ${field("char_reference", "Персонажи на картинках по портрету", s, { type: "select", options: [["true", "Да, как на портрете (fal.ai ~$0.04, а если выбран RoyalTechno, то через него)"], ["false", "Нет, только по текстовому описанию (дешевле, но похожесть хуже)"]] })}
    <div id="t-img-r" style="margin-top:10px"></div>
  </div>

  <div class="card"><h2>4. Видео</h2>
    <div class="grid2"><div>
      ${field("words_per_scene", "Слов на одну картинку (длинное видео)", s, { type: "number", hint: "22 слова ≈ 9 секунд на картинку" })}
      ${field("short_words_per_scene", "Слов на одну картинку (шортс)", s, { type: "number" })}
      ${field("motion_strength", "Сила движения камеры", s, { type: "range", min: 0.05, max: 0.35, step: 0.01 })}
      ${field("music_volume", "Громкость фоновой музыки", s, { type: "range", min: 0, max: 0.4, step: 0.01 })}
    </div><div>
      ${field("fps", "Кадров в секунду", s, { type: "select", options: [[24, "24"], [30, "30"]] })}
      ${field("scene_gap", "Пауза между сценами, сек", s, { type: "number" })}
      ${field("paragraph_gap", "Пауза между абзацами, сек", s, { type: "number" })}
      ${field("image_parallel", "Картинок одновременно", s, { type: "number" })}
      ${field("render_parallel", "Фрагментов видео одновременно", s, { type: "number", hint: "Для M1 подходит 3" })}
      ${field("jobs_parallel", "Роликов одновременно", s, { type: "number", hint: "Сколько роликов делается сразу: темы, текст, озвучка, картинки, анимация. Монтаж всё равно идёт по одному. От 1 до 5, обычно 3" })}
    </div></div>
    <h3>Анимация сцен</h3>
    <p class="muted small">Нейросеть превращает картинку сцены в короткий клип с движением (люди, огонь, вода, камера). Работает через fal.ai (нужен ключ fal.ai из раздела «Картинки») или через RoyalTechno (ключ ниже, тот же, что для картинок и озвучки). Стоит денег за каждую секунду, поэтому выгоднее оживлять только начало ролика и ключевые моменты. Здесь значения по умолчанию, у каждого ролика можно выбрать своё.</p>
    <div class="grid2"><div>
      ${field("video_model", "Модель анимации", s, { type: "select", options: META.video_models.map(m => [m.id, `${m.name}: ~$${m.clip} за одну сцену ($${m.price} за секунду клипа)`]) })}
      ${field("anim_mode", "Что оживлять по умолчанию", s, { type: "select", options: animModes(), hint: "Для роликов без проекта. У проекта своя настройка в его карточке" })}
      ${field("anim_short", "Оживлять шортс", s, { type: "select", options: [["false", "Нет"], ["true", "Да, столько же первых сцен шортса"]] })}
    </div><div>
      ${field("royal_key", "Ключ RoyalTechno (для моделей «RoyalTechno»)", s, { type: "secret", hint: `Создаётся в Телеграм-боте <a href="https://t.me/royaltechno_ai_bot" target="_blank">@royaltechno_ai_bot</a> командой /api_key_new, там же пополнение. Это сторонний перепродавец с очень низкими ценами: держите на балансе немного, $5–10` })}
      ${field("anim_count", "Сколько сцен оживлять", s, { type: "number", hint: "«Первые сцены»: первые N. «Начало и ключевые моменты»: треть в начале, остальное на поворотах сюжета. Одна сцена ≈ цена одного клипа" })}
    </div></div>
    <div class="row" style="margin-top:10px"><button id="t-anim">▶ Проверить анимацию (одна картинка + один клип, ~$0.4)</button><span id="t-anim-r" class="muted small"></span></div>
    <video id="t-anim-v" controls loop style="display:none;max-width:560px;margin-top:8px"></video>
    <h3>Эффекты</h3>
    <p class="muted small">Звук перелистывания на смене картинок, удары, «вжух» на переходах, резкие наезды и тряска в нужных местах сценария. Можно положить свои звуки (mp3 или wav) в папки <code>${esc(META.data_dir)}/sfx/whoosh</code>, <code>impact</code> и <code>swoosh</code>: программа возьмёт их вместо встроенных.</p>
    <div class="grid2"><div>
      ${field("fx_mode", "Эффекты по умолчанию", s, { type: "select", options: Object.entries(META.fx_modes), hint: "Для роликов без проекта. У проекта своя настройка в его карточке" })}
    </div><div>
      ${field("sfx_volume", "Громкость звуковых эффектов", s, { type: "range", min: 0, max: 1, step: 0.05 })}
    </div></div>
    <h3>Моушен: карты, даты, графики, цитаты</h3>
    <p class="muted small">Там, где в сценарии важны места или даты, программа вместо картинки показывает анимацию: карта подлетает к региону, прорисовывает границы стран, маршрут и метки, линия времени с датами, график, сравнение двух сторон, цитата или список причин. Переход с предыдущей картинки плавный, появление элементов озвучено мягкими щелчками. Цифры берутся только из сценария. Картинки для этих сцен не нужны. Рисуется бесплатно, нужен один короткий запрос к нейросети на ролик.</p>
    <div class="grid2"><div>
      ${field("motion_mode", "Моушен по умолчанию", s, { type: "select", options: Object.entries(META.motion_modes) })}
    </div><div></div></div>
    <h3>Атмосфера: туман, дождь, снег</h3>
    <p class="muted small">ИИ при описании сцен отмечает погоду и настроение по сценарию, и программа рисует их поверх картинки: туман, дождь, грозу с молниями, снег, пыль, искры от огня, зерно старой плёнки. Под такими сценами тихо звучит дождь, ветер или треск огня. Это бесплатно. Эффект любой сцены можно поменять на шаге «Сцены».</p>
    <div class="grid2"><div>
      ${field("atmos_mode", "Атмосфера по умолчанию", s, { type: "select", options: Object.entries(META.atmos_modes) })}
    </div><div>
      ${field("atmos_volume", "Громкость дождя, ветра и огня", s, { type: "range", min: 0, max: 1, step: 0.05 })}
    </div></div>
    <details class="atm-lib" style="margin-top:6px"><summary>🎞 Свои футажи и звуки для эффектов (необязательно)</summary>
      <p class="muted small">Программа рисует эффекты сама. Если хотите, чтобы было как в кино, положите сюда настоящие видео дождя, тумана, снега, искр <b>на чёрном фоне</b> (бесплатные есть на pixabay.com и mixkit.co, ищите «rain overlay», «fog overlay», «snow overlay black background»). Чёрный фон станет прозрачным. Звук (mp3, wav) заменит встроенный шум.</p>
      <div data-atm-list>Загружаю…</div></details>
    <h3>Субтитры</h3>
    <p class="muted small">Текст озвучки появляется на видео в такт голосу. Это значение по умолчанию для новых роликов: у каждого ролика субтитры можно включить или выключить отдельно. Файл .srt для YouTube создаётся всегда.</p>
    <div class="grid2"><div>
      ${field("subtitles_long", "Субтитры на длинном видео", s, { type: "select", options: [["false", "Выключены"], ["true", "Включены"]], hint: "Для роликов без проекта. У проекта своя настройка в его карточке" })}
    </div><div>
      ${field("cta_short", "Призыв на шортсах", s, { type: "select", options: Object.entries(META.cta_modes), hint: "Анимированные кнопки «Подписаться» и «Нравится» в стиле YouTube во второй половине шортса. Для роликов без проекта; у проекта своя настройка в его карточке" })}
      ${field("cta_lang", "Язык кнопок призыва", s, { type: "select", options: Object.entries(META.cta_langs), hint: "Для роликов без проекта" })}
      ${field("subtitles_short", "Субтитры на шортсе", s, { type: "select", options: [["true", "Включены (рекомендую: шортсы часто смотрят без звука)"], ["false", "Выключены"]], hint: "Для роликов без проекта. У проекта своя настройка в его карточке" })}
      ${field("subs_pos", "Высота субтитров", s, { type: "select", options: Object.entries(META.subs_positions || {}), hint: "можно поменять и у готового ролика, на его странице" })}
    </div></div>
  </div>
  <div class="card" id="ytcard"><h2>5. YouTube: автоматическая загрузка</h2>
    <p class="muted small">Можно подключить несколько каналов. У каждого канала свои ниша, голос и стиль картинок, а ещё настройка «загружать сам, когда ролик готов».</p>
    ${yt.last_error ? `<div class="banner bad">${nl(yt.last_error)}</div>` : ""}
    <details ${yt.has_client ? "" : "open"}><summary><b>Как подключить (один раз, ~15 минут)</b></summary>
      <ol class="small">
        <li>Откройте <a href="https://console.cloud.google.com/" target="_blank">console.cloud.google.com</a> и войдите своим Google-аккаунтом. Вверху нажмите выбор проекта → «New project», назовите, например, «Avto YouTube» → Create.</li>
        <li>Откройте <a href="https://console.cloud.google.com/apis/library/youtube.googleapis.com" target="_blank">YouTube Data API v3</a> и нажмите <b>Enable</b>.</li>
        <li>Так же включите <a href="https://console.cloud.google.com/apis/library/youtubeanalytics.googleapis.com" target="_blank">YouTube Analytics API</a> (<b>Enable</b>): по нему программа узнаёт, сколько процентов роликов досматривают, и учится, что работает.</li>
        <li>Откройте <a href="https://console.cloud.google.com/auth/overview" target="_blank">Google Auth Platform</a> → <b>Get started</b>: имя приложения «Avto YouTube», ваш email, Audience: <b>External</b>, снова email → Create.</li>
        <li>Там же, раздел <b>Audience</b>: нажмите <b>Publish app</b> и подтвердите (статус станет «In production»). Без этого Google будет отключать доступ каждые 7 дней. Проверка Google для личного пользования не нужна.</li>
        <li>Раздел <b>Clients</b> → <b>Create client</b> → Application type: <b>Desktop app</b> → Create → <b>Download JSON</b>.</li>
        <li>Загрузите этот файл кнопкой ниже.</li>
        <li>Нажмите «Подключить канал». Google покажет «Google hasn't verified this app»: нажмите <b>Advanced</b> («Дополнительно») → <b>Go to Avto YouTube</b> → выберите канал → отметьте все галочки → Continue.</li>
        <li>Чтобы YouTube принимал своё превью, подтвердите канал по телефону: <a href="https://www.youtube.com/verify" target="_blank">youtube.com/verify</a>.</li>
      </ol></details>
    <div class="row" style="margin:12px 0">
      <input type="file" id="ytfile" accept=".json,application/json" style="display:none">
      <button id="ytfile-btn">${yt.has_client ? "✅ Файл ключа Google загружен (заменить)" : "Загрузить файл ключа Google (JSON)"}</button>
      <a class="btn primary" href="/api/youtube/login" ${yt.has_client ? "" : 'style="pointer-events:none;opacity:.5"'}>＋ Подключить канал</a>
    </div>
    <p class="muted small">Каждый канал подключается отдельно. Если несколько каналов на одном Google-аккаунте, Google спросит, какой из них выбрать.</p>
    ${yt.channels.map(c => `<div class="provider" data-ch="${c.id}">
      <div class="row">${c.thumb ? `<img src="${esc(c.thumb)}" style="width:36px;height:36px;border-radius:50%">` : ""}<b class="grow">${esc(c.title)}</b>
        ${c.needs_login ? `<span class="badge error">нужно войти заново</span>` : `<span class="badge done">подключён</span>`}</div>
      ${c.needs_login ? `<div class="banner warn small">Доступ к каналу закончился. Нажмите «Подключить канал» и выберите этот канал ещё раз.</div>` : ""}
      <details><summary class="small" style="cursor:pointer;margin-top:6px">Настройки канала</summary>
        <label class="f">Ниша канала <span class="hint">Пусто — как в общих настройках</span></label><textarea data-p="niche">${esc(c.profile.niche)}</textarea>
        <label class="f">Голос</label><select data-p="voice_id" class="ch-voice"><option value="">Как в общих настройках (${esc(s.elevenlabs_voice_name)})</option>${c.profile.voice_id ? `<option value="${esc(c.profile.voice_id)}" selected>${esc(c.profile.voice_name || c.profile.voice_id)}</option>` : ""}</select>
        <label class="f">Стиль картинок <span class="hint">Пусто — как в общих настройках. По-английски.</span></label><textarea data-p="image_style">${esc(c.profile.image_style)}</textarea>
        <div class="grid2"><div>
          <label class="f">Доступ при загрузке</label><select data-p="privacy">${PRIVACY.map(([v, n]) => `<option value="${v}" ${v === c.profile.privacy ? "selected" : ""}>${n}</option>`).join("")}</select>
        </div><div>
          <label class="f">Категория</label><select data-p="category">${yt.categories.map(([v, n]) => `<option value="${v}" ${v === c.profile.category ? "selected" : ""}>${n}</option>`).join("")}</select>
        </div></div>
        <label class="check"><input type="checkbox" data-p="auto_upload" ${c.profile.auto_upload ? "checked" : ""}> Загружать на этот канал сам, как только ролик готов</label>
        <label class="check"><input type="checkbox" data-p="synthetic" ${c.profile.synthetic ? "checked" : ""}> Отмечать «ИИ-контент» (рекомендую: YouTube требует это для реалистичного ИИ-контента)</label>
        <div class="row"><button class="primary sm ch-save">Сохранить канал</button><button class="sm danger ch-del">Отключить канал</button></div>
      </details></div>`).join("")}
  </div>
  <div class="card" id="igcard"><h2>6. Instagram: выкладка рилсов</h2>
    <p class="muted small">Шортсы выкладываются в Instagram как рилсы с подписью и хэштегами. Видео идёт прямо с вашего компьютера в Instagram. Если вы в России, при выкладке должен быть включён VPN.</p>
    ${s.ig_username ? `<div class="banner ok">✅ Подключён аккаунт <b>@${esc(s.ig_username)}</b>${s.ig_page ? ` (страница Facebook «${esc(s.ig_page)}»)` : ""}. <button class="sm danger" id="ig-off">Отключить</button></div>` : ""}
    <details ${s.ig_username ? "" : "open"}><summary><b>Как подключить (один раз, ~10 минут)</b></summary>
      <p class="small"><b>Важно:</b> выкладывать видео прямо с компьютера Meta разрешает только при подключении через страницу Facebook. Маркер со страницы «Настройка API для входа в Instagram» для выкладки не подходит.</p>
      <ol class="small">
        <li>В приложении Instagram: Настройки → «Тип аккаунта и инструменты» → <b>«Переключиться на профессиональный аккаунт»</b> → «Автор». Это бесплатно.</li>
        <li>Привяжите Instagram к странице Facebook. Если страницы нет, создайте её на <a href="https://www.facebook.com/pages/create" target="_blank">facebook.com/pages/create</a> (подойдёт любое название). В настройках страницы: «Связанные аккаунты» → Instagram → <b>Подключить</b>.</li>
        <li>В кабинете приложения на <a href="https://developers.facebook.com/apps" target="_blank">developers.facebook.com/apps</a> слева: Instagram → <b>«Настройка API для входа на Facebook»</b>. Затем «Настройки приложения» → «Основное»: скопируйте <b>ID приложения</b> и <b>Секрет приложения</b> в поля ниже. Это не те ID и секрет, что на странице Instagram.</li>
        <li>Откройте <a href="https://developers.facebook.com/tools/explorer" target="_blank">Graph API Explorer</a>. Справа выберите своё приложение и «User Token». В «Permissions» добавьте: <b>instagram_basic</b>, <b>instagram_content_publish</b>, <b>pages_show_list</b>, <b>pages_read_engagement</b>, <b>business_management</b>. Нажмите <b>Generate Access Token</b>, войдите, отметьте свою страницу и аккаунт Instagram. Скопируйте токен (начинается с EAA) в поле справа.</li>
        <li>Нажмите «Подключить через Facebook». Программа сама сделает токен постоянным, секрет не сохраняет.</li>
      </ol></details>
    <div class="grid2"><div>
      <label class="f">Секрет приложения</label><input type="password" id="ig-secret" autocomplete="off">
      <label class="f">ID приложения (App ID)</label><input type="text" id="ig-app" autocomplete="off">
    </div><div>
      <label class="f">Маркер доступа (токен)</label><textarea id="ig-token" rows="4" autocomplete="off" placeholder="EAA…"></textarea>
    </div></div>
    <div class="row" style="margin:10px 0"><button id="ig-connect">${s.ig_username ? "Подключить заново через Facebook" : "Подключить через Facebook"}</button><span id="ig-r" class="muted small"></span></div>
    <div class="grid2"><div>
      ${field("ig_auto", "Выкладывать в Instagram сам, как только ролик готов", s, { type: "select", options: [["false", "Нет, только по кнопке на странице ролика"], ["true", "Да, автоматически"]] })}
    </div><div>
      ${field("ig_ai_label", "Отмечать «Создано с помощью ИИ»", s, { type: "select", options: [["true", "Да (рекомендую: Instagram требует это для ИИ-контента)"], ["false", "Нет"]] })}
    </div></div>
  </div>
  <div class="sticky-save"><button class="primary big" id="save">Сохранить настройки</button></div>`;
  $("#ig-connect").onclick = async () => {
    const r = $("#ig-r"); r.textContent = "Подключаю…";
    try {
      const x = await api("/api/instagram/connect", { json: { app_id: $("#ig-app").value, app_secret: $("#ig-secret").value, token: $("#ig-token").value } });
      toast(`Instagram подключён: @${x.username}`); viewSettings("instagram");
    } catch (e) { r.textContent = ""; toast(e.message, true); }
  };
  if ($("#ig-off")) $("#ig-off").onclick = async () => { if (!confirm("Отключить Instagram?")) return; await api("/api/instagram/disconnect", { json: {} }); viewSettings("instagram"); };
  foldCards(main, "set");
  if (id === "instagram") { $("#igcard").classList.add("open"); $("#igcard").scrollIntoView(); }
  if (id === "youtube-ok") toast("Канал подключён");
  if (id && id.startsWith("youtube")) { $("#ytcard").classList.add("open"); $("#ytcard").scrollIntoView(); }
  $("#ytfile-btn").onclick = () => $("#ytfile").click();
  $("#ytfile").onchange = async e => {
    const f = e.target.files[0]; if (!f) return;
    try { await api("/api/youtube/client", { method: "POST", body: f }); toast("Файл ключа загружен. Теперь нажмите «Подключить канал»."); viewSettings("youtube"); }
    catch (err) { toast(err.message, true); }
  };
  main.querySelectorAll("[data-ch]").forEach(box => {
    const cid = box.dataset.ch;
    box.querySelector("details").addEventListener("toggle", async () => {
      const sel = box.querySelector(".ch-voice");
      if (sel.dataset.loaded) return; sel.dataset.loaded = 1;
      addLibButton(sel, "");
      try {
        const vs = voices.length ? voices : (voices = await api("/api/voices"));
        const cur = sel.value;
        sel.innerHTML = sel.options[0].outerHTML + voiceOptions(vs, cur, ""); sel.value = cur;
      } catch (e) { }
    });
    box.querySelector(".ch-save").onclick = async () => {
      const p = {};
      box.querySelectorAll("[data-p]").forEach(i => p[i.dataset.p] = i.type === "checkbox" ? i.checked : i.value);
      const vs = box.querySelector(".ch-voice"); p.voice_name = vs.value ? (vs.options[vs.selectedIndex].dataset.name || vs.options[vs.selectedIndex].text) : "";
      await api(`/api/youtube/channels/${cid}`, { json: p }).then(() => toast("Настройки канала сохранены")).catch(e => toast(e.message, true));
    };
    box.querySelector(".ch-del").onclick = async () => {
      if (!confirm("Отключить этот канал от программы? На YouTube ничего не удалится.")) return;
      await api(`/api/youtube/channels/${cid}`, { method: "DELETE" }); viewSettings("youtube");
    };
  });

  const collect = () => {
    const out = {};
    main.querySelectorAll("[data-k]").forEach(i => { if (i.type === "password" && !i.value) return; out[i.dataset.k] = i.value; });
    const prov = main.querySelector("input[name=imgprov]:checked"); if (prov) out.image_provider = prov.value;
    const vs = $("#voice-sel"); out.elevenlabs_voice_id = vs.value; out.elevenlabs_voice_name = vs.options[vs.selectedIndex]?.dataset.name || vs.options[vs.selectedIndex]?.text;
    const manual = $("#voice-id").value.trim();
    if (manual) { out.elevenlabs_voice_id = manual; out.elevenlabs_voice_name = `Свой голос (${manual.slice(0, 6)}…)`; }
    return out;
  };
  const save = async (quiet) => { SETTINGS_CACHE = await api("/api/settings", { json: collect() }); draftClear(); if (!quiet) { toast("Настройки сохранены"); await viewSettings(); draftBaseReset(); } };
  $("#save").onclick = () => save(false).catch(e => toast(e.message, true));
  main.querySelectorAll("input[name=imgprov]").forEach(r => r.onchange = () => main.querySelectorAll(".provider").forEach(p => p.classList.toggle("sel", p.contains(main.querySelector("input[name=imgprov]:checked")))));
  const elBox = main.querySelector(".el-keys");
  const drawKeys = async () => {
    const list = elBox.querySelector("[data-el-list]");
    try {
      const ks = await api("/api/eleven/keys");
      list.innerHTML = ks.length ? `<table>${ks.map(k => `<tr><td>${k.active ? "✅ <b>рабочий</b>" : "запасной"}</td><td><code>${esc(k.mask)}</code></td>
        <td>${k.left !== undefined ? `осталось ${k.left.toLocaleString("ru")} символов` : `<span class="muted">${esc(k.error || "не проверить")}</span>`}${k.spent ? " · <span class=\"muted\">кончились недавно</span>" : ""}</td>
        <td>${k.active ? "" : `<button class="sm" type="button" data-el-use="${k.id}">Сделать рабочим</button> <button class="sm" type="button" data-el-del="${k.id}">Убрать</button>`}</td></tr>`).join("")}</table>` : `<p class="muted">Ключей пока нет.</p>`;
      list.querySelectorAll("[data-el-use]").forEach(b => b.onclick = async () => { await api(`/api/eleven/keys/${b.dataset.elUse}/use`, { json: {} }).catch(e => toast(e.message, true)); drawKeys(); });
      list.querySelectorAll("[data-el-del]").forEach(b => b.onclick = async () => {
        if (!confirm("Убрать этот ключ из программы?")) return;
        await fetch(`/api/eleven/keys/${b.dataset.elDel}`, { method: "DELETE" }); drawKeys();
      });
    } catch (e) { list.innerHTML = `<span class="muted">${esc(e.message)}</span>`; }
  };
  if (elBox) {
    elBox.addEventListener("toggle", () => { if (elBox.open) drawKeys(); });
    elBox.querySelector("[data-el-add]").onclick = async () => {
      const inp = elBox.querySelector("[data-el-new]");
      if (!inp.value.trim()) return toast("Вставьте ключ", true);
      await api("/api/eleven/keys", { json: { key: inp.value.trim() } }).then(() => { inp.value = ""; toast("Ключ добавлен"); drawKeys(); }).catch(e => toast(e.message, true));
    };
  }
  const atmBox = main.querySelector("[data-atm-list]");
  const drawAtm = async () => {
    const lib = await api("/api/atmos").catch(() => ({}));
    atmBox.innerHTML = Object.entries(META.atmos_kinds).filter(([k]) => k !== "none").map(([k, n]) => `<div class="row" style="gap:8px;margin:6px 0;flex-wrap:wrap">
      <b style="min-width:180px">${esc(n)}</b>
      ${(lib[k] || []).map(f => `<span class="tag-mod">${/\.(mp3|wav|m4a|aac|ogg)$/i.test(f.name) ? "🔊" : "🎞"} ${esc(f.name)} <a href="#" data-atm-del="${k}/${esc(f.name)}" title="Убрать">✕</a></span>`).join("") || `<span class="muted small">встроенный</span>`}
      <label class="btn sm" style="cursor:pointer">＋ Добавить<input type="file" accept="video/*,audio/*" multiple data-atm-up="${k}" style="display:none"></label></div>`).join("");
    atmBox.querySelectorAll("[data-atm-up]").forEach(inp => inp.onchange = async () => {
      for (const f of inp.files) {
        toast(`Загружаю ${f.name}…`);
        const r = await fetch(`/api/atmos/${inp.dataset.atmUp}/upload?name=${encodeURIComponent(f.name)}`, { method: "POST", body: f });
        if (!r.ok) { const x = await r.json().catch(() => ({})); toast(x.error || x.detail || "Не загрузилось", true); }
      }
      drawAtm();
    });
    atmBox.querySelectorAll("[data-atm-del]").forEach(a => a.onclick = async e => {
      e.preventDefault(); await fetch(`/api/atmos/${a.dataset.atmDel}`, { method: "DELETE" }); drawAtm();
    });
  };
  if (atmBox) drawAtm();
  $("#load-voices").onclick = async () => {
    try {
      await save(true);
      voices = await loadVoices(true);
      const cur = $("#voice-sel").value;
      $("#voice-sel").innerHTML = voiceOptions(voices, cur, ""); $("#voice-sel").value = cur;
      renderMarks();
      const a = await api("/api/elevenlabs/account").catch(() => null);
      if (a) $("#el-acc").textContent = `Тариф: ${a.tier}, использовано ${a.used?.toLocaleString("ru")} из ${a.limit?.toLocaleString("ru")} символов`;
      toast(`Загружено голосов: ${voices.length}`);
    } catch (e) { toast(e.message, true); }
  };
  const renderMarks = () => {
    const box = $("#voice-marks");
    const sel = v => `<select class="sm" data-aud="${v.voice_id}" style="width:auto">
      <option value="auto" ${v.audience === v.auto_audience ? "selected" : ""}>Само (${v.auto_audience === "both" ? "?" : v.auto_audience.toUpperCase()})</option>
      ${[["ru", "🇷🇺 Русская"], ["en", "🇺🇸 Английская"], ["de", "🇩🇪 Немецкая"], ["es", "🇪🇸 Испанская"], ["fr", "🇫🇷 Французская"], ["both", "🌍 Любая"]].map(([k, n]) => `<option value="${k}" ${v.audience === k && v.audience !== v.auto_audience ? "selected" : ""}>${n}</option>`).join("")}</select>`;
    const countries = [...new Set(voices.map(v => v.country))].sort();
    const f = renderMarks.f || (renderMarks.f = { aud: "", kind: "", country: "" });
    const shown = voices.filter(v => (!f.aud || v.audience === f.aud) && (!f.kind || v.kind === f.kind) && (!f.country || v.country === f.country));
    box.innerHTML = `<h3>Голоса: аудитория, тип и страна</h3>
      <p class="muted small">Программа сама делит голоса на мужские, женские и детские и пишет, под какую страну подходит акцент. Аудиторию определяет по языку и акценту голоса в ElevenLabs: русский, английский, немецкий, испанский или французский; стандартные голоса ElevenLabs (George, Brian и др.) — носители английского. Если не согласны, поменяйте пометку в последнем столбце, она запомнится. Голоса нужного языка проще всего добавить кнопкой «Библиотека голосов»: там можно выбрать язык.</p>
      <div class="row" style="gap:8px;margin:8px 0" data-nodraft>
        <select data-vf="aud" data-nodraft style="width:auto"><option value="">Любая аудитория</option>${Object.entries(AUD).map(([k, n]) => `<option value="${k}" ${f.aud === k ? "selected" : ""}>${n.split(" (")[0]}</option>`).join("")}</select>
        <select data-vf="kind" style="width:auto"><option value="">Все голоса</option>${Object.entries(KIND).map(([k, n]) => `<option value="${k}" ${f.kind === k ? "selected" : ""}>${n}</option>`).join("")}</select>
        <select data-vf="country" style="width:auto"><option value="">Все страны</option>${countries.map(c => `<option ${f.country === c ? "selected" : ""}>${esc(c)}</option>`).join("")}</select>
        <span class="muted small">Показано: ${shown.length} из ${voices.length}</span></div>
      <div data-nodraft><table><tr><th>Тип</th><th>Имя</th><th>Страна</th><th>Описание</th><th></th><th>Аудитория</th></tr>${shown.map(v => `<tr>
        <td style="white-space:nowrap">${KIND[v.kind || "other"].split(" ")[0]}</td><td><b>${esc(v.name)}</b></td>
        <td style="white-space:nowrap">${v.flag} ${esc(v.country)}</td><td class="muted small">${esc(v.description)}</td>
        <td>${v.preview_url ? `<button class="sm" data-prev="${v.voice_id}">▶</button>` : ""}</td><td>${sel(v)}</td></tr>`).join("")}</table></div>`;
    box.querySelectorAll("[data-vf]").forEach(x => { x.dataset.nodraft = 1; x.onchange = () => { f[x.dataset.vf] = x.value; renderMarks(); }; });
    box.querySelectorAll("[data-aud]").forEach(x => x.onchange = async () => {
      await api(`/api/voices/${x.dataset.aud}/audience`, { json: { audience: x.value } }).catch(e => toast(e.message, true));
      voices = await loadVoices(true); const cur = $("#voice-sel").value;
      $("#voice-sel").innerHTML = voiceOptions(voices, cur, ""); $("#voice-sel").value = cur; renderMarks();
      toast("Пометка сохранена");
    });
    box.querySelectorAll("[data-prev]").forEach(b => b.onclick = () => {
      const v = voices.find(x => x.voice_id === b.dataset.prev); const a = $("#voice-audio"); a.src = v.preview_url; a.play();
    });
  };
  $("#voice-lib").onclick = () => openVoiceLibrary(async (vid, name) => {
    $("#voice-id").value = ""; voices = VOICES || voices;
    const sel = $("#voice-sel"); if (voices.length) sel.innerHTML = voiceOptions(voices, vid, "");
    pickIntoSelect(sel, vid, name);
  });
  $("#voice-preview").onclick = () => {
    const v = voices.find(x => x.voice_id === $("#voice-sel").value);
    if (!v?.preview_url) return toast("Сначала нажмите «Загрузить список голосов»", true);
    const a = $("#voice-audio"); a.src = v.preview_url; a.play();
  };
  main.querySelectorAll("[data-style]").forEach(b => b.onclick = () => {
    main.querySelector('[data-k="image_style"]').value = STYLE_PRESETS[b.dataset.style].text;
    toast("Стиль подставлен. Нажмите «Сохранить», а потом «Проверить этот сервис», чтобы увидеть пример.");
  });
  $("#t-anim").onclick = async () => {
    const r = $("#t-anim-r"), b = $("#t-anim");
    b.disabled = true; r.textContent = "Рисую картинку и оживляю её. Обычно это 1–3 минуты…";
    try { await save(true); const blob = await api("/api/test/anim", { json: {} }); const v = $("#t-anim-v"); v.style.display = ""; v.src = URL.createObjectURL(blob); v.play(); r.textContent = "✅ Анимация работает."; }
    catch (e) { r.textContent = "❌ " + e.message; }
    b.disabled = false;
  };
  const bkInfo = () => api("/api/backup").then(r => { $("#bk-info").textContent = r.items.length ? `Копий: ${r.items.length}, последняя: ${r.items[0].name}` : "Копий пока нет."; }).catch(() => { });
  bkInfo();
  $("#bk-make").onclick = async () => {
    try { const r = await api("/api/backup", { method: "POST" }); toast(`Сохранено ${r.where}: ${r.name}`); bkInfo(); } catch (e) { toast(e.message, true); }
  };
  $("#t-llm").onclick = async () => {
    $("#t-llm-r").textContent = "Проверяю…";
    try { await save(true); const r = await api("/api/test/llm", { json: {} }); $("#t-llm-r").textContent = `✅ Работает. Ответ: «${r.text}»`; }
    catch (e) { $("#t-llm-r").textContent = "❌ " + e.message; }
  };
  $("#t-tts").onclick = async () => {
    try { await save(true); toast("Озвучиваю пробную фразу…"); const b = await api("/api/test/tts", { json: {} }); const a = $("#t-tts-a"); a.style.display = ""; a.src = URL.createObjectURL(b); a.play(); }
    catch (e) { toast(e.message, true); }
  };
  main.querySelectorAll("[data-timg]").forEach(b => b.onclick = async () => {
    $("#t-img-r").innerHTML = `<p class="muted">Рисую пробную картинку через ${esc(P[b.dataset.timg].name)}…</p>`;
    $("#t-img-r").scrollIntoView({ block: "center" });
    try { await save(true); const blob = await api("/api/test/image", { json: { provider: b.dataset.timg } }); $("#t-img-r").innerHTML = `<p>✅ Работает:</p><img src="${URL.createObjectURL(blob)}" style="max-width:600px;width:100%;border-radius:8px">`; }
    catch (e) { $("#t-img-r").innerHTML = `<div class="banner bad">${esc(e.message)}</div>`; }
  });
}

// ------------------------------------------------------------------ prompts
async function viewPrompts(name) {
  const list = await api("/api/prompts");
  const cur = list.find(p => p.name === name) || list[0];
  main.innerHTML = `<h1>Шаблоны сценария</h1>
  <div class="banner info small">Это инструкции, по которым нейросеть пишет сценарий на каждом шаге. Они на английском, потому что так нейросеть пишет английский текст качественнее. Слова в {{двойных фигурных скобках}} программа подставляет сама, их не удаляйте. Формат ответа задаёт программа, поэтому менять можно только сами правила. Если что-то сломалось, нажмите «Вернуть как было».</div>
  <div class="row" style="align-items:flex-start">
    <div class="card plist" style="width:300px">${list.map(p => `<a href="#/prompts/${p.name}" class="${p.name === cur.name ? "active" : ""}">${esc(p.title)} ${p.modified ? `<span class="tag-mod">● изменён</span>` : ""}</a>`).join("")}</div>
    <div class="card grow">
      <h2>${esc(cur.title)}</h2>
      <textarea class="code" id="ptext">${esc(cur.text)}</textarea>
      <div class="row" style="margin-top:10px"><button class="primary" id="psave">Сохранить</button><button id="preset">Вернуть как было</button></div>
    </div></div>`;
  $("#psave").onclick = async () => { await api(`/api/prompts/${cur.name}`, { json: { text: $("#ptext").value } }); draftClear(); toast("Шаблон сохранён. Он будет использоваться в новых роликах."); viewPrompts(cur.name); };
  $("#preset").onclick = async () => { if (!confirm("Вернуть исходный шаблон?")) return; await api(`/api/prompts/${cur.name}`, { json: { reset: true } }); viewPrompts(cur.name); };
}

// ------------------------------------------------------------------ music
// Tracks grouped into folders: composed ones apart, the rest by the genre their style names.
const MUSIC_GENRES = [["Поп", /поп|pop/], ["Джаз", /джаз|нуар|jazz/], ["Рок", /рок|гитар|rock/], ["Хип-хоп", /хип|рэп|трэп|hip|rap|trap/],
  ["Лоу-фай", /лоу-?фай|lo-?fi/], ["Оркестр и кино", /оркестр|эпич|кинемат|cinemat|orchestr|epic/], ["Электроника", /эмби|синт|электр|ambient|synth|electr/],
  ["Кантри", /кантри|country/], ["Комедийная", /комед|пиццикато|игрив/], ["Мрачная", /мрач|напряж|тревож|хоррор|dark/], ["Спокойная", /спокой|лирич|пианино|piano|calm/]];
function musicGenre(style) {
  const t = (style || "").toLowerCase(); if (!t.trim()) return "";
  const g = MUSIC_GENRES.find(([, re]) => re.test(t));
  if (g) return g[0];
  const w = t.split(/[,.;]/)[0].trim(); return w[0].toUpperCase() + w.slice(1);
}
function musicFolders(files) {
  const groups = {};
  for (const f of files) {
    const g = f.made_for ? "🎼 Сочинённая программой" : musicGenre(f.style) || "Без стиля";
    (groups[g] = groups[g] || []).push(f);
  }
  const names = Object.keys(groups).sort((a, b) => (a.startsWith("🎼") ? 1 : 0) - (b.startsWith("🎼") ? 1 : 0) || (a === "Без стиля") - (b === "Без стиля") || a.localeCompare(b, "ru"));
  return names.map(g => `<div class="card"><h2>${g === "Без стиля" || g.startsWith("🎼") ? g : "📁 " + esc(g)} (${groups[g].length})</h2>
    <div class="mlist">${groups[g].map(f => `<div class="mrow"><div class="grow"><div class="small"><b>${esc(f.name)}</b></div>
      <input type="text" class="mstyle" list="mgenres" data-name="${esc(f.name)}" value="${esc(f.style || "")}" placeholder="Стиль или папка, например «Поп» или «весёлый поп, бодрый»">
      ${f.made_for ? `<div class="muted small">Сочинена для ролика «${esc(f.made_for)}»</div>` : ""}</div>
      <audio controls preload="none" src="/music/${encodeURIComponent(f.name)}"></audio><button class="sm danger" data-del="${esc(f.name)}">Удалить</button></div>`).join("")}</div></div>`).join("") + `<datalist id="mgenres">${MUSIC_GENRES.map(([g]) => `<option value="${g}">`).join("")}</datalist>`;
}
async function viewMusic() {
  const files = await api("/api/music");
  main.innerHTML = `<h1>Фоновая музыка</h1>
  <div class="card">
    <p>Для каждого ролика программа выбирает отсюда трек, который больше всего подходит по стилю к настроению ролика, и тихо подкладывает его под голос. Если раздел пустой, ролик будет без музыки.</p>
    <p class="muted small">Треки разложены по папкам по стилю: напишите у трека стиль (или просто выберите папку из подсказки, например «Поп»), и он переедет в свою папку. Сочинённые программой треки лежат в отдельной папке. Папки открываются нажатием.</p>
    <p class="muted small">Можно включить в «Новом ролике» «Сочинять новую»: программа сочинит музыку через ElevenLabs (около $0.30 за минуту) и сохранит её сюда со стилем, чтобы использовать снова бесплатно. Стиль можно подписать и у своих треков: по нему программа подбирает музыку.</p>
    <p class="muted small">Где взять музыку без проблем с авторскими правами: в <a href="https://studio.youtube.com/" target="_blank">YouTube Studio → Фонотека</a> (бесплатно, можно использовать на YouTube). Ищите спокойные, атмосферные или «cinematic» треки без слов.</p>
    <div class="row"><input type="file" id="mfile" multiple accept="audio/*" style="display:none"><button class="primary" onclick="document.getElementById('mfile').click()">＋ Добавить треки</button><button id="mopen">📂 Открыть папку с музыкой</button></div>
  </div>
  ${files.length ? musicFolders(files) : `<div class="card"><p class="muted">Треков пока нет.</p></div>`}`;
  foldCards(main, "music");
  $("#mfile").onchange = async e => {
    for (const f of e.target.files) {
      try { await api(`/api/music/upload?name=${encodeURIComponent(f.name)}`, { method: "POST", body: f }); } catch (err) { toast(err.message, true); }
    }
    toast("Музыка добавлена"); viewMusic();
  };
  $("#mopen").onclick = () => api("/api/open", { json: { what: "music" } });
  main.querySelectorAll(".mstyle").forEach(i => i.onchange = () => api(`/api/music/${encodeURIComponent(i.dataset.name)}/style`, { json: { style: i.value } }).then(() => { toast("Стиль сохранён"); viewMusic(); }).catch(e => toast(e.message, true)));
  main.querySelectorAll("[data-del]").forEach(b => b.onclick = async () => { await api(`/api/music/${encodeURIComponent(b.dataset.del)}`, { method: "DELETE" }); viewMusic(); });
}

// ------------------------------------------------------------------ help
// ------------------------------------------------------------------ updates from GitHub
async function checkUpdate(byHand) {
  let u;
  const box = $("#updbox");
  try { u = await api("/api/update/check"); }
  catch (e) {
    // GitHub not reachable right now (often without VPN): keep the link so it can be tried again.
    box.innerHTML = `<a href="#" class="updcheck">Проверить обновления</a>`;
    box.querySelector("a").onclick = async ev => { ev.preventDefault(); await checkUpdate(true); };
    if (byHand) toast("Не удалось проверить обновления: " + e.message + " Если вы в России, включите VPN и нажмите ещё раз.", true);
    return;
  }
  if (!u.available) {
    box.innerHTML = `<a href="#" class="updcheck">Проверить обновления</a>`;
    box.querySelector("a").onclick = async ev => { ev.preventDefault(); await checkUpdate(true); if (!$("#updbox .updbtn")) toast(`У вас последняя версия (${u.current})`); };
    return;
  }
  box.innerHTML = `<button class="updbtn" title="${esc(u.notes)}">⬆ Обновить до версии ${u.latest}${u.label ? `: ${esc(u.label)}` : ""}</button>`;
  box.querySelector("button").onclick = () => {
    if (!u.can_install) {
      if (confirm(`Вышла версия ${u.latest}.\n\n${u.notes}\n\nСкачать новую программу?`) && u.download) window.open(u.download, "_blank");
      return;
    }
    if (!confirm(`Обновить программу до версии ${u.latest}?\n\n${u.notes}\n\nПрограмма закроется и через полминуты откроется уже новой. Ролики, проекты и ключи останутся. Если сейчас делается ролик, он продолжится после обновления.`)) return;
    runUpdate();
  };
}
async function runUpdate() {
  const wait = document.createElement("div"); wait.className = "updwait"; wait.textContent = "Обновляю программу…";
  document.body.appendChild(wait);
  try { await api("/api/update/apply", { json: {} }); }
  catch (e) { wait.remove(); return toast(e.message, true); }
  const poll = setInterval(async () => {
    let st;
    try { st = await api("/api/update/status"); } catch (e) { wait.textContent = "Программа перезапускается…"; return; }
    if (st.status === "error") { clearInterval(poll); wait.remove(); toast(st.error, true); return; }
    wait.textContent = st.status === "restarting" ? "Программа перезапускается…" : `Обновляю программу: ${st.step}…`;
  }, 1000);
}
checkUpdate();
setInterval(checkUpdate, 30 * 60 * 1000);

// ------------------------------------------------------------------ balances
const BAL_SHORT = { anthropic: "Claude", openai: "OpenAI", elevenlabs: "ElevenLabs", fal: "fal.ai", replicate: "Replicate", together: "Together", runware: "Runware" };
function balValue(r) {
  if (r.value == null) return "";
  if (r.unit === "символов") return `${Number(r.value).toLocaleString("ru")} симв.`;
  return `${r.kind === "estimate" ? "≈ " : ""}$${Number(r.value).toFixed(2)}`;
}
function renderBalSide(rows) {
  const shown = rows.filter(r => r.value != null);
  $("#balside").innerHTML = shown.length ? `<div class="bh">Балансы</div>` + shown.map(r =>
    `<div class="bl ${r.low ? "low" : ""}"><span>${esc(BAL_SHORT[r.id] || r.name)}</span><b>${esc(balValue(r))}</b></div>`).join("") : "";
}
async function refreshBalSide() {
  try { renderBalSide((await api("/api/balance")).services); } catch (e) { }
}
refreshBalSide();
setInterval(refreshBalSide, 10 * 60 * 1000);

async function viewBalance() {
  main.innerHTML = `<h1>Балансы сервисов</h1><p class="muted">Загружаю…</p>`;
  const d = await api("/api/balance");
  renderBalSide(d.services);
  const when = t => new Date(t * 1000).toLocaleString("ru");
  const cards = d.services.map(r => {
    let body = "";
    if (r.kind === "error") body = `<div class="banner bad small">${esc(r.error)}</div>`;
    else if (r.unit === "символов") {
      body = `<div class="big ${r.low ? "low" : ""}">${Number(r.value).toLocaleString("ru")} символов</div>
        <p class="small muted">Осталось из ${Number(r.limit).toLocaleString("ru")} по тарифу${r.plan ? ` «${esc(r.plan)}»` : ""}. Это примерно ${r.minutes} мин озвучки.${r.reset ? ` Лимит обновится ${new Date(r.reset * 1000).toLocaleDateString("ru")}.` : ""}</p>`;
    } else if (r.kind === "real") {
      body = `<div class="big ${r.low ? "low" : ""}">$${Number(r.value).toFixed(2)}</div><p class="small muted">Точный остаток, его присылает сам сервис.</p>`;
    } else {
      if (r.error && !r.fal_rights) body += `<div class="banner warn small">Не удалось спросить баланс: ${esc(r.error)}</div>`;
      if (r.fal_rights) body += `<div class="banner warn small">fal.ai не дал посмотреть баланс этим ключом. Чтобы видеть точный остаток, создайте на fal.ai новый ключ с правами «Full» или «Read only» и вставьте его в Настройках. Пока считаю примерно.</div>`;
      body += r.value != null
        ? `<div class="big ${r.low ? "low" : ""}">≈ $${Number(r.value).toFixed(2)}</div>
           <p class="small muted">Примерно: программа берёт сумму, которую вы вписали ${when(r.known_time)} ($${Number(r.known_amount).toFixed(2)}), и вычитает свои траты с того момента.</p>`
        : `<p>${r.id === "fal" ? "Точный остаток сейчас узнать не получилось." : "Этот сервис не сообщает баланс программам."} Впишите остаток из кабинета один раз, и программа будет сама вычитать свои траты.</p>`;
      body += `<div class="row"><span class="small">Сейчас в кабинете:</span> $ <input class="bal-in" data-s="${esc(r.id)}" style="width:110px" placeholder="например 20">
        <button class="sm bal-save" data-s="${esc(r.id)}">Сохранить</button></div>
        <p class="small muted">Сверяйте раз в неделю или после пополнения: счёт программы примерный.${r.spent ? ` Программа потратила здесь около $${Number(r.spent).toFixed(2)}${r.since ? ` с ${new Date(r.since * 1000).toLocaleDateString("ru")}` : ""}.` : ""}</p>`;
    }
    return `<div class="card balcard"><h3>${esc(r.name)}</h3>${body}<a href="${esc(r.billing)}" target="_blank" class="small">Открыть кабинет и пополнить →</a></div>`;
  }).join("");
  main.innerHTML = `<h1>Балансы сервисов</h1>
    <p class="muted">Красным выделено, когда денег осталось мало: меньше $${d.low_usd} или меньше 10% символов озвучки. Слева внизу балансы видны всегда.</p>
    ${cards || `<div class="banner warn">Пока не подключён ни один платный сервис. Вставьте ключи в <a href="#/settings">Настройках</a>.</div>`}
    <button id="bal-refresh">Обновить</button>`;
  $("#bal-refresh").onclick = () => viewBalance();
  main.querySelectorAll(".bal-save").forEach(b => b.onclick = async () => {
    const inp = main.querySelector(`.bal-in[data-s="${b.dataset.s}"]`);
    try { await api("/api/balance/known", { json: { service: b.dataset.s, amount: inp.value } }); toast("Сохранено"); viewBalance(); }
    catch (e) { toast(e.message, true); }
  });
}

function viewHelp() {
  main.innerHTML = `<h1>Как пользоваться</h1>
  <div class="card">
    <h2>Первый запуск</h2>
    <ol>
      <li>Откройте <a href="#/settings">Настройки</a> и вставьте три ключа: нейросеть для сценария (Anthropic или OpenAI), ElevenLabs и сервис картинок. После каждого ключа нажмите «Проверить».</li>
      <li>Добавьте 3–5 треков в <a href="#/music">Музыку</a> (по желанию).</li>
      <li>Нажмите <a href="#/new">Новый ролик</a>, впишите тему или оставьте пустым, нажмите «Запустить».</li>
    </ol>
    <h2>Как делается ролик</h2>
    <ol>
      <li><b>Выбор темы.</b> Нейросеть придумывает 5 тем (число меняется в Настройках, ещё темы можно попросить кнопкой), оценивает каждую по 5 пунктам и выбирает лучшую.</li>
      <li><b>Структура и хуки.</b> Хук на первые 15 секунд, повороты, удерживающие крючки каждые 1–1,5 минуты.</li>
      <li><b>Текст.</b> Около 150 слов на минуту ролика.</li>
      <li><b>Проверка редактором.</b> Отдельный запрос оценивает текст по 10 пунктам и переписывает, пока оценка не выше порога. Все оценки и комментарии на русском.</li>
      <li><b>Сцены.</b> Текст делится на куски по ~9 секунд, для каждого пишется описание картинки.</li>
      <li><b>Перевод и описание.</b> Полный перевод на русский, название, описание, теги и обложка для YouTube.</li>
      <li><b>Шортс.</b> Отдельный короткий сценарий из самого сильного момента.</li>
      <li><b>Озвучка, картинки, сборка.</b> Всё собирается в MP4 1920×1080 и вертикальный 1080×1920.</li>
    </ol>
    <h2>Полезно знать</h2>
    <ul>
      <li>Программа открывается в своём окне. Закрыли окно, и программа выключилась; если в этот момент делается ролик, она спросит, и при следующем запуске продолжит с того же места. Выключить можно и кнопкой «Выключить программу» слева внизу.</li>
      <li>Если выключить программу или Mac, работа продолжится с того же места при следующем запуске.</li>
      <li>Пока делается ролик, Mac не уснёт сам. Не закрывайте крышку, если ноутбук не на зарядке.</li>
      <li>Любой шаг можно переделать кнопкой «Переделать с этого шага». Любую картинку можно перерисовать в шаге «Сцены».</li>
      <li>Проекты (слева «Проекты и ниши»): у каждой ниши свои язык, тема, стиль картинок, голос и настройки. Создаются из готовой ниши одной кнопкой, ролики каждого проекта видны на отдельной вкладке в «Роликах». Для русских роликов выберите в проекте русскоязычный голос.</li>
      <li>Режим «Только шортс» выбирается в «Новом ролике» или в проекте: сценарий, картинки, озвучка и монтаж делаются под вертикальное видео до 60 секунд.</li>
      <li>Эффекты (звук перелистывания, удары, «вжух», наезды, тряска) нейросеть расставляет по смыслу сценария. Режим меняется под готовым видео, пересборка бесплатная.</li>
      <li>Персонажи создаются в проекте (описание по-русски, портрет рисуется или загружается). При запуске ролика нажмите на нужных персонажей: сценарий строится вокруг них, а на картинках они похожи на свой портрет.</li>
      <li>Предметы (товары и вещи) добавляются в разделе «Предметы» с фото. При запуске ролика нажмите на нужные: они появятся в истории и на картинках будут как на ваших фото.</li>
      <li>Анимация сцен выбирается при запуске ролика или в шаге «Анимация сцен». Выгоднее всего «Только хук»: оживает начало ролика, где зрители решают, смотреть ли дальше. Цена показывается до запуска.</li>
      <li>Субтитры включаются галочкой при запуске ролика или кнопкой «Включить/Выключить субтитры» под готовым видео. Видео пересобирается за пару минут бесплатно, без новых запросов к сервисам.</li>
      <li>Все ролики лежат в папке: <code>${esc(META.data_dir)}/jobs</code>. Кнопка «Открыть папку» на странице ролика открывает её в Finder.</li>
    </ul>
  </div>`;
}

$("#quit").onclick = async e => {
  e.preventDefault();
  if (!confirm("Выключить программу? Если сейчас делается ролик, он продолжится с того же места при следующем запуске.")) return;
  await api("/api/shutdown", { json: {} }).catch(() => { });
  clearInterval(timer);
  main.innerHTML = `<div class="card"><h2>Программа выключена</h2><p class="muted">Окно можно закрыть. Чтобы запустить снова, откройте «Авто ютуб» из Программ или из Дока.</p></div>`;
};

route();


// ------------------------------------------------------------------ remake of someone else's video
const RM_STATUS = { new: "Не запускалась", running: "⏳ Идёт работа", done: "✅ Готово", error: "⚠️ Ошибка" };

async function viewRemake(id) {
  if (id) return viewRemakeOne(id);
  const r = await api("/api/remakes");
  main.innerHTML = `<h1>🔁 Переделка ролика</h1>
  <div class="card">
    <p>Загрузите готовый ролик с русской речью, например чужой шортс с вшитыми субтитрами. Программа распознает речь, переведёт её на живой английский, озвучит выбранным голосом, закроет или сотрёт старые субтитры, наложит английские и напишет название, описание и теги под поиск. Можно ещё отразить картинку и чуть изменить кадр, чтобы ролик не выглядел копией.</p>
    <p class="muted small">Стоимость за минуту ролика: распознавание речи около $0.004, перевод и описание около $0.02, озвучка около 900 символов ElevenLabs. Стирание субтитров нейросетью оплачивается отдельно в Replicate. Для своих роликов из программы удобнее кнопка «🌐 Английская версия» на странице ролика: там субтитры стирать не нужно.</p>
    <label class="btn primary" style="display:inline-block;cursor:pointer">📤 Загрузить видео mp4<input type="file" id="rmfile" accept="video/*" style="display:none"></label>
    <span id="rmup" class="muted small"></span>
  </div>
  <div class="card"><h2>Переделки</h2>${r.items.length ? `<table>${r.items.map(x => `<tr><td><a href="#/remake/${x.id}">${esc(x.title || x.name)}</a><div class="muted small">${esc(x.name)} · ${fmtTime(x.duration)}</div></td><td>${RM_STATUS[x.status] || esc(x.status)}</td></tr>`).join("")}</table>` : `<p class="muted">Пока ничего не загружено.</p>`}</div>`;
  $("#rmfile").onchange = async e => {
    const f = e.target.files[0];
    if (!f) return;
    $("#rmup").textContent = `Загружаю ${f.name} (${(f.size / 1048576).toFixed(1)} МБ)…`;
    try {
      const m = await api(`/api/remakes?name=${encodeURIComponent(f.name)}`, { method: "POST", body: f });
      location.hash = `#/remake/${m.id}`;
    } catch (err) { $("#rmup").textContent = ""; toast(err.message, true); }
  };
}

async function viewRemakeOne(id) {
  clearInterval(timer); timer = null;
  const [m, info] = await Promise.all([api(`/api/remakes/${id}`), api("/api/remakes")]);
  const o = m.opts || {};
  const box = m.box || { y: 75, h: 12 };
  const running = m.status === "running";
  const vertical = m.height > m.width;
  const mins = Math.max(m.duration / 60, 0.1);
  main.innerHTML = `<div class="row"><a href="#/remake" class="muted small">← Все переделки</a></div>
  <h1>${esc(m.title || m.name)}</h1>
  ${m.title_ru ? `<div class="muted">${esc(m.title_ru)}</div>` : ""}
  <div class="row" style="margin:8px 0">${RM_STATUS[m.status] || esc(m.status)}<span class="muted small">${esc(m.name)} · ${m.width}×${m.height} · ${fmtTime(m.duration)}</span></div>
  ${m.status === "error" ? `<div class="banner bad">${nl(m.error || "")}</div>` : ""}
  ${m.files["video.mp4"] ? `<div class="card"><h2>Результат</h2>
    <video controls src="/api/remakes/${id}/file/video.mp4?t=${m.finished || ""}" style="max-width:${vertical ? 320 : 640}px;width:100%"></video>
    <div class="row" style="margin-top:8px"><a class="btn" href="/api/remakes/${id}/file/video.mp4" download="remake.mp4">⬇️ Скачать видео</a>
      ${m.files["thumbnail.jpg"] ? `<a class="btn" href="/api/remakes/${id}/file/thumbnail.jpg" target="_blank">🖼 Обложка</a>` : ""}
      <button data-open>📂 Открыть папку</button></div>
    <div id="rmseo" class="small" style="margin-top:10px"></div></div>` : ""}
  <div class="card"><h2>Настройки переделки</h2>
    <div class="grid2"><div>
      <label class="f">Голос для английской озвучки</label>
      <select id="rm-v" ${running ? "disabled" : ""}><option value="">Загружаю голоса…</option></select>
      <label class="f">Старые субтитры</label>
      <select id="rm-s" ${running ? "disabled" : ""}>${Object.entries(info.subs_modes).map(([k, n]) => `<option value="${k}" ${k === (o.subs_mode || "blur") ? "selected" : ""}>${esc(n)}</option>`).join("")}</select>
      <div id="rm-ai" class="muted small" style="display:none">${info.replicate ? "Нейросеть найдёт и сотрёт текст на кадрах и дорисует фон. На лицах и сложном фоне иногда остаются разводы. Видео отправляется в ваш аккаунт Replicate и удаляется оттуда после обработки." : "⚠️ Нужен ключ Replicate: Настройки → 3. Картинки → Replicate → Ключ (выбирать Replicate для картинок не обязательно)."}</div>
      <label class="check"><input type="checkbox" id="rm-r" ${o.restyle !== false ? "checked" : ""} ${running ? "disabled" : ""}> Изменить вид: отразить зеркально, приблизить кадр на 6%, чуть ярче цвета</label>
      <label class="check"><input type="checkbox" id="rm-n" ${o.new_subs !== false ? "checked" : ""} ${running ? "disabled" : ""}> Английские субтитры на видео</label>
      <label class="f">Фоновая музыка</label>
      <select id="rm-m" ${running ? "disabled" : ""}><option value="library">Подобрать из раздела «Музыка»</option><option value="off" ${o.music === "off" ? "selected" : ""}>Без музыки</option></select>
      <p class="muted small">Русский голос из ролика полностью убирается вместе с оригинальным звуком, поэтому под английский голос ставится музыка из вашей библиотеки.</p>
    </div><div>
      <label class="f">Симулятор <span class="hint">включите ролик: жёлтая рамка показывает, что закроется размытой полосой, белый текст показывает новые субтитры</span></label>
      <div id="rm-stage" style="position:relative;display:inline-block;max-width:100%;overflow:hidden;border-radius:8px;background:#000">
        <video id="rm-vid" src="/api/remakes/${id}/file/source.mp4" poster="/api/remakes/${id}/file/preview.jpg" controls playsinline preload="metadata" style="display:block"></video>
        <div id="rm-box" style="position:absolute;left:0;right:0;border:3px solid #f5c400;background:rgba(245,196,0,.25);pointer-events:none"></div>
        <div id="rm-sub" style="position:absolute;text-align:center;color:#fff;font-family:'Arial Black','Arial Bold',Arial,sans-serif;font-weight:900;line-height:1.15;pointer-events:none;white-space:pre-wrap"></div></div>
      <div id="rm-boxui"><label class="f">Старые субтитры, сверху: <span id="rm-yv"></span>% <span class="hint">двигайте, пока жёлтая рамка не закроет старый текст во всём ролике</span></label><input type="range" id="rm-y" min="0" max="95" step="1" value="${box.y}" ${running ? "disabled" : ""}>
      <label class="f">Старые субтитры, высота: <span id="rm-hv"></span>%</label><input type="range" id="rm-h" min="3" max="60" step="1" value="${box.h}" ${running ? "disabled" : ""}></div>
      <div id="rm-subui"><label class="f">Размер новых субтитров: <span id="rm-zv"></span>%</label><input type="range" id="rm-z" min="40" max="250" step="5" value="${Math.round((o.subs_scale || 1) * 100)}" ${running ? "disabled" : ""}>
      <label class="check"><input type="checkbox" id="rm-pa" ${o.subs_pos == null ? "checked" : ""} ${running ? "disabled" : ""}> Ставить новые субтитры автоматически (на место старых, если их закрывает полоса)</label>
      <div id="rm-pui"><label class="f">Новые субтитры, середина текста сверху: <span id="rm-pv"></span>%</label><input type="range" id="rm-p" min="5" max="98" step="1" value="${o.subs_pos ?? 75}" ${running ? "disabled" : ""}></div></div>
    </div></div>
    <p class="muted small">Примерно: распознавание речи ~$${(0.004 * mins).toFixed(3)}, перевод и описание ~$${(0.02 * mins).toFixed(2)}, озвучка ~${Math.round(900 * mins).toLocaleString("ru")} символов ElevenLabs.</p>
    <div class="row"><button class="primary" id="rm-go" ${running ? "disabled" : ""}>${m.status === "new" ? "▶ Запустить переделку" : "↻ Переделать заново"}</button><span class="grow"></span><button class="danger" id="rm-del" ${running ? "disabled" : ""}>Удалить</button></div>
  </div>
  <div class="card"><h2>Журнал</h2><pre class="log" style="white-space:pre-wrap;max-height:300px;overflow:auto">${esc(m.log || "Пока пусто.")}</pre></div>`;
  // ---- simulator: the source video with the band to blur and the new subtitles as they will be drawn (ASS sizes)
  const W = m.width, H = m.height, vid = $("#rm-vid"), stage = $("#rm-stage");
  const fit = () => {
    const maxW = Math.max(200, stage.parentElement.clientWidth - 4), k = Math.min(maxW / W, (vertical ? 520 : 400) / H);
    vid.style.width = Math.round(W * k) + "px"; vid.style.height = Math.round(H * k) + "px"; return k;
  };
  const cues = [];
  (m.preview_lines || []).forEach(l => {  // like captions.group: short chunks, timed by their length
    const ws = l.text.split(/\s+/).filter(Boolean), maxW = vertical ? 3 : 8, maxC = vertical ? 18 : 42, chunks = [];
    let cur = [];
    ws.forEach(w => { if (cur.length && (cur.length >= maxW || (cur.join(" ") + " " + w).length > maxC)) { chunks.push(cur.join(" ")); cur = []; } cur.push(w); });
    if (cur.length) chunks.push(cur.join(" "));
    const total = chunks.reduce((a, c) => a + c.length, 0) || 1; let t = l.start;
    chunks.forEach(c => { const dt = (l.end - l.start) * c.length / total; cues.push({ s: t, e: t + dt, text: c }); t += dt; });
  });
  const sample = vertical ? "NEW SUBTITLES" : "This is how the new English subtitles will look";
  const draw = () => {
    const k = fit();
    const y = +$("#rm-y").value, h = +$("#rm-h").value, mode = $("#rm-s").value, on = $("#rm-n").checked;
    const scale = +$("#rm-z").value / 100, auto = $("#rm-pa").checked;
    $("#rm-box").style.top = y + "%"; $("#rm-box").style.height = h + "%";
    $("#rm-box").style.display = mode === "blur" ? "" : "none";
    $("#rm-yv").textContent = y; $("#rm-hv").textContent = h; $("#rm-zv").textContent = Math.round(scale * 100); $("#rm-pv").textContent = $("#rm-p").value;
    $("#rm-boxui").style.display = mode === "blur" ? "" : "none";
    $("#rm-ai").style.display = mode === "ai" ? "" : "none";
    $("#rm-subui").style.display = on ? "" : "none";
    $("#rm-pui").style.display = auto ? "none" : "";
    const sub = $("#rm-sub");
    if (!on) { sub.textContent = ""; return; }
    const size = Math.round((vertical ? 96 : 60) * scale), outline = Math.max(2, Math.round((vertical ? 6 : 4) * scale));
    const centre = !auto ? +$("#rm-p").value : mode === "blur" ? y + h / 2 : null;
    const marginV = centre != null ? Math.max(10, Math.round(H * (1 - centre / 100) - size / 2)) : vertical ? Math.round(H * 0.30) : 70;
    const t = vid.currentTime, cue = cues.find(c => t >= c.s && t < c.e);
    let text = cue ? cue.text : (vid.paused || !cues.length) ? (cues[0] ? cues[0].text : sample) : "";
    if (vertical) text = text.toUpperCase();
    const o = outline * k, sh = [];
    for (let a = 0; a < 16; a++) sh.push(`${(Math.cos(a * Math.PI / 8) * o).toFixed(1)}px ${(Math.sin(a * Math.PI / 8) * o).toFixed(1)}px 0 #000`);
    sh.push(`${2 * k}px ${2 * k}px 0 rgba(0,0,0,.5)`);
    Object.assign(sub.style, { fontSize: size * k + "px", bottom: marginV * k + "px", left: 80 * k + "px", right: 80 * k + "px", textShadow: sh.join(",") });
    sub.textContent = text;
  };
  ["#rm-y", "#rm-h", "#rm-z", "#rm-p"].forEach(k => $(k).oninput = draw);
  ["#rm-s", "#rm-n", "#rm-pa"].forEach(k => $(k).onchange = draw);
  ["timeupdate", "seeked", "play", "pause", "loadedmetadata"].forEach(ev => vid.addEventListener(ev, draw));
  const onResize = () => document.body.contains(vid) ? draw() : window.removeEventListener("resize", onResize);
  window.addEventListener("resize", onResize);
  draw();
  const vsel = $("#rm-v");
  if (!running) addLibButton(vsel, "en");
  loadVoices().then(vs => { vsel.innerHTML = `<option value="">— выберите голос —</option>` + voiceOptions(vs, o.voice_id || "", "en"); vsel.value = o.voice_id || ""; })
    .catch(e => { vsel.innerHTML = `<option value="">Голоса не загрузились: ${esc(e.message)}</option>`; });
  $("#rm-go").onclick = async () => {
    if (!vsel.value) return toast("Выберите голос", true);
    const op = vsel.options[vsel.selectedIndex];
    await api(`/api/remakes/${id}/start`, { json: { voice_id: vsel.value, voice_name: op.dataset.name || op.text, subs_mode: $("#rm-s").value,
      restyle: $("#rm-r").checked, new_subs: $("#rm-n").checked, music: $("#rm-m").value, box: { y: +$("#rm-y").value, h: +$("#rm-h").value },
      subs_scale: +$("#rm-z").value / 100, subs_pos: $("#rm-pa").checked ? null : +$("#rm-p").value } })
      .then(() => viewRemakeOne(id)).catch(e => toast(e.message, true));
  };
  $("#rm-del").onclick = async () => { if (!confirm("Удалить эту переделку со всеми файлами?")) return; await api(`/api/remakes/${id}`, { method: "DELETE" }); location.hash = "#/remake"; };
  const op = main.querySelector("[data-open]");
  if (op) op.onclick = () => api("/api/open", { json: { what: "remake", id } }).catch(e => toast(e.message, true));
  if (m.files["youtube.txt"]) {
    const t = await (await fetch(`/api/remakes/${id}/file/youtube.txt`)).text();
    $("#rmseo").innerHTML = `<pre style="white-space:pre-wrap">${esc(t)}</pre>${copyBtn(t)}`;
  }
  if (running) timer = setInterval(async () => {
    const n = await api(`/api/remakes/${id}`).catch(() => null);
    if (!n || location.hash !== `#/remake/${id}`) return;
    if (n.status !== "running") return viewRemakeOne(id);
    const log = main.querySelector("pre.log"); if (log) log.textContent = n.log;
  }, 3000);
}

// ------------------------------------------------------------------ AI producer: why competitors' videos worked
const PR_STATUS = { running: "⏳ Идёт разбор", done: "✅ Готово", error: "⚠️ Ошибка" };
function prList(arr) { return arr && arr.length ? `<ul>${arr.map(x => `<li>${esc(x)}</li>`).join("")}</ul>` : ""; }
function prViews(v) { return v ? `${Number(v).toLocaleString("ru")} просмотров` : ""; }
function prSection(title, body) { return body ? `<div style="margin-top:8px"><b>${title}</b><div>${body}</div></div>` : ""; }

async function viewProducer(id) {
  if (id) return viewProducerOne(id);
  clearInterval(timer); timer = null;
  const r = await api("/api/producer");
  r.items = r.items.filter(x => x.platform !== "instagram");  // reels live in the Instagram section
  main.innerHTML = `<h1>🎓 ИИ продюсер</h1>
  <div class="card">
    <p>Дайте ссылку на ролик или на целый канал YouTube, загрузите видео или вставьте текст сценария. Продюсер разберёт смысл и сценарий, объяснит, почему ролик набрал просмотры, и выпишет сильные стороны. Готовый разбор можно сохранить в «📚 Хранилище сценариев» нужной ниши, и сценарист будет на него опираться.</p>
    <label class="f">Ссылка на ролик, шортс или канал YouTube</label>
    <input id="pr-link" placeholder="https://www.youtube.com/shorts/…  или  https://www.youtube.com/@канал">
    <label class="f">Если это канал: сколько самых просматриваемых роликов разобрать</label>
    <select id="pr-count">${[3, 5, 7, 10].map(n => `<option ${n === 5 ? "selected" : ""}>${n}</option>`).join("")}</select>
    <label class="f">…или вставьте текст сценария</label>
    <textarea id="pr-text" rows="5" placeholder="Текст чужого ролика, который вам понравился"></textarea>
    <div class="row" style="margin-top:10px"><button class="primary" id="pr-go">▶ Разобрать</button>
      <label class="btn" style="display:inline-block;cursor:pointer">📤 Загрузить видео<input type="file" id="pr-file" accept="video/*" style="display:none"></label>
      <span id="pr-up" class="muted small"></span></div>
    <p class="muted small">Разбор одного ролика стоит примерно $0.03–0.08 у нейросети сценария. Если у ролика нет субтитров, речь распознаёт ElevenLabs (около $0.004 за минуту).</p>
  </div>
  <div class="card"><h2>🔍 Закономерности канала</h2>
    <p>Бывает, что на канале три ролика подряд ничего не набирают, а четвёртый стреляет. Продюсер возьмёт последние ролики канала с просмотрами, найдёт выстрелившие и провалившиеся, сравнит их темы, названия, обложки, хуки и тексты и объяснит, почему так вышло. Главные выводы можно сохранить в хранилище ниши.</p>
    <label class="f">Ссылка на канал YouTube</label>
    <input id="pt-link" placeholder="https://www.youtube.com/@канал">
    <div class="grid2"><div>
      <label class="f">Сколько последних роликов смотреть</label>
      <select id="pt-count">${[10, 15, 20, 30, 50].map(n => `<option ${n === 20 ? "selected" : ""}>${n}</option>`).join("")}</select>
    </div><div>
      <label class="f">Какие ролики</label>
      <select id="pt-tab"><option value="auto">Где их больше (шортсы или длинные)</option><option value="shorts">Шортсы</option><option value="videos">Длинные ролики</option></select>
    </div></div>
    <div class="row" style="margin-top:10px"><button class="primary" id="pt-go">🔍 Найти закономерности</button></div>
    <p class="muted small">Стоит примерно $0.08–0.20 у нейросети сценария: до 7 роликов разбираются целиком (тема, название, превью, описание, хук, сценарий, финал), у остальных смотрятся названия и просмотры.</p>
  </div>
  <div class="card"><h2>Разборы</h2>${r.items.length ? `<table>${r.items.map(x => `<tr><td><a href="#/producer/${x.id}">${x.mode === "patterns" ? "🔍 " : ""}${esc(x.title || x.source)}</a><div class="muted small">${esc(x.source)}${x.count ? ` · роликов: ${x.count}` : ""}</div></td><td>${PR_STATUS[x.status] || esc(x.status)}</td></tr>`).join("")}</table>` : `<p class="muted">Пока ни одного разбора.</p>`}</div>
  <div class="card"><h2>Загрузчик YouTube</h2>
    <p class="muted small">YouTube часто меняет сайт. Если ссылки перестали разбираться, обновите загрузчик. Сейчас: ${r.downloader ? `версия ${esc(r.downloader)}` : "не установлен"}.</p>
    <button id="pr-upd">🔄 Обновить загрузчик YouTube</button>
    <label class="f">Вход в YouTube <span class="hint">если YouTube принимает программу за робота, она смотрит ролики под вашим входом из браузера, как вы сами</span></label>
    <select id="pr-br"><option value="">Автоматически (найти браузер, где вы вошли в YouTube)</option>${Object.entries(r.browsers).map(([k, n]) => `<option value="${k}" ${k === r.browser ? "selected" : ""}>${esc(n)}${r.installed.includes(k) ? "" : " (не найден)"}</option>`).join("")}<option value="none" ${r.browser === "none" ? "selected" : ""}>Не использовать</option></select>
    <p class="muted small">Войдите в свой аккаунт YouTube в выбранном браузере. Для Chrome, Edge, Brave, Opera и Vivaldi Mac один раз спросит пароль: нажмите «Разрешать всегда». Для Safari нужно включить «Авто ютуб» в Системные настройки → Конфиденциальность и безопасность → Полный доступ к диску. Проще всего Firefox или Chrome. Яндекс Браузер не подходит.</p></div>`;
  $("#pr-go").onclick = async () => {
    const link = $("#pr-link").value.trim(), text = $("#pr-text").value.trim();
    if (!link && !text) return toast("Вставьте ссылку или текст", true);
    $("#pr-go").disabled = true;
    try {
      const m = await api("/api/producer", { json: { link, text: link ? "" : text, count: +$("#pr-count").value } });
      location.hash = `#/producer/${m.id}`;
    } catch (e) { $("#pr-go").disabled = false; toast(e.message, true); }
  };
  $("#pt-go").onclick = async () => {
    const link = $("#pt-link").value.trim();
    if (!link) return toast("Вставьте ссылку на канал", true);
    $("#pt-go").disabled = true;
    try {
      const m = await api("/api/producer", { json: { link, mode: "patterns", count: +$("#pt-count").value, tab: $("#pt-tab").value } });
      location.hash = `#/producer/${m.id}`;
    } catch (e) { $("#pt-go").disabled = false; toast(e.message, true); }
  };
  $("#pr-file").onchange = async e => {
    const f = e.target.files[0];
    if (!f) return;
    $("#pr-up").textContent = `Загружаю ${f.name} (${(f.size / 1048576).toFixed(1)} МБ)…`;
    try {
      const m = await api(`/api/producer?name=${encodeURIComponent(f.name)}`, { method: "POST", body: f });
      location.hash = `#/producer/${m.id}`;
    } catch (err) { $("#pr-up").textContent = ""; toast(err.message, true); }
  };
  $("#pr-br").onchange = e => api("/api/settings", { json: { yt_cookies_browser: e.target.value } }).then(() => toast("Сохранено")).catch(er => toast(er.message, true));
  $("#pr-upd").onclick = async () => {
    const b = $("#pr-upd"); b.disabled = true; b.textContent = "⏳ Обновляю, это может занять пару минут…";
    try { const v = await api("/api/producer/update-downloader", { method: "POST" }); toast(`Загрузчик обновлён: ${v.version}`); viewProducer(); }
    catch (e) { toast(e.message, true); b.disabled = false; b.textContent = "🔄 Обновить загрузчик YouTube"; }
  };
}

function prItem(x, i, canPick) {
  const head = `${canPick ? `<input type="checkbox" class="pr-pick" data-i="${i}" checked> ` : ""}<b>${esc(x.title || "Ролик")}</b>`;
  const sub = [x.channel, prViews(x.views), x.duration ? fmtTime(x.duration) : "", x.kind === "short" ? "шортс" : x.kind === "video" ? "длинный" : ""].filter(Boolean).join(" · ");
  return `<div class="card">
    <label style="display:block">${head}</label>
    <div class="muted small">${esc(sub)}${x.source ? ` · <a href="${esc(x.source)}" target="_blank">открыть</a>` : ""}</div>
    ${prSection("О чём ролик", nl(x.summary_ru))}
    ${prSection("Почему сработал", nl(x.why_ru))}
    ${prSection("Хук (начало)", nl(x.hook_ru))}
    ${prSection("Структура", Array.isArray(x.structure_ru) ? prList(x.structure_ru) : nl(x.structure_ru))}
    ${prSection("Сильные стороны", prList(x.strengths_ru))}
    ${prSection("Что можно лучше", prList(x.weaknesses_ru))}
    ${prSection("Название и обложка", nl(x.packaging_ru))}
    ${prSection("Похожие темы для нас", prList(x.topics_ru))}
    ${prSection("Приёмы для сценариста (на английском, так их читает нейросеть)", prList(x.techniques))}
    ${prSection("Начало ролика по-русски", nl(x.script_ru))}
    ${x.script ? `<details style="margin-top:8px"><summary>Текст ролика</summary><pre style="white-space:pre-wrap">${esc(x.script)}</pre></details>` : ""}
  </div>`;
}

const PT_GRADE = { good: "✅", mixed: "➖", bad: "❌" };
const PT_WEIGHT = { decisive: "🔑 решило", helped: "👍 помогло", minor: "· почти не влияло" };
function ptThumb(v) { return v.thumbnail ? `<img src="${esc(v.thumbnail)}" style="width:160px;border-radius:6px;flex:none" loading="lazy" onerror="this.remove()">` : ""; }
function ptX(v) { return v.x != null ? ` · ×${String(v.x).replace(".", ",")} от обычного` : ""; }

function prPatterns(m) {
  const p = m.patterns, vids = m.videos || [];
  const max = Math.max(1, ...vids.map(v => v.views || 0));
  const icon = mk => mk === "star" ? "🏆" : mk === "hit" ? "🔥" : mk === "flop" ? "💤" : "";
  const bars = vids.length ? `<div class="card"><h2>Просмотры последних роликов</h2>
    <p class="muted small">Сверху самые новые. Обычный ролик (медиана) набирает ${Number(m.median || 0).toLocaleString("ru")}. 🏆 главный хит, 🔥 тоже выше обычного, 💤 не набрал.</p>
    ${vids.map(v => `<div class="pt-row"><span class="pt-mark">${icon(v.mark)}</span><a class="pt-t small" href="${esc(v.url)}" target="_blank" title="${esc(v.title)}">${esc(v.title)}</a><span class="pt-bar"><i class="${v.mark === "star" ? "hit" : v.mark}" style="width:${Math.max(1, 100 * (v.views || 0) / max).toFixed(1)}%"></i></span><span class="pt-v small">${Number(v.views || 0).toLocaleString("ru")}</span></div>`).join("")}</div>` : "";
  if (!p) return bars;
  const concl = `<div class="card"><h2>✅ Выводы: что повторять</h2>${(p.positive || []).map((x, i) => `<label class="check"><input type="checkbox" class="pt-pick" data-i="${i}" checked> ${esc(x.rule_ru)}</label>`).join("")}
    ${prSection("❌ Ошибки, которые нельзя повторять", prList(p.avoid_ru))}${prSection("Темы для нас", prList(p.topics_ru))}</div>`;
  if (!p.videos) {  // an analysis made by version 93
    return `<div class="card"><h2>Главное</h2>${prSection("Что за канал", nl(p.summary_ru))}${prSection("Закономерность", nl(p.pattern_ru))}${prSection("Почему выстрелили", prList(p.reasons_ru))}
      <p class="muted small">Это разбор старого вида. Нажмите «🔄 Разобрать заново», чтобы получить разбор по каждому ролику.</p></div>
      ${(p.differences || []).length ? `<div class="card"><h2>Выстрелившие против провалившихся</h2><table><tr><th></th><th>🔥 Выстрелили</th><th>💤 Не набрали</th></tr>${p.differences.map(r => `<tr><td><b>${esc(r.aspect_ru)}</b></td><td>${nl(r.hits_ru)}</td><td>${nl(r.flops_ru)}</td></tr>`).join("")}</table></div>` : ""}
      ${concl}${bars}`;
  }
  const comp = m.compared || [], star = comp[0] || {};
  const cards = p.videos.map(x => {
    const v = comp[x.n - 1] || {};
    return `<div class="card pt-card ${x.n === 1 ? "pt-star" : ""}">
      <div class="row" style="align-items:flex-start;gap:12px;flex-wrap:nowrap">${ptThumb(v)}<div>
        <div>${x.n === 1 ? "🏆 <b>Главный хит</b> · " : icon(v.mark) + " "}<a href="${esc(v.url || "")}" target="_blank"><b>${esc(v.title || "Ролик " + x.n)}</b></a></div>
        <div class="muted small">${prViews(v.views)}${ptX(v)}${v.date ? " · " + esc(v.date) : ""}${v.duration ? " · " + fmtTime(v.duration) : ""}</div>
        <p style="margin:6px 0 0">${nl(x.verdict_ru)}</p></div></div>
      <table class="pt-f">${(x.factors || []).map(f => `<tr><td class="pt-g">${PT_GRADE[f.grade] || ""}</td><td><b>${esc(f.factor)}</b></td><td>${nl(f.did_ru)}<div class="muted small">${nl(f.note_ru)}</div></td></tr>`).join("")}</table>
      ${v.script ? `<details><summary class="small">Текст ролика</summary><pre style="white-space:pre-wrap">${esc(v.script)}</pre></details>` : `<div class="muted small">Текста нет, сравнивал по названию, описанию и превью</div>`}
    </div>`;
  }).join("");
  return `<div class="card"><h2>🏆 Почему выстрелил «${esc(star.title || "")}»</h2>
      <div class="muted small">${prViews(star.views)}${ptX(star)}</div>
      <p style="font-size:1.05em">${nl(p.main_ru)}</p>
      <p class="muted small">${nl(p.summary_ru)}${p.caveats_ru ? " " + nl(p.caveats_ru) : ""}</p></div>
    ${(p.comparison || []).length ? `<div class="card"><h2>Хит против остальных</h2><table class="pt-cmp"><tr><th></th><th>🏆 Хит</th><th>Остальные ролики</th><th></th></tr>
      ${p.comparison.map(r => `<tr><td><b>${esc(r.factor)}</b></td><td>${nl(r.star_ru)}</td><td>${nl(r.others_ru)}</td><td class="small nowrap">${PT_WEIGHT[r.weight] || ""}</td></tr>`).join("")}</table></div>` : ""}
    <h2 style="margin:18px 0 6px">Разбор каждого ролика</h2>
    <p class="muted small">✅ сделано хорошо · ➖ так себе · ❌ ошибка автора (под ней, как надо было)</p>
    ${cards}${concl}${bars}`;
}

async function viewProducerOne(id) {
  clearInterval(timer); timer = null;
  const [m, projs] = await Promise.all([api(`/api/producer/${id}`), api("/api/projects").catch(() => [])]);
  const running = m.status === "running", items = m.items || [], ch = m.channel, pat = m.mode === "patterns";
  let last = ""; try { last = localStorage.getItem("ay_lib_project") || ""; } catch (e) { }
  const ig = m.platform === "instagram";
  if (ig) navActive("insta");
  const projOpt = p => `<option value="${p.id}" ${p.id === last ? "selected" : ""}>${esc((p.icon || "") + " " + (p.name || "Без названия"))}</option>`;
  const igP = projs.filter(p => p.platform === "instagram"), ytP = projs.filter(p => p.platform !== "instagram");
  const groups = (ig ? [["Инстаграм", igP], ["YouTube", ytP]] : [["YouTube", ytP], ["Инстаграм", igP]]).filter(([, l]) => l.length);
  main.innerHTML = `<div class="row"><a href="${ig ? "#/insta" : "#/producer"}" class="muted small">← Все разборы</a></div>
  <h1>${esc(m.title || m.source)}</h1>
  <div class="row" style="margin:8px 0">${PR_STATUS[m.status] || esc(m.status)}<span class="muted small">${esc(m.source)}</span></div>
  ${m.status === "error" ? `<div class="banner bad">${nl(m.error || "")}</div>` : ""}
  ${!running && (items.length || (pat && m.patterns)) ? `<div class="card"><h2>📚 Сохранить в хранилище</h2>
    ${projs.length ? `<label class="f">Ниша (проект)</label>
    <select id="pr-proj">${groups.map(([t, l]) => `<optgroup label="${t}">${l.map(projOpt).join("")}</optgroup>`).join("")}</select>
    ${pat ? `<p class="muted small">Сохранятся выводы с галочкой (они ниже), закономерность, темы и что не делать. Сценарист ниши будет на них опираться.</p>` : items.length > 1 ? `<p class="muted small">Сохранятся ролики с галочкой. Галочки стоят у каждого ролика ниже.</p>` : ""}
    ${ch ? `<label class="check"><input type="checkbox" id="pr-ch" checked> И общую формулу канала</label>` : ""}
    <div class="row" style="margin-top:8px"><button class="primary" id="pr-save">📚 Сохранить в хранилище</button></div>`
      : `<p class="muted">Сначала создайте проект в разделе «📁 Проекты и ниши»: у каждой ниши своё хранилище.</p>`}</div>` : ""}
  ${ch ? `<div class="card"><h2>Формула канала</h2>
    ${prSection("Что за канал", nl(ch.summary_ru))}${prSection("Формула хитов", nl(ch.formula_ru))}
    ${prSection("Сильные стороны", prList(ch.strengths_ru))}${prSection("Как обойти этот канал", nl(ch.advice_ru))}
    ${prSection("Темы для нас", prList(ch.topics_ru))}${prSection("Приёмы для сценариста", prList(ch.techniques))}</div>` : ""}
  ${pat ? prPatterns(m) : ""}
  ${items.map((x, i) => prItem(x, i, !running && items.length > 1)).join("")}
  <div class="card"><h2>Журнал</h2><pre class="log" style="white-space:pre-wrap;max-height:300px;overflow:auto">${esc(m.log || "Пока пусто.")}</pre>
    <div class="row">${pat && !running ? `<button id="pt-again">🔄 Разобрать заново</button>` : ""}<span class="grow"></span><button class="danger" id="pr-del" ${running ? "disabled" : ""}>Удалить разбор</button></div></div>`;
  if ($("#pt-again")) $("#pt-again").onclick = async e => {
    e.target.disabled = true;
    try { const n = await api("/api/producer", { json: { link: m.source, mode: "patterns", count: m.count, tab: m.tab || "auto" } }); location.hash = `#/producer/${n.id}`; }
    catch (er) { toast(er.message, true); e.target.disabled = false; }
  };
  const save = $("#pr-save");
  if (save) save.onclick = async () => {
    const pid = $("#pr-proj").value;
    const picks = [...main.querySelectorAll(pat ? ".pt-pick" : ".pr-pick")];
    const indexes = picks.length ? picks.filter(c => c.checked).map(c => +c.dataset.i) : null;
    if (pat && indexes && !indexes.length) return toast("Отметьте хотя бы один вывод", true);
    const withCh = $("#pr-ch") ? $("#pr-ch").checked : false;
    if (indexes && !indexes.length && !withCh) return toast("Отметьте хотя бы один ролик", true);
    try {
      const r = await api(`/api/producer/${id}/save`, { json: { project_id: pid, indexes, with_channel: withCh } });
      try { localStorage.setItem("ay_lib_project", pid); } catch (e) { }
      toast(`Сохранено в хранилище: ${r.added}`);
    } catch (e) { toast(e.message, true); }
  };
  $("#pr-del").onclick = async () => {
    if (!confirm("Удалить этот разбор?")) return;
    const lib = confirm("Убрать его и из хранилища сценариев?\n\nОК — убрать отовсюду: сценарист перестанет на него опираться, правила ниши пересоберутся без него.\nОтмена — удалить только здесь, в хранилище он останется.");
    const b = $("#pr-del"); b.disabled = true; b.textContent = lib ? "⏳ Убираю и пересобираю правила…" : "Удаляю…";
    try {
      const r = await api(`/api/producer/${id}?library=${lib ? 1 : 0}`, { method: "DELETE" });
      toast((r.notes || []).join("\n") || "Разбор удалён");
      location.hash = "#/producer";
    } catch (e) { toast(e.message, true); b.disabled = false; b.textContent = "Удалить разбор"; }
  };
  if (running) timer = setInterval(async () => {
    const n = await api(`/api/producer/${id}`).catch(() => null);
    if (!n || location.hash !== `#/producer/${id}`) return;
    if (n.status !== "running" || (n.items || []).length !== items.length || (n.videos || []).length !== (m.videos || []).length) return viewProducerOne(id);
    const log = main.querySelector("pre.log"); if (log) log.textContent = n.log;
  }, 3000);
}

// ------------------------------------------------------------------ Instagram: its own niches, reel analyses and libraries
const navActive = k => document.querySelectorAll("[data-nav]").forEach(a => a.classList.toggle("active", a.dataset.nav === k));
async function viewInsta() {
  clearInterval(timer); timer = null;
  const [all, niches, r] = await Promise.all([api("/api/projects"), api("/api/niches").catch(() => META.presets), api("/api/producer")]);
  const projs = all.filter(p => p.platform === "instagram");
  const libs = await Promise.all(projs.map(p => api(`/api/projects/${p.id}/library`).catch(() => ({ items: [] }))));
  const reels = r.items.filter(x => x.platform === "instagram");
  const nOpts = Object.entries(niches).filter(([, n]) => !n.hidden).map(([k, n]) => `<option value="${k}">${esc((n.icon || "") + " " + n.name)}</option>`).join("");
  main.innerHTML = `<h1>📸 Инстаграм</h1>
  <p class="muted">Всё для рилсов в одном месте: свои ниши, разборы рилсов по ссылке и хранилища. С YouTube-проектами они не смешиваются, но устроены так же: разбор можно сохранить в хранилище любой ниши, и сценарист будет на него опираться. Ролики Инстаграм-ниш по умолчанию вертикальные, до 60 секунд.</p>
  <div class="card"><h2>Ниши Инстаграма</h2>
    ${projs.length ? `<div class="pgrid sm">${projs.map((p, i) => `<a class="pcard" href="#/projects/${p.id}"><div class="pic">${esc(p.icon)}</div><div><b>${esc(p.name)}</b>
      <div class="muted small">роликов: ${p.count} · разборов: ${libs[i].items.length}</div></div></a>`).join("")}</div>`
      : `<p class="muted">Пока нет ни одной ниши для Инстаграма.</p>`}
    <div class="row" style="gap:8px;margin-top:6px"><select id="ig-niche" style="max-width:360px">${nOpts}<option value="custom">＋ Свой проект с нуля</option></select><button class="primary" id="ig-new">Создать нишу для Инстаграма</button></div>
  </div>
  <div class="card"><h2>Разобрать рилс или профиль</h2>
    <label class="f">Ссылка на рилс или на профиль <span class="hint">профиль: программа найдёт его рилсы с наибольшими просмотрами, разберёт каждый и выведет общую формулу аккаунта</span></label>
    <input type="text" id="ig-link" placeholder="https://www.instagram.com/reel/… или https://www.instagram.com/имя/">
    <div class="row" style="gap:6px;margin-top:6px"><span class="small">Для профиля разобрать лучших рилсов:</span><select id="ig-count" style="width:auto">${[3, 5, 8, 10].map(n => `<option value="${n}" ${n === 5 ? "selected" : ""}>${n}</option>`).join("")}</select><span class="muted small">≈ $0.05 за рилс</span></div>
    <label class="f">…или вставьте текст рилса</label>
    <textarea id="ig-text" rows="3" placeholder="Текст чужого рилса, который вам понравился"></textarea>
    <div class="row" style="margin-top:10px"><button class="primary" id="ig-go">▶ Разобрать</button>
      <label class="btn" style="display:inline-block;cursor:pointer">📤 Загрузить видео<input type="file" id="ig-file" accept="video/*" style="display:none"></label>
      <span id="ig-up" class="muted small"></span></div>
    <p class="muted small">Продюсер смотрит рилс как рилс: первая секунда, обложка, текст на экране, подпись, звук, темп, за что его сохраняют и пересылают. Стоит примерно $0.03–0.08. Профиль тоже можно: нужен ваш вход в Инстаграм в браузере (ниже).</p>
  </div>
  <div class="card"><h2>Разборы рилсов (${reels.length})</h2>${reels.length ? `<table>${reels.map(x => `<tr><td><a href="#/producer/${x.id}">${esc(x.title || x.source)}</a><div class="muted small">${esc(x.source)}</div></td><td>${PR_STATUS[x.status] || esc(x.status)}</td></tr>`).join("")}</table>` : `<p class="muted">Пока ни одного разбора.</p>`}</div>
  ${projs.length ? `<div class="card"><h2>Хранилища ниш</h2><div class="pgrid sm">${projs.map((p, i) => `<a class="pcard" href="#/library/${p.id}"><div class="pic">${esc(p.icon)}</div><div><b>${esc(p.name)}</b>
    <div class="muted small">разборов: ${libs[i].items.length}${libs[i].playbook_ru ? " · есть правила" : ""}</div></div></a>`).join("")}</div></div>` : ""}
  <div class="card"><h2>Вход в браузере</h2>
    <p class="muted small">Инстаграм часто отдаёт рилсы только тем, кто вошёл в аккаунт. Войдите на instagram.com в Chrome или Firefox и выберите этот браузер: программа будет смотреть рилсы под вашим входом, как вы сами. Это то же поле, что «Вход в YouTube» в ИИ продюсере.</p>
    <select id="ig-br"><option value="">Автоматически</option>${Object.entries(r.browsers).map(([k, n]) => `<option value="${k}" ${k === r.browser ? "selected" : ""}>${esc(n)}${r.installed.includes(k) ? "" : " (не найден)"}</option>`).join("")}<option value="none" ${r.browser === "none" ? "selected" : ""}>Не использовать</option></select>
  </div>`;
  $("#ig-new").onclick = async () => {
    const p = await api("/api/projects", { json: { preset: $("#ig-niche").value, platform: "instagram" } }).catch(e => toast(e.message, true));
    if (p) { toast("Ниша для Инстаграма готова"); location.hash = `#/projects/${p.id}`; }
  };
  $("#ig-go").onclick = async () => {
    const link = $("#ig-link").value.trim(), text = $("#ig-text").value.trim();
    if (!link && !text) return toast("Вставьте ссылку или текст", true);
    $("#ig-go").disabled = true;
    try { const m = await api("/api/producer", { json: { link, text: link ? "" : text, platform: "instagram", count: +$("#ig-count").value } }); location.hash = `#/producer/${m.id}`; }
    catch (e) { $("#ig-go").disabled = false; toast(e.message, true); }
  };
  $("#ig-file").onchange = async e => {
    const f = e.target.files[0]; if (!f) return;
    $("#ig-up").textContent = `Загружаю ${f.name} (${(f.size / 1048576).toFixed(1)} МБ)…`;
    try { const m = await api(`/api/producer?platform=instagram&name=${encodeURIComponent(f.name)}`, { method: "POST", body: f }); location.hash = `#/producer/${m.id}`; }
    catch (err) { $("#ig-up").textContent = ""; toast(err.message, true); }
  };
  $("#ig-br").onchange = e => api("/api/settings", { json: { yt_cookies_browser: e.target.value } }).then(() => toast("Сохранено")).catch(er => toast(er.message, true));
}

// ------------------------------------------------------------------ script library of a niche
async function viewLibrary(id) {
  clearInterval(timer); timer = null;
  let projs = await api("/api/projects").catch(() => []);
  if (!projs.length) {
    main.innerHTML = `<h1>📚 Хранилище сценариев</h1><div class="card"><p>Хранилище есть у каждой ниши. Сначала создайте проект в разделе <a href="#/projects">«📁 Проекты и ниши»</a>.</p></div>`;
    return;
  }
  const pid = id;
  const proj = projs.find(p => p.id === pid);
  if (!proj) {
    projs = projs.filter(p => p.platform !== "instagram");
    const libs = await Promise.all(projs.map(p => api(`/api/projects/${p.id}/library`).catch(() => ({ items: [] }))));
    main.innerHTML = `<h1>📚 Хранилище сценариев</h1>
    <p class="muted">У каждой ниши своё хранилище: разборы удачных роликов и правила, по которым пишет сценарист. Нажмите на нишу, чтобы открыть её хранилище.</p>
    <div class="pgrid sm">${projs.map((p, i) => `<a class="pcard" href="#/library/${p.id}"><div class="pic">${esc(p.icon)}</div><div><b>${esc(p.name || "Без названия")}</b>
      <div class="muted small">разборов: ${libs[i].items.length}${libs[i].playbook_ru ? " · есть правила" : ""}</div></div></a>`).join("")}</div>`;
    return;
  }
  const lib = await api(`/api/projects/${pid}/library`);
  const items = [...lib.items].reverse();
  const topics = [...new Set(lib.items.flatMap(x => x.topics_ru || []))].slice(-40).reverse();
  if (proj.platform === "instagram") navActive("insta");
  main.innerHTML = `<a href="${proj.platform === "instagram" ? "#/insta" : "#/library"}" class="small">← Все ниши</a><h1>${esc(proj.icon || "")} ${esc(proj.name || "Без названия")}</h1>
  <div class="card">
    <p class="muted small">Здесь лежат разборы роликов, которые сработали. Сценарист этой ниши читает правила ниши и последние разборы перед каждым новым роликом: учится приёмам, но не копирует темы и текст. Новые ниши появляются в списке сами, когда вы создаёте проект.</p>
    <label class="f">Описание ниши <span class="hint">то же поле, что в проекте</span></label>
    ${nicheIsLeftover(proj) ? LEFTOVER_NICHE : ""}
    <textarea id="lb-niche" rows="4">${esc(proj.niche || "")}</textarea>
    <div class="row" style="margin-top:6px"><button id="lb-niche-save">Сохранить описание</button>${lib.niche_prev != null ? `<button id="lb-niche-undo" title="Вернуть описание, которое было до последнего обновления продюсером">↩ Вернуть прежнее описание</button>` : ""}</div>
  </div>
  <div class="card"><h2>Правила ниши</h2>
    <p class="muted small">Кнопка ниже изучает все разборы этой ниши и пишет правила, а заодно описание ниши вверху страницы. Если описание уже заполнено, продюсер его дополнит и ничего вашего не выкинет. Правила можно поправить руками: тогда сценарист будет читать ваш вариант.</p>
    ${!lib.items.length && lib.playbook_ru ? `<div class="banner info small">Разборов в хранилище нет, а правила остались от удалённых. Сценарист их всё ещё читает. Если они не нужны, нажмите «🧹 Очистить правила».</div>` : ""}
    <textarea id="lb-pb" rows="10" placeholder="Пока пусто. Сохраните сюда несколько разборов и нажмите кнопку ниже.">${esc(lib.playbook_ru || "")}</textarea>
    <div class="row" style="margin-top:6px"><button class="primary" id="lb-build" ${lib.items.length ? "" : "disabled"}>✨ Обновить правила и описание ниши</button><button id="lb-pb-save">Сохранить мои правки</button>${lib.playbook_ru ? `<button id="lb-pb-clear">🧹 Очистить правила</button>` : ""}
      ${lib.playbook_at ? `<span class="muted small">обновлено ${new Date(lib.playbook_at * 1000).toLocaleString("ru")}</span>` : ""}</div>
  </div>
  ${topics.length ? `<div class="card"><h2>Темы из разборов</h2><p class="muted small">Идеи, которые продюсер предложил по мотивам удачных роликов. Можно брать как свою тему на странице нового ролика.</p>${prList(topics)}</div>` : ""}
  <div class="card"><h2>Разборы (${lib.items.length})</h2>
    ${items.length ? `<div class="row" style="gap:8px;margin-bottom:8px;flex-wrap:wrap"><button class="sm" id="lb-all">☑ Отметить все</button>
      ${[...new Set(items.map(x => x.channel || (x.title || "").replace(/^(Канал|Закономерности:)\s*/, "")).filter(Boolean))].length > 1 ? [...new Set(items.map(x => x.channel || (x.title || "").replace(/^(Канал|Закономерности:)\s*/, "")).filter(Boolean))].map(ch => `<button class="sm" data-lbch="${esc(ch)}">☑ Все «${esc(ch)}»</button>`).join("") : ""}
      <span class="grow"></span><button class="danger sm" id="lb-rm" disabled>Убрать отмеченные</button></div>` : ""}
    ${items.length ? items.map(x => `<details style="margin-bottom:8px"><summary><input type="checkbox" data-lbsel="${x.id}" data-ch="${esc(x.channel || (x.title || "").replace(/^(Канал|Закономерности:)\s*/, ""))}" style="width:auto;margin-right:6px" onclick="event.stopPropagation()"><b>${x.type === "patterns" ? "🔍 " : x.type === "channel" ? "📺 " : x.kind === "short" ? "📱 " : "🎬 "}${esc(x.title || "Без названия")}</b> <span class="muted small">${esc([x.channel, prViews(x.views)].filter(Boolean).join(" · "))}</span></summary>
      ${x.source ? `<div class="small"><a href="${esc(x.source)}" target="_blank">${esc(x.source)}</a></div>` : ""}
      ${prSection("О чём", nl(x.summary_ru))}${prSection(x.type === "patterns" ? "Закономерность" : x.type === "channel" ? "Формула хитов" : "Почему сработал", nl(x.why_ru))}
      ${prSection("Хук", nl(x.hook_ru))}${prSection(x.type === "patterns" ? "Что повторять" : "Сильные стороны", prList(x.strengths_ru))}${prSection("Чего не делать", prList(x.avoid_ru))}
      ${prSection("Приёмы для сценариста", prList(x.techniques))}
      ${prSection("Начало по-русски", nl(x.script_ru))}
      ${x.script ? `<details><summary>Текст ролика</summary><pre style="white-space:pre-wrap">${esc(x.script)}</pre></details>` : ""}
      <div class="row" style="margin-top:6px"><button class="danger sm" data-lbdel="${x.id}">Убрать из хранилища</button></div></details>`).join("")
      : `<p class="muted">Пусто. Откройте <a href="#/producer">«🎓 ИИ продюсер»</a>, разберите удачный ролик и сохраните разбор сюда.</p>`}
  </div>`;
  $("#lb-niche-save").onclick = () => api(`/api/projects/${pid}`, { json: { niche: $("#lb-niche").value } }).then(() => toast("Описание ниши сохранено")).catch(e => toast(e.message, true));
  if ($("#lb-niche-undo")) $("#lb-niche-undo").onclick = async () => {
    if (!confirm("Вернуть описание ниши, которое было до обновления продюсером?")) return;
    try { const r = await api(`/api/projects/${pid}/library/niche-undo`, { method: "POST" }); $("#lb-niche").value = r.niche; toast("Прежнее описание возвращено"); } catch (e) { toast(e.message, true); }
  };
  $("#lb-pb-save").onclick = () => api(`/api/projects/${pid}/library/playbook`, { json: { playbook_ru: $("#lb-pb").value } }).then(() => toast("Правила сохранены")).catch(e => toast(e.message, true));
  if ($("#lb-pb-clear")) $("#lb-pb-clear").onclick = async () => {
    if (!confirm("Очистить правила ниши? Сценарист перестанет их читать. Описание ниши останется.")) return;
    await api(`/api/projects/${pid}/library/playbook`, { json: { playbook_ru: "" } }).then(() => toast("Правила очищены")).catch(e => toast(e.message, true));
    viewLibrary(pid);
  };
  $("#lb-build").onclick = async () => {
    const b = $("#lb-build"); b.disabled = true; b.textContent = "⏳ Изучаю все разборы ниши…";
    try { await api(`/api/projects/${pid}/library/build`, { method: "POST" }); toast("Правила и описание ниши обновлены"); viewLibrary(pid); }
    catch (e) { toast(e.message, true); b.disabled = false; b.textContent = "✨ Обновить правила и описание ниши"; }
  };
  const sels = () => [...main.querySelectorAll("[data-lbsel]")];
  const upd = () => { const n = sels().filter(c => c.checked).length, b = $("#lb-rm"); if (b) { b.disabled = !n; b.textContent = n ? `Убрать отмеченные (${n})` : "Убрать отмеченные"; } };
  sels().forEach(c => c.onchange = upd);
  if ($("#lb-all")) $("#lb-all").onclick = () => { const on = !sels().every(c => c.checked); sels().forEach(c => c.checked = on); upd(); };
  main.querySelectorAll("[data-lbch]").forEach(b => b.onclick = () => { sels().forEach(c => { if (c.dataset.ch === b.dataset.lbch) c.checked = true; }); upd(); });
  if ($("#lb-rm")) $("#lb-rm").onclick = async () => {
    const ids = sels().filter(c => c.checked).map(c => c.dataset.lbsel);
    if (!ids.length || !confirm(`Убрать из хранилища разборов: ${ids.length}? Сценарист перестанет на них опираться, а правила и описание ниши пересоберутся без их выводов (описание можно будет вернуть кнопкой «↩»).`)) return;
    const b = $("#lb-rm"); b.disabled = true; b.textContent = "⏳ Убираю и пересобираю правила…";
    const r = await api(`/api/projects/${pid}/library/remove`, { json: { ids } }).catch(e => { toast(e.message, true); return null; });
    if (r && r.note) toast(r.note);
    viewLibrary(pid);
  };
  main.querySelectorAll("[data-lbdel]").forEach(b => b.onclick = async () => {
    if (!confirm("Убрать этот разбор из хранилища? Сценарист перестанет на него опираться, а правила и описание ниши пересоберутся без его выводов (описание можно будет вернуть кнопкой «↩»).")) return;
    b.disabled = true; b.textContent = "⏳ Убираю и пересобираю правила…";
    const r = await api(`/api/projects/${pid}/library/${b.dataset.lbdel}`, { method: "DELETE" }).catch(e => { toast(e.message, true); return null; });
    if (r && r.note) toast(r.note);
    viewLibrary(pid);
  });
}


// ---------------------------------------------------------------- local editor: timeline and render on this Mac, no API keys
async function viewLocalEditor(id) {
  navActive("local-editor");
  if (!id) {
    const projects = await api("/api/local-editor");
    main.innerHTML = `<h1>🎞️ Локальный монтаж</h1>
    <p class="muted">Полностью на этом компьютере: ваши фото, видео, озвучка и музыка. Никаких API-ключей и отправки файлов в интернет. Исходники не изменяются.</p>
    <div class="card le-new"><h2>Новый монтаж</h2><div class="row">
      <input class="grow" id="le-new-title" type="text" placeholder="Название ролика">
      <select id="le-new-format" style="width:auto"><option value="long">YouTube 16:9</option><option value="short">Shorts / Reels 9:16</option></select>
      <button class="primary" id="le-create">Создать</button></div></div>
    ${projects.length ? `<div class="le-projects">${projects.map(p => `<a class="card le-project" href="#/local-editor/${p.id}">
      <div><b>${esc(p.title)}</b><div class="muted small">${p.format === "short" ? "9:16" : "16:9"} · ${p.scenes.length} сцен · ${fmtTime(p.duration)}</div></div>
      <span class="badge ${p.render.status === "error" ? "error" : p.render.status === "running" ? "running" : p.render.final_url ? "done" : "queued"}">${p.render.final_url ? "Готово" : p.render.status === "running" ? "Собирается" : "Черновик"}</span>
      <button class="sm danger" data-le-delete="${p.id}" data-title="${esc(p.title)}">Удалить</button></a>`).join("")}</div>` : `<div class="card muted">Монтажей пока нет. Создайте первый проект выше.</div>`}`;
    $("#le-create").onclick = async () => {
      const b = $("#le-create"); b.disabled = true;
      try { const p = await api("/api/local-editor", { json: { title: $("#le-new-title").value, format: $("#le-new-format").value } }); location.hash = `#/local-editor/${p.id}`; }
      catch (e) { toast(e.message, true); b.disabled = false; }
    };
    $("#le-new-title").onkeydown = e => { if (e.key === "Enter") $("#le-create").click(); };
    main.querySelectorAll("[data-le-delete]").forEach(b => b.onclick = async e => {
      e.preventDefault(); e.stopPropagation();
      if (!confirm(`Убрать монтаж «${b.dataset.title}»? Он переместится во внутреннюю корзину.`)) return;
      try { await api(`/api/local-editor/${b.dataset.leDelete}`, { method: "DELETE" }); b.closest(".le-project").remove(); toast("Монтаж перемещён в корзину"); }
      catch (x) { toast(x.message, true); }
    });
    return;
  }

  let p = await api(`/api/local-editor/${id}`);
  const whisper = await api("/api/local-editor/whisper/info").catch(() => ({ installed: false, models: {} }));
  p.transcript = p.transcript || { status: "idle", text: "", words: [], language: "", model: "small", error: "", step: "" };
  let saveTimer = null, saving = false;
  const motionOptions = [["none", "Без движения"], ["zoom_in", "Медленное приближение"], ["zoom_out", "Медленное отдаление"], ["pan_left", "Панорама влево"], ["pan_right", "Панорама вправо"]];
  const transitionOptions = [["cut", "Обычный стык"], ["fade", "Через затемнение"]];
  const graphicOptions = [["none", "Без моушен-графики"], ["counter", "Крупная цифра / счётчик"], ["money", "Деньги"], ["percent", "Процент в круге"], ["bar", "Шкала заполнения"], ["timer", "Обратный отсчёт"], ["stopwatch", "Секундомер"], ["up", "Стрелка роста"], ["down", "Стрелка падения"], ["date", "Дата"], ["rank", "Место в рейтинге"], ["keyword", "Крупная надпись"], ["warning", "Предупреждение"], ["people", "Люди / аудитория"], ["location", "Кинематографическая локация"], ["name", "Имя / нижняя треть"], ["quote", "Цитата"], ["chapter", "Глава / раздел"], ["document", "Архивный документ"], ["secret", "Печать «Секретно»"], ["news", "Новостная плашка"], ["timeline", "Временная линия"], ["idea", "Идея / открытие"], ["trophy", "Достижение / рекорд"]];
  const graphicStyles = [["classic", "Классический"], ["glass", "Стекло"], ["neon", "Неон"], ["minimal", "Минимальный"], ["cinematic", "Кинематографический"], ["broadcast", "Эфирный"]];
  const graphicAnimations = [["pop", "Пружина"], ["slide", "Выезд сбоку"], ["pulse", "Пульс"], ["fade", "Плавное появление"]];
  const options = (items, value) => items.map(([k, n]) => `<option value="${k}" ${k === value ? "selected" : ""}>${n}</option>`).join("");
  const busy = () => p.render?.status === "running" || p.transcript?.status === "running";
  const save = async (quiet = false) => {
    clearTimeout(saveTimer); saveTimer = null;
    if (busy() || saving) return;
    saving = true; const lab = $("#le-saved"); if (lab) lab.textContent = "Сохраняю…";
    try { p = await api(`/api/local-editor/${id}`, { method: "PUT", json: p }); if ($("#le-saved")) $("#le-saved").textContent = "✓ Сохранено"; rememberTab(); if (!quiet) toast("Монтаж сохранён"); }
    catch (e) { toast(e.message, true); if ($("#le-saved")) $("#le-saved").textContent = "Ошибка сохранения"; }
    finally { saving = false; }
  };
  const saveSoon = () => { clearTimeout(saveTimer); saveTimer = setTimeout(() => save(true), 500); };
  const mediaBox = s => s.kind === "image"
    ? `<img src="${s.url}" alt="${esc(s.name)}">`
    : `<video src="${s.url}#t=${Number(s.trim_start || 0).toFixed(2)}" preload="metadata" muted></video><span class="le-play">▶</span>`;
  const sceneCard = (s, i) => { const g = s.graphic || { type: "none", value: "", unit: "", label: "", start: .2, style: "classic", animation: "pop", auto: false }; return `<article class="le-scene" data-scene="${s.id}" draggable="${busy() ? "false" : "true"}">
    <div class="le-handle" title="Перетащите сцену">⋮⋮</div><div class="le-num">${i + 1}</div><div class="le-media">${mediaBox(s)}</div>
    <div class="le-fields"><b title="${esc(s.name)}">${esc(s.name)}</b><div class="row le-compact">
      <label>Длительность <input type="number" min=".1" step=".1" data-sf="duration" value="${Number(s.duration).toFixed(2)}"> сек</label>
      ${s.kind === "video" ? `<label>Начало <input type="number" min="0" max="${s.source_duration}" step=".1" data-sf="trim_start" value="${Number(s.trim_start).toFixed(2)}"></label><label>Конец <input type="number" min=".1" max="${s.source_duration}" step=".1" data-sf="trim_end" value="${Number(s.trim_end).toFixed(2)}"></label>` : ""}
      <select data-sf="fit">${options([["cover", "Заполнить кадр"], ["contain", "Вписать целиком"]], s.fit)}</select>
      ${s.kind === "image" ? `<select data-sf="motion">${options(motionOptions, s.motion)}</select>` : ""}
      <select data-sf="transition">${options(transitionOptions, s.transition)}</select>
    </div><details class="le-scene-gfx" ${g.type !== "none" ? "open" : ""}><summary>Моушен-графика: <b>${esc((graphicOptions.find(x => x[0] === g.type) || graphicOptions[0])[1])}</b></summary>
      <div class="row le-gfx-fields"><select data-gf="type">${options(graphicOptions, g.type || "none")}</select>
      <input type="text" data-gf="value" value="${esc(g.value)}" placeholder="Значение: 75 или 1896" ${g.type === "none" ? "disabled" : ""}>
      <input type="text" data-gf="unit" value="${esc(g.unit)}" placeholder="Единица: %, ₽, млн" ${g.type === "none" ? "disabled" : ""}>
      <input type="text" data-gf="label" value="${esc(g.label)}" placeholder="Короткая подпись" ${g.type === "none" ? "disabled" : ""}>
      <select data-gf="style" ${g.type === "none" ? "disabled" : ""}>${options(graphicStyles, g.style || "classic")}</select>
      <select data-gf="animation" ${g.type === "none" ? "disabled" : ""}>${options(graphicAnimations, g.animation || "pop")}</select>
      <label>Старт <input type="number" data-gf="start" min="0" max="${Number(s.duration).toFixed(2)}" step=".1" value="${Number(g.start || 0).toFixed(1)}" ${g.type === "none" ? "disabled" : ""}> сек</label></div></details>
    </div><div class="le-actions">${s.alternate_source ? `<button class="sm" data-swap-source title="Переключить фото и видео">${s.kind === "video" ? "Фото" : "Видео"}</button>` : ""}<button class="sm" data-up title="Выше">↑</button><button class="sm" data-down title="Ниже">↓</button><button class="sm danger" data-remove title="Убрать с таймлайна">✕</button></div>
  </article>`; };
  const renderState = () => {
    const r = p.render || {};
    if (r.status === "running") return `<div class="banner info"><b>${r.quality === "final" ? "Собираю готовый ролик" : "Собираю предпросмотр"}…</b><div class="bar" style="margin-top:9px"><div style="width:${Math.round((r.progress || 0) * 100)}%"></div></div><div class="small muted" style="margin-top:5px">${Math.round((r.progress || 0) * 100)}% · окно можно оставить открытым</div></div>`;
    if (r.status === "error") return `<div class="banner bad"><b>Сборка не завершилась.</b> ${esc(r.error || "Неизвестная ошибка")}</div>`;
    return "";
  };
  const transcriptState = () => {
    const t = p.transcript || {};
    if (t.status === "running") return `<div class="banner info le-transcribe-state"><b>Whisper работает локально…</b><div class="small" style="margin-top:5px">${esc(t.step || "Распознаю речь и таймкоды слов…")}</div></div>`;
    if (t.status === "error") return `<div class="banner bad le-transcribe-state"><b>Расшифровка не завершилась.</b> ${esc(t.error || "Неизвестная ошибка")}</div>`;
    return `<div class="le-transcribe-state"></div>`;
  };
  const outputBox = () => {
    const r = p.render || {}, url = r.final_url || r.preview_url;
    if (!url) return "";
    const q = r.final_url ? "final" : "preview";
    return `<div class="card le-output"><h2>${q === "final" ? "Готовый ролик" : "Предпросмотр"}</h2><video controls src="${url}?v=${p.updated || Date.now()}" class="${p.format === "short" ? "vert" : ""}"></video>
      <div class="row" style="margin-top:10px"><a class="btn primary" href="/api/local-editor/${p.id}/output/${q}?download=true">Скачать MP4</a><span class="muted small">Файл хранится только на этом компьютере.</span></div></div>`;
  };
  const waveform = async () => {
    const canvas = $("#le-wave"); if (!canvas || !p.voice) return;
    try {
      const w = await api(`/api/local-editor/${id}/waveform/voice?points=900`); if (!$("#le-wave")) return;
      const rect = canvas.getBoundingClientRect(), scale = devicePixelRatio || 1;
      canvas.width = Math.max(300, rect.width * scale); canvas.height = 92 * scale;
      const c = canvas.getContext("2d"), W = canvas.width, H = canvas.height; c.clearRect(0, 0, W, H);
      c.fillStyle = getComputedStyle(document.documentElement).getPropertyValue("--field") || "#eee"; c.fillRect(0, 0, W, H);
      c.strokeStyle = getComputedStyle(document.documentElement).getPropertyValue("--accent") || "#0a84ff"; c.lineWidth = Math.max(scale, 1); c.beginPath();
      w.peaks.forEach((v, i) => { const x = i / Math.max(w.peaks.length - 1, 1) * W, h = Math.max(1, v * H * .46); c.moveTo(x, H / 2 - h); c.lineTo(x, H / 2 + h); }); c.stroke();
      const total = p.duration || p.scenes.reduce((n, s) => n + +s.duration, 0); if (total) {
        c.strokeStyle = "rgba(255,255,255,.75)"; c.fillStyle = "rgba(0,0,0,.65)"; c.font = `${11 * scale}px sans-serif`; let at = 0;
        p.scenes.slice(0, -1).forEach((s, i) => { at += +s.duration; const x = at / total * W; c.beginPath(); c.moveTo(x, 0); c.lineTo(x, H); c.stroke(); c.fillText(String(i + 2), x + 3 * scale, 13 * scale); });
      }
    } catch (e) { /* A waveform is helpful, but never blocks editing. */ }
  };
  const draw = () => {
    const total = p.scenes.reduce((n, s) => n + Number(s.duration || 0), 0); p.duration = total;
    const imageCount = p.scenes.filter(s => s.kind === "image").length, videoCount = p.scenes.length - imageCount;
    const tr = p.transcript || {}, modelOptions = Object.entries(whisper.models || {}).map(([k, v]) => `<option value="${k}" ${k === (tr.model || "small") ? "selected" : ""}>${esc(v.name)} · ${esc(v.size)}</option>`).join("");
    main.innerHTML = `<div class="row le-titlebar"><a class="btn sm" href="#/local-editor">← Все монтажи</a><input id="le-title" class="grow" type="text" value="${esc(p.title)}"><span id="le-saved" class="muted small">✓ Сохранено</span></div>
    <div class="le-toolbar card"><div class="row"><label>Формат <select id="le-format"><option value="long" ${p.format === "long" ? "selected" : ""}>YouTube 16:9</option><option value="short" ${p.format === "short" ? "selected" : ""}>Shorts / Reels 9:16</option></select></label>
      <label>Кадров/сек <select id="le-fps">${[24, 25, 30, 50, 60].map(x => `<option ${x === p.fps ? "selected" : ""}>${x}</option>`).join("")}</select></label>
      <span class="le-total"><b>${fmtTime(total)}</b> · ${p.scenes.length} сцен</span></div>
      <div class="row" style="margin-top:12px"><label class="btn">＋ Фото и видео<input id="le-files" type="file" accept="image/*,video/*" multiple hidden></label>
        <label class="btn">🎙 Озвучка<input id="le-voice" type="file" accept="audio/*,video/mp4,video/quicktime" hidden></label>
        <label class="btn">♫ Музыка<input id="le-music" type="file" accept="audio/*" hidden></label>
        <span id="le-uploading" class="muted small"></span></div></div>
    <div class="card le-render le-render-top"><div class="row"><h2 class="grow">Сборка</h2><span class="muted small">Всегда наверху · всё собирает FFmpeg на вашем Mac</span></div>${renderState()}<div class="row"><button id="le-preview" ${busy() || !p.scenes.length ? "disabled" : ""}>▶ Быстрый предпросмотр</button><button class="primary" id="le-final" ${busy() || !p.scenes.length ? "disabled" : ""}>Экспорт 1080p MP4</button></div></div>
    ${outputBox()}
    <div class="card le-audio"><div class="row"><h2 class="grow">Звук</h2>${p.voice ? `<span class="small">🎙 ${esc(p.voice.name)} (${fmtTime(p.voice.duration)})</span><button class="sm danger" data-audio-remove="voice">Убрать</button>` : `<span class="muted small">Озвучка не добавлена — ролик будет без голоса</span>`}</div>
      ${p.voice ? `<canvas id="le-wave"></canvas>` : ""}
      <div class="row le-musicline">${p.music ? `<span class="grow small">♫ ${esc(p.music.name)} (${fmtTime(p.music.duration)}) · автоматически повторяется до конца ролика</span><label>Громкость музыки <input id="le-music-volume" type="range" min="0" max="1" step=".01" value="${p.music_volume}"><b id="le-music-value">${Math.round(p.music_volume * 100)}%</b></label><button class="sm danger" data-audio-remove="music">Убрать</button>` : `<span class="muted small">Музыка не добавлена · короткий трек будет автоматически зациклен</span>`}</div>
      ${p.voice ? `<div class="le-whisper"><h3>Локальный Whisper</h3><div class="row">
        <select id="le-whisper-model" ${busy() ? "disabled" : ""}>${modelOptions || `<option value="small">Whisper Small</option>`}</select>
        <select id="le-whisper-lang" ${busy() ? "disabled" : ""}>${options([["", "Язык: определить автоматически"], ["ru", "Русский"], ["en", "Английский"], ["de", "Немецкий"], ["es", "Испанский"], ["fr", "Французский"]], tr.language || "")}</select>
        <button id="le-transcribe" ${busy() || !whisper.installed ? "disabled" : ""}>${tr.status === "done" ? "Расшифровать заново" : "Расшифровать голос"}</button>
        ${!whisper.installed ? `<span class="muted small">Библиотека Whisper ещё не установлена.</span>` : `<span class="muted small">Без API: звук не покидает Mac. Модель загружается один раз.</span>`}
      </div>${transcriptState()}
      ${tr.status === "done" ? `<div class="row le-transcript-tools"><b>${(tr.words || []).length} слов · язык ${esc(tr.language || "определён")}</b><span class="badge done">${p.scenes_synced ? "Сцены синхронизированы" : "Нужна синхронизация"}</span><button id="le-sync" ${!p.scenes.length ? "disabled" : ""}>Синхронизировать заново</button></div><textarea class="le-transcript" readonly>${esc(tr.text)}</textarea>` : ""}</div>` : ""}</div>
    <div class="card le-subtitles"><div class="row"><h2 class="grow">Субтитры</h2><label class="check le-subcheck"><input id="le-subs" type="checkbox" ${p.subtitles !== false ? "checked" : ""}> Показывать на видео</label>
      <select id="le-subs-pos">${options([["low", "Внизу"], ["mid_low", "Ниже середины"], ["mid", "Чуть ниже центра"], ["center", "По центру"]], p.subtitles_position || "mid_low")}</select>
      ${tr.status === "done" ? `<a class="btn sm" href="${tr.srt_url || `/api/local-editor/${p.id}/output/subtitles`}">Скачать SRT</a>` : `<span class="muted small">Появятся после расшифровки голоса Whisper.</span>`}</div></div>
    <div class="card le-graphics-master"><div class="row"><h2 class="grow">Моушен-графика</h2><label class="check le-mastercheck"><input id="le-gfx-auto" type="checkbox" ${p.graphics_auto ? "checked" : ""}> Определять автоматически</label><label class="check le-mastercheck"><input id="le-gfx-enabled" type="checkbox" ${p.graphics_enabled ? "checked" : ""}> Использовать в ролике</label></div>
      <div class="row"><button id="le-gfx-detect" ${p.transcript?.status !== "done" || !p.scenes.length || busy() ? "disabled" : ""}>Обновить автоподбор</button><span class="muted small">Whisper распознаёт цифры, имена, локации, цитаты, главы, деньги, даты, рост и предупреждения. 6 стилей и 4 варианта появления. Никаких API.</span></div></div>
    <div class="row le-timeline-head"><h2 class="grow">Таймлайн</h2><span class="muted small">Перетаскивайте сцены за ⋮⋮ или используйте стрелки</span></div>
    <div class="card le-bulk-tools"><div class="row"><b>Видео вместо фото</b>
      <button id="le-match-media" class="sm" ${busy() || !imageCount || !videoCount ? "disabled" : ""}>Сопоставить по имени или номеру</button>
      <span class="muted small">Например, 012.jpg и 012.mp4 — видео автоматически займёт место фото. Фото: ${imageCount} · видео: ${videoCount}</span></div>
      <div class="row le-bulk-motion"><b>Движение камеры для всех фото</b><select id="le-motion-all" ${busy() || !imageCount ? "disabled" : ""}>${options([["auto", "Чередовать автоматически"], ...motionOptions], "auto")}</select>
      <button id="le-apply-motion" class="sm" ${busy() || !imageCount ? "disabled" : ""}>Применить ко всем фото</button></div>
      <div class="row le-bulk-transition"><b>Переход для всех сцен</b><select id="le-transition-all" ${busy() || !p.scenes.length ? "disabled" : ""}>${options([["auto", "Чередовать автоматически"], ...transitionOptions], "auto")}</select>
      <button id="le-apply-transition" class="sm" ${busy() || !p.scenes.length ? "disabled" : ""}>Применить ко всем</button><span class="muted small">Любую сцену потом можно изменить отдельно.</span></div></div>
    <div id="le-timeline" class="le-timeline">${p.scenes.length ? p.scenes.map(sceneCard).join("") : `<label class="le-empty">Перетащите сюда фото и видео или нажмите «＋ Фото и видео»<input id="le-empty-files" type="file" accept="image/*,video/*" multiple hidden></label>`}</div>`;
    bind(); waveform();
  };
  const uploadFiles = async (files, kind) => {
    files = [...files];
    if (kind === "scene") files.sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true, sensitivity: "base" }));
    if (!files.length || busy()) return;
    const lab = $("#le-uploading");
    let replaced = 0;
    try {
      for (const [i, file] of files.entries()) {
        if (lab) lab.textContent = `Загружаю ${i + 1} из ${files.length}: ${file.name}`;
        const r = await fetch(`/api/local-editor/${id}/upload?kind=${kind}&name=${encodeURIComponent(file.name)}`, { method: "POST", body: file });
        let data = {}; try { data = await r.json(); } catch (e) { }
        if (!r.ok) throw new Error(data.error || data.detail || `Не удалось загрузить ${file.name}`);
        if (data.media_replaced) replaced++;
        p = data;
      }
      let synced = false;
      if (kind === "scene" && p.transcript?.status === "done" && p.scenes.length) {
        p = await api(`/api/local-editor/${id}/sync-scenes`, { method: "POST" }); synced = true;
        if (p.graphics_auto) p = await api(`/api/local-editor/${id}/suggest-graphics`, { method: "POST" }).catch(() => p);
      }
      draw(); toast(kind === "scene" ? (synced ? "Файлы добавлены, сцены синхронизированы с голосом" : replaced ? `Видео поставлено вместо фото: ${replaced}` : "Файлы добавлены на таймлайн") : kind === "voice" ? "Озвучка добавлена" : "Музыка добавлена");
    } catch (e) { toast(e.message, true); if (lab) lab.textContent = ""; }
  };
  const move = async (i, to) => { if (to < 0 || to >= p.scenes.length || i === to) return; const [s] = p.scenes.splice(i, 1); p.scenes.splice(to, 0, s); await save(true); draw(); };
  const startRender = async quality => {
    await save(true); const b = quality === "final" ? $("#le-final") : $("#le-preview"); if (b) b.disabled = true;
    try { await api(`/api/local-editor/${id}/render?quality=${quality}`, { method: "POST" }); p = await api(`/api/local-editor/${id}`); draw(); poll(); }
    catch (e) { toast(e.message, true); draw(); }
  };
  const startTranscription = async () => {
    const model = $("#le-whisper-model")?.value || "small", language = $("#le-whisper-lang")?.value || "";
    try { await api(`/api/local-editor/${id}/transcribe?model=${encodeURIComponent(model)}&language=${encodeURIComponent(language)}`, { method: "POST" }); p = await api(`/api/local-editor/${id}`); draw(); poll(); }
    catch (e) { toast(e.message, true); }
  };
  const poll = () => {
    clearInterval(timer); timer = setInterval(async () => {
      try { const wasRender = p.render?.status === "running", wasWhisper = p.transcript?.status === "running"; p = await api(`/api/local-editor/${id}`); if (!busy()) { clearInterval(timer); timer = null; draw(); if (wasRender && p.render.status === "done") toast(p.render.quality === "final" ? "Готовый ролик собран" : "Предпросмотр готов"); if (wasWhisper && p.transcript.status === "done") toast(p.scenes_synced ? "Whisper готов, сцены автоматически подогнаны к речи" : "Whisper закончил расшифровку"); } else { const rb = $(".le-render .banner"); if (rb && p.render?.status === "running") rb.outerHTML = renderState(); const tb = $(".le-transcribe-state"); if (tb) tb.outerHTML = transcriptState(); } }
      catch (e) { clearInterval(timer); timer = null; toast(e.message, true); }
    }, 1200);
  };
  const bind = () => {
    $("#le-title").oninput = e => { p.title = e.target.value; saveSoon(); };
    $("#le-format").onchange = e => { p.format = e.target.value; saveSoon(); };
    $("#le-fps").onchange = e => { p.fps = +e.target.value; saveSoon(); };
    $("#le-files").onchange = e => uploadFiles(e.target.files, "scene");
    $("#le-empty-files")?.addEventListener("change", e => uploadFiles(e.target.files, "scene"));
    $("#le-voice").onchange = e => uploadFiles([e.target.files[0]], "voice");
    $("#le-music").onchange = e => uploadFiles([e.target.files[0]], "music");
    $("#le-music-volume")?.addEventListener("input", e => { p.music_volume = +e.target.value; $("#le-music-value").textContent = `${Math.round(p.music_volume * 100)}%`; saveSoon(); });
    $("#le-transcribe")?.addEventListener("click", startTranscription);
    $("#le-sync")?.addEventListener("click", async () => { try { p = await api(`/api/local-editor/${id}/sync-scenes`, { method: "POST" }); draw(); toast("Сцены подогнаны к паузам и длине озвучки"); } catch (e) { toast(e.message, true); } });
    $("#le-subs")?.addEventListener("change", e => { p.subtitles = e.target.checked; saveSoon(); });
    $("#le-subs-pos")?.addEventListener("change", e => { p.subtitles_position = e.target.value; saveSoon(); });
    $("#le-gfx-enabled")?.addEventListener("change", e => { p.graphics_enabled = e.target.checked; saveSoon(); });
    $("#le-gfx-auto")?.addEventListener("change", async e => { p.graphics_auto = e.target.checked; if (e.target.checked) p.graphics_enabled = true; await save(true); if (e.target.checked && p.transcript?.status === "done" && p.scenes.length) { try { p = await api(`/api/local-editor/${id}/suggest-graphics`, { method: "POST" }); } catch (x) { } } draw(); toast(e.target.checked ? "Автоподбор моушена включён" : "Автоподбор моушена выключен"); });
    $("#le-gfx-detect")?.addEventListener("click", async () => { try { p = await api(`/api/local-editor/${id}/suggest-graphics`, { method: "POST" }); draw(); toast(`Добавлено анимаций: ${p.graphics_added || 0}`); } catch (e) { toast(e.message, true); } });
    $("#le-match-media")?.addEventListener("click", async () => { try { p = await api(`/api/local-editor/${id}/match-media`, { method: "POST" }); const count = p.media_replaced || 0; if (p.transcript?.status === "done") p = await api(`/api/local-editor/${id}/sync-scenes`, { method: "POST" }); draw(); toast(`Видео поставлено вместо фото: ${count}`); } catch (e) { toast(e.message, true); } });
    $("#le-apply-motion")?.addEventListener("click", async () => { const value = $("#le-motion-all").value, cycle = ["zoom_in", "pan_left", "zoom_out", "pan_right"]; let i = 0; p.scenes.forEach(s => { if (s.kind === "image") s.motion = value === "auto" ? cycle[i++ % cycle.length] : value; }); await save(true); draw(); toast(value === "auto" ? "Движения камеры автоматически чередуются" : "Движение применено ко всем фотографиям"); });
    $("#le-apply-transition")?.addEventListener("click", async () => { const value = $("#le-transition-all").value, cycle = ["fade", "cut"]; p.scenes.forEach((s, i) => { s.transition = value === "auto" ? cycle[i % cycle.length] : value; }); await save(true); draw(); toast(value === "auto" ? "Переходы автоматически чередуются" : value === "fade" ? "Затемнение применено ко всем сценам" : "Обычный стык применён ко всем сценам"); });
    main.querySelectorAll("[data-audio-remove]").forEach(b => b.onclick = async () => { try { p = await api(`/api/local-editor/${id}/audio/${b.dataset.audioRemove}`, { method: "DELETE" }); draw(); } catch (e) { toast(e.message, true); } });
    $("#le-preview").onclick = () => startRender("preview"); $("#le-final").onclick = () => startRender("final");
    const rows = [...main.querySelectorAll(".le-scene")];
    rows.forEach((row, i) => {
      row.querySelectorAll("[data-sf]").forEach(el => el.onchange = () => { const s = p.scenes[i], k = el.dataset.sf; s[k] = el.type === "number" ? +el.value : el.value; saveSoon(); });
      row.querySelectorAll("[data-gf]").forEach(el => {
        const event = el.tagName === "INPUT" && el.type !== "number" ? "input" : "change";
        el.addEventListener(event, () => { const s = p.scenes[i], k = el.dataset.gf; s.graphic = s.graphic || { type: "none", value: "", unit: "", label: "", start: .2, style: "classic", animation: "pop", auto: false }; s.graphic[k] = el.type === "number" ? +el.value : el.value; s.graphic.auto = false; saveSoon(); if (k === "type") draw(); });
      });
      row.querySelector("[data-up]").onclick = () => move(i, i - 1); row.querySelector("[data-down]").onclick = () => move(i, i + 1);
      row.querySelector("[data-swap-source]")?.addEventListener("click", async () => { try { p = await api(`/api/local-editor/${id}/scene/${p.scenes[i].id}/swap-source`, { method: "POST" }); draw(); toast("Источник сцены переключён"); } catch (e) { toast(e.message, true); } });
      row.querySelector("[data-remove]").onclick = async () => { p.scenes.splice(i, 1); await save(true); draw(); };
      row.querySelector("video")?.addEventListener("click", e => { if (e.target.paused) e.target.play(); else e.target.pause(); });
      row.addEventListener("dragstart", e => { row.classList.add("drag"); e.dataTransfer.setData("text/plain", String(i)); e.dataTransfer.effectAllowed = "move"; });
      row.addEventListener("dragend", () => row.classList.remove("drag"));
      row.addEventListener("dragover", e => { e.preventDefault(); row.classList.add("over"); }); row.addEventListener("dragleave", () => row.classList.remove("over"));
      row.addEventListener("drop", e => { if (e.dataTransfer?.files?.length) return; e.preventDefault(); row.classList.remove("over"); const raw = e.dataTransfer.getData("text/plain"); if (raw !== "") move(+raw, i); });
    });
    const timeline = $("#le-timeline"); ["dragenter", "dragover"].forEach(n => timeline.addEventListener(n, e => { if (e.dataTransfer?.types?.includes("Files")) { e.preventDefault(); timeline.classList.add("fileover"); } }));
    timeline.addEventListener("dragleave", () => timeline.classList.remove("fileover")); timeline.addEventListener("drop", e => { if (e.dataTransfer?.files?.length) { e.preventDefault(); timeline.classList.remove("fileover"); uploadFiles(e.dataTransfer.files, "scene"); } });
  };
  draw(); if (busy()) poll();
}

// ---------------------------------------------------------------- montage: the owner's own text and pictures
async function viewMontage() {
  const s = await api("/api/settings");
  const projs = await api("/api/projects").catch(() => []);
  let vs = VOICES || [];
  let cur = lsGet("ay_montage_proj");
  if (!projs.find(p => p.id === cur)) cur = "";
  const opt = (pairs, v) => pairs.map(([k, n]) => `<option value="${esc(k)}" ${String(k) === String(v) ? "selected" : ""}>${esc(n)}</option>`).join("");
  const draw = () => {
    const p = projs.find(x => x.id === cur) || {};
    const num = k => p[k] !== undefined && p[k] !== "" ? p[k] : s[k];
    const fmt = p.format || "long";
    main.innerHTML = `<h1>✂️ Монтаж</h1>
    <p class="muted">Соберите ролик из своего: текст, своя озвучка или голос ИИ, свои картинки и видео по сценам, своя музыка. Программа разобьёт всё на сцены, остановится, чтобы вы загрузили картинки и клипы (номер сцены в имени файла), и смонтирует по всем нашим правилам: эффекты, звуки, музыка, субтитры, кнопки «Подписаться» и «Нравится».</p>
    <div class="card">
      <label class="check"><input type="radio" name="mt-mode" value="build" checked> Собрать ролик <span class="hint">из текста или своей озвучки, своих картинок или видео</span></label>
      <label class="check"><input type="radio" name="mt-mode" value="polish"> Обработать готовый ролик <span class="hint">ролик не режется и не ускоряется: добавляются только субтитры, музыка, звуки переходов, кнопки «Подписаться» и «Нравится»</span></label>
      <div id="mt-polish" style="display:none;margin-top:8px">
        <label class="f">Готовый ролик</label><input type="file" id="mt-polishfile" accept="video/*">
        <label class="f">Отдельная озвучка <span class="hint">необязательно: если голос уже есть в ролике, субтитры сделаются по нему</span></label><input type="file" id="mt-polishvoice" accept="audio/*">
        <label class="f">Текст озвучки <span class="hint">необязательно: локальный Whisper сам расшифрует голос и поставит таймкоды слов без API-ключей</span></label><textarea id="mt-polishtext" rows="4" placeholder="Текст, который звучит в ролике"></textarea>
      </div>
    </div>
    <div class="card">
      <div class="grid2"><div>
        <label class="f">Проект <span class="hint">берутся его персонажи, стиль картинок и голос</span></label>
        <select id="mt-proj"><option value="">Без проекта (общие настройки)</option>${projs.map(x => `<option value="${x.id}" ${x.id === cur ? "selected" : ""}>${esc(x.icon || "")} ${esc(x.name)}</option>`).join("")}</select>
        <label class="f">Название ролика <span class="hint">необязательно</span></label>
        <input type="text" id="mt-title" placeholder="Например: Почему она не пишет первой">
      </div><div>
        <label class="f">Формат</label>
        <select id="mt-fmt">${opt([["short", "Шортс / рилс (вертикальный 9:16)"], ["long", "Длинный ролик (горизонтальный 16:9)"]], fmt)}</select>
        <label class="f">Язык</label>
        <select id="mt-lang">${opt(Object.entries(LANG_RU).map(([k, n]) => [k, n[0].toUpperCase() + n.slice(1)]), p.language || "ru")}</select>
      </div></div>
      <div class="mt-build"><label class="f">Текст для озвучки <span class="hint">со своей озвучкой текст необязателен: программа сама расшифрует запись. Ровно то, что будет прочитано. Пустая строка разделяет абзацы. Реплика героя своим голосом: «Имя: фраза» отдельным абзацем, имя вслух не читается</span></label>
      <textarea id="mt-text" rows="12" placeholder="Вставьте сценарий сюда"></textarea>
      <div class="muted small" id="mt-wc"></div></div>
    </div>
    <div class="card mt-build"><h2>Картинки</h2>
      <label class="check"><input type="radio" name="mt-img" value="video" checked> Одно готовое видео целиком <span class="hint">все сцены склеены; программа найдёт склейки, разрежет видео по ним, каждому кадру даст его слова из озвучки и подгонит по времени, картинки не нужны</span></label>
      <div id="mt-own-video" style="margin:6px 0 10px"><input type="file" id="mt-videofile" accept="video/*"><div class="muted small">Можно загрузить и позже, на странице ролика в шаге «Сцены».</div></div>
      <label class="check"><input type="radio" name="mt-img" value="pics"> Мои картинки сразу <span class="hint">загружаете все картинки ролика по порядку; программа сама посмотрит их и разложит текст по картинкам, оживит (если включена анимация) и смонтирует</span></label>
      <div id="mt-own-pics" style="display:none;margin:6px 0 10px"><label class="btn sm" style="cursor:pointer">🖼 Выбрать картинки<input type="file" id="mt-picfiles" accept="image/*" multiple style="display:none"></label> <label class="btn sm" style="cursor:pointer">📁 Папкой<input type="file" id="mt-picdir" accept="image/*" multiple webkitdirectory style="display:none"></label> <span class="muted small" id="mt-pics-n">Порядок по номеру в имени файла (1.png, 2.png…)</span></div>
      <label class="check"><input type="radio" name="mt-img" value="own"> Свои картинки и видео: после озвучки пауза, загружаете картинки (шаг «Сцены») и клипы (шаг «Анимация») пачкой, номер сцены в имени файла${s.images_manual !== false ? "" : ", недостающие дорисует ИИ"}</label>
      <label class="check"><input type="radio" name="mt-img" value="ai"> Все картинки рисует ИИ по тексту (в стиле проекта)</label>
    </div>
    <div class="card mt-build"><h2>Голос</h2>
      <label class="check"><input type="radio" name="mt-vsrc" value="ai" checked> Озвучивает ИИ (ElevenLabs) по тексту</label>
      <label class="check"><input type="radio" name="mt-vsrc" value="own"> Своя озвучка из файла <span class="hint">mp3, wav, m4a или видео; пауз программа не добавляет, режет запись по сценам и делает субтитры по словам</span></label>
      <div id="mt-own-voice" style="display:none;margin:6px 0 10px"><input type="file" id="mt-voicefile" accept="audio/*,video/mp4,video/quicktime"></div>
      <div class="grid2" id="mt-ai-voice"><div>
        <label class="f">Голос</label>
        <select id="mt-voice"><option value="">Как в проекте (${esc(p.voice_name || s.elevenlabs_voice_name || "общие настройки")})</option>${voiceOptions(vs, "", p.language || "ru")}</select>
        <label class="f">Стабильность (0–1) <span class="hint">меньше — эмоциональнее</span></label><input type="number" step="0.05" min="0" max="1" id="mt-voice_stability" value="${esc(num("voice_stability"))}">
        <label class="f">Похожесть на оригинал (0–1)</label><input type="number" step="0.05" min="0" max="1" id="mt-voice_similarity" value="${esc(num("voice_similarity"))}">
      </div><div>
        <label class="f">Выразительность (0–1)</label><input type="number" step="0.05" min="0" max="1" id="mt-voice_style" value="${esc(num("voice_style"))}">
        <label class="f">Скорость голоса (0.7–1.2)</label><input type="number" step="0.01" min="0.7" max="1.2" id="mt-voice_speed" value="${esc(num("voice_speed"))}">
      </div></div>
    </div>
    <div class="card"><h2>Монтаж</h2>
      <div class="grid2"><div>
        <label class="f">Музыка</label><select id="mt-music">${opt([...Object.entries(META.music_modes), ["own", "Своя музыка из файла"]], p.music_mode || "library")}</select>
        <div id="mt-own-music" style="display:none;margin:4px 0 8px"><input type="file" id="mt-musicfile" accept="audio/*"><div class="muted small">Трек сохранится и в раздел «Музыка».</div></div>
        <label class="f">Атмосфера: туман, дождь, снег <span class="hint">поверх картинок, бесплатно</span></label><select id="mt-atm">${opt([...Object.entries(META.atmos_modes), ...Object.entries(META.atmos_kinds).filter(([k]) => k !== "none").map(([k, n]) => [k, `${n}: на весь ролик`])], p.atmos_mode || s.atmos_mode || "auto")}</select>
        <label class="f">Эффекты и звуки</label><select id="mt-fx">${opt(Object.entries(META.fx_modes), p.fx_mode || s.fx_mode || "light")}</select>
        <label class="f">Скорость готового ролика <span class="hint">голос и картинка вместе, тон голоса не меняется</span></label>
        <select id="mt-speed">${opt([1, 1.05, 1.1, 1.15, 1.2, 1.25, 1.3, 1.4, 1.5].map(x => [x, x === 1 ? "Обычная" : `×${x}`]), 1)}</select>
        <label class="check"><input type="checkbox" id="mt-gfx" ${p.graphics !== false ? "checked" : ""}> Анимации данных <span class="hint">цифры, таймеры, стрелки, галочки</span></label>
        <label class="check"><input type="checkbox" id="mt-smart" ${p.subs_smart !== false ? "checked" : ""}> Субтитры в свободном месте кадра</label>
        <label class="check"><input type="checkbox" id="mt-subs" ${(fmt === "short" ? p.subs_short ?? s.subtitles_short : p.subs_video ?? s.subtitles_long) ? "checked" : ""}> Субтитры на видео</label>
      </div><div>
        <label class="f">Призыв на вертикальном видео</label><select id="mt-cta">${opt(Object.entries(META.cta_modes), p.cta_short || s.cta_short || "both")}</select>
        <label class="f">Язык кнопок призыва</label><select id="mt-cta-lang">${opt(Object.entries(META.cta_langs), p.cta_lang || s.cta_lang || "auto")}</select>
        <label class="f">Анимация сцен <span class="hint">платно</span></label><select id="mt-anim">${opt(animModes(), p.anim_mode || s.anim_mode || "off")}</select>
        <label class="f">Сколько сцен оживлять</label><input type="number" id="mt-anim-n" min="1" max="60" value="${esc(p.anim_count || 3)}">
        <label class="check"><input type="checkbox" id="mt-anim-p" ${p.anim_pause ? "checked" : ""}> Пауза перед анимацией: выбрать сцены самому</label>
      </div></div>
    </div>
    <div class="row"><button class="primary" id="mt-go">🎬 Начать монтаж</button><span class="muted small">Текст не проверяется и не переписывается.</span></div>`;
    const vsrc = () => main.querySelector('input[name="mt-vsrc"]:checked').value;
    const mode = () => main.querySelector('input[name="mt-mode"]:checked').value;
    main.querySelectorAll('input[name="mt-mode"]').forEach(r => r.onchange = () => {
      const pol = mode() === "polish";
      $("#mt-polish").style.display = pol ? "" : "none";
      main.querySelectorAll(".mt-build").forEach(x => x.style.display = pol ? "none" : "");
    });
    addLibButton($("#mt-voice"), p.language || "ru");
    main.querySelectorAll('input[name="mt-vsrc"]').forEach(r => r.onchange = () => { $("#mt-own-voice").style.display = vsrc() === "own" ? "" : "none"; $("#mt-ai-voice").style.display = vsrc() === "own" ? "none" : ""; });
    let picFiles = [];
    const pickPics = inp => { picFiles = [...inp.files].filter(f => /^image\//.test(f.type) || /\.(png|jpe?g|webp|heic|avif)$/i.test(f.name)).sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true })); $("#mt-pics-n").textContent = `Выбрано картинок: ${picFiles.length}`; };
    $("#mt-picfiles").onchange = e => pickPics(e.target); $("#mt-picdir").onchange = e => pickPics(e.target);
    main.querySelectorAll('input[name="mt-img"]').forEach(r => r.onchange = () => { const m = main.querySelector('input[name="mt-img"]:checked').value; $("#mt-own-video").style.display = m === "video" ? "" : "none"; $("#mt-own-pics").style.display = m === "pics" ? "" : "none"; });
    $("#mt-music").onchange = () => { $("#mt-own-music").style.display = $("#mt-music").value === "own" ? "" : "none"; };
    $("#mt-music").onchange();
    const ta = $("#mt-text"), wc = $("#mt-wc");
    const count = () => { const n = (ta.value.match(/[\p{L}\p{N}]+/gu) || []).length; wc.textContent = n ? `${n} слов, примерно ${(n / ({ ru: 130, de: 125, es: 160 }[$("#mt-lang").value] || 150) * 60).toFixed(0)} сек озвучки` : ""; };
    ta.oninput = count;
    $("#mt-proj").onchange = e => { cur = e.target.value; lsSet("ay_montage_proj", cur); const t = ta.value, ti = $("#mt-title").value; draw(); $("#mt-text").value = t; $("#mt-title").value = ti; $("#mt-text").oninput(); };
    $("#mt-go").onclick = async () => {
      const mf0 = $("#mt-musicfile").files[0];
      if (mode() === "polish") {
        const pf = $("#mt-polishfile").files[0], pv = $("#mt-polishvoice").files[0];
        if (!pf) return toast("Выберите готовый ролик", true);
        if ($("#mt-music").value === "own" && !mf0) return toast("Выберите файл своей музыки", true);
        $("#mt-go").disabled = true;
        const up = async (url, file, what) => { toast(`Загружаю ${what}…`); const r = await fetch(url, { method: "POST", body: file }); let d = {}; try { d = await r.json(); } catch (e) {} if (!r.ok) throw new Error(d.error || d.detail || `Не удалось загрузить ${what}`); return d; };
        try {
          const body = { polish: true, topic: $("#mt-title").value, project_id: cur, format: $("#mt-fmt").value, language: $("#mt-lang").value,
            images_pause: true, review_pause: false, idea_pause: false, music_mode: $("#mt-music").value, fx_mode: $("#mt-fx").value, atmos_mode: $("#mt-atm").value, graphics: $("#mt-gfx").checked,
            subs_smart: $("#mt-smart").checked, subs_video: $("#mt-subs").checked, subs_short: $("#mt-subs").checked, cta_short: $("#mt-cta").value, cta_lang: $("#mt-cta-lang").value, anim_mode: "off" };
          if ($("#mt-polishtext").value.trim()) body.montage_script = $("#mt-polishtext").value;
          body.own_video_upload = (await up(`/api/uploads?name=${encodeURIComponent(pf.name)}`, pf, "ролик")).id;
          if (pv) body.own_voice_upload = (await up(`/api/uploads?name=${encodeURIComponent(pv.name)}`, pv, "озвучку")).id;
          if (body.music_mode === "own") { await up(`/api/music/upload?name=${encodeURIComponent(mf0.name)}`, mf0, "музыку"); body.music_track = mf0.name; body.music_mode = "library"; }
          const jobs = await api("/api/jobs", { json: body }); toast("Обработка начата"); location.hash = `#/job/${jobs[0].id}`;
        } catch (e) { toast(e.message, true); $("#mt-go").disabled = false; }
        return;
      }
      const ownVoice = vsrc() === "own", vf = $("#mt-voicefile").files[0], mf = $("#mt-musicfile").files[0];
      const imgMode = main.querySelector('input[name="mt-img"]:checked').value, vidf = $("#mt-videofile").files[0];
      if (ownVoice && !vf) return toast("Выберите файл своей озвучки", true);
      if (!ownVoice && (ta.value.match(/[\p{L}\p{N}]+/gu) || []).length < 3) return toast("Вставьте текст сценария", true);
      if ($("#mt-music").value === "own" && !mf) return toast("Выберите файл своей музыки", true);
      const v = $("#mt-voice"), vo = v.selectedOptions[0];
      const body = { montage_script: ta.value, topic: $("#mt-title").value, project_id: cur, format: $("#mt-fmt").value, language: $("#mt-lang").value,
        images_pause: imgMode !== "ai", review_pause: false, idea_pause: false,
        voice_id: v.value || undefined, voice_name: v.value ? (vo.dataset.name || vo.textContent) : undefined,
        voice_stability: $("#mt-voice_stability").value, voice_similarity: $("#mt-voice_similarity").value, voice_style: $("#mt-voice_style").value, voice_speed: $("#mt-voice_speed").value,
        music_mode: $("#mt-music").value, fx_mode: $("#mt-fx").value, atmos_mode: $("#mt-atm").value, graphics: $("#mt-gfx").checked, subs_smart: $("#mt-smart").checked, speed_video: +$("#mt-speed").value,
        subs_video: $("#mt-subs").checked, subs_short: $("#mt-subs").checked, cta_short: $("#mt-cta").value, cta_lang: $("#mt-cta-lang").value,
        anim_mode: $("#mt-anim").value, anim_count: +$("#mt-anim-n").value, anim_pause: $("#mt-anim-p").checked };
      $("#mt-go").disabled = true;
      const send = async (url, file, what) => {
        toast(`Загружаю ${what}…`);
        const r = await fetch(url, { method: "POST", body: file });
        let d = {}; try { d = await r.json(); } catch (e) {}
        if (!r.ok) throw new Error(d.detail || d.error || `Не удалось загрузить ${what}`);
        return d;
      };
      try {
        if (imgMode === "pics") {
          if (!picFiles.length) throw new Error("Выберите свои картинки");
          body.own_pics_uploads = [];
          for (const [k, f] of picFiles.entries()) { toast(`Загружаю картинки: ${k + 1} из ${picFiles.length}`); const r = await fetch(`/api/uploads?name=${encodeURIComponent(f.name)}`, { method: "POST", body: f }); let x = {}; try { x = await r.json(); } catch (e) {} if (!r.ok) throw new Error(`${f.name}: ${x.error || x.detail || "не загрузилась"}`); body.own_pics_uploads.push(x.id); }
        }
        if (imgMode === "video" && vidf) body.own_video_upload = (await send(`/api/uploads?name=${encodeURIComponent(vidf.name)}`, vidf, "видео")).id;
        if (ownVoice) { body.own_voice_upload = (await send(`/api/uploads?name=${encodeURIComponent(vf.name)}`, vf, "озвучку")).id; delete body.voice_id; }
        if (body.music_mode === "own") { await send(`/api/music/upload?name=${encodeURIComponent(mf.name)}`, mf, "музыку"); body.music_track = mf.name; body.music_mode = "library"; }
        const jobs = await api("/api/jobs", { json: body }); draftClear(); toast("Монтаж начат"); location.hash = `#/job/${jobs[0].id}`;
      }
      catch (e) { toast(e.message, true); $("#mt-go").disabled = false; }
    };
  };
  draw();
  // The voice list comes from ElevenLabs and may be slow: the page opens at once, the list fills in when ready.
  if (!VOICES) loadVoices().then(v => {
    vs = v; const sel = $("#mt-voice"); if (!sel) return;
    const c = sel.value; sel.innerHTML = sel.options[0].outerHTML + voiceOptions(vs, c, $("#mt-lang").value); sel.value = c;
  }).catch(() => { });
}

// Строгие оформления: убираем эмодзи в начале кнопок и вкладок
(() => {
  const EMO = /^[\s\p{Extended_Pictographic}️‍]+/u;
  const SEL = "button, .btn, #tabbar a";
  const clean = root => {
    if (!document.documentElement.dataset.look) return;
    const els = root.matches && root.matches(SEL) ? [root] : [];
    if (root.querySelectorAll) els.push(...root.querySelectorAll(SEL));
    for (const el of els) {
      const t = [...el.childNodes].find(n => n.nodeType === 3 && n.textContent.trim() || n.nodeType === 1);
      if (t && t.nodeType === 3 && EMO.test(t.textContent) && (t.textContent.replace(EMO, "").trim() || el.children.length))
        t.textContent = t.textContent.replace(EMO, "");
    }
  };
  new MutationObserver(ms => ms.forEach(m => m.addedNodes.forEach(n => n.nodeType === 1 && clean(n)))).observe(document.body, { childList: true, subtree: true });
  clean(document.body);
})();
