"""ElevenLabs text-to-speech."""
import base64
import json
from pathlib import Path

from . import net
from .net import UserError

BASE = "https://api.elevenlabs.io/v1"

MODELS = [
    ("eleven_multilingual_v2", "Multilingual v2 — самый естественный, 1 кредит за символ"),
    ("eleven_turbo_v2_5", "Turbo v2.5 — в 2 раза дешевле, чуть проще звучит"),
    ("eleven_flash_v2_5", "Flash v2.5 — самый дешёвый и быстрый"),
    ("eleven_v3", "v3 — самый эмоциональный (может звучать нестабильно)"),
]


def _key(settings):
    k = settings.get("elevenlabs_key")
    if not k:
        raise UserError("Не указан ключ ElevenLabs. Вставьте его в Настройках, раздел «Озвучка».")
    return k


AUDIENCES = ("ru", "en", "de", "es", "fr", "both")


def list_voices(settings) -> list:
    r = net.request("ElevenLabs", "GET", f"{BASE}/voices", headers={"xi-api-key": _key(settings)}, timeout=60)
    out = []
    for v in r.json().get("voices", []):
        labels = {k.replace(" ", "_"): str(x).strip() for k, x in (v.get("labels") or {}).items() if x}
        auto = _audience(v)
        own = (settings.get("voice_audience") or {}).get(v["voice_id"])
        audience = own if own in AUDIENCES else auto
        flag, country = _country(labels.get("accent", ""), audience)
        out.append({"voice_id": v["voice_id"], "name": v.get("name", ""), "description": _desc_ru(labels),
                    "kind": _kind(labels, v.get("description") or ""), "flag": flag, "country": country,
                    "preview_url": v.get("preview_url", ""), "auto_audience": auto, "audience": audience})
    order = {a: i for i, a in enumerate(AUDIENCES)}
    kinds = {"male": 0, "female": 1, "child": 2, "other": 3}
    return sorted(out, key=lambda x: (order.get(x["audience"], 9), kinds[x["kind"]], x["name"].lower()))


def library(settings, gender: str = "", use_case: str = "", search: str = "", page: int = 0, language: str = "ru") -> dict:
    """Voices of one language (ru, en, de, es, fr) from the public ElevenLabs Voice Library."""
    headers = {"xi-api-key": _key(settings)}
    params = {"page_size": 30, "language": language if language in AUDIENCES[:5] else "ru", "page": max(int(page or 0), 0)}
    if gender:
        params["gender"] = gender
    if use_case:
        params["use_cases"] = use_case
    if search:
        params["search"] = search.strip()[:80]
    d = net.request("ElevenLabs", "GET", f"{BASE}/shared-voices", headers=headers, params=params, timeout=60).json()
    try:
        mine = {v["voice_id"] for v in net.request("ElevenLabs", "GET", f"{BASE}/voices", headers=headers,
                                                   timeout=60).json().get("voices", [])}
    except UserError:
        mine = set()
    out = []
    for v in d.get("voices") or []:
        labels = {"gender": v.get("gender") or "", "age": v.get("age") or "",
                  "description": v.get("descriptive") or "", "use_case": v.get("use_case") or ""}
        out.append({"voice_id": v.get("voice_id", ""), "owner": v.get("public_owner_id", ""), "name": v.get("name", ""),
                    "kind": _kind(labels, ""), "description": _desc_ru(labels),
                    "about": (v.get("description") or "")[:220], "preview_url": v.get("preview_url", ""),
                    "users": int(v.get("cloned_by_count") or 0), "added": v.get("voice_id") in mine,
                    "free": v.get("free_users_allowed", True)})
    return {"voices": out, "has_more": bool(d.get("has_more"))}


def add_from_library(settings, owner: str, voice_id: str, name: str) -> str:
    """Adds a library voice to the account's own voices (the API can only speak with those). Returns its voice_id."""
    from . import elkeys
    key = _key(settings)
    r = net.request("ElevenLabs", "POST", f"{BASE}/voices/add/{owner}/{voice_id}", headers={"xi-api-key": key},
                    json={"new_name": (name or "Голос")[:100]}, timeout=60, tries=2)
    vid = r.json().get("voice_id") or voice_id
    elkeys.remember_voice(vid, owner, voice_id, name, key)
    return vid


_WORDS_RU = {
    "male": "мужской", "female": "женский", "neutral": "нейтральный", "non-binary": "нейтральный",
    "young": "молодой", "middle aged": "средних лет", "middle_aged": "средних лет", "middle-aged": "средних лет",
    "old": "пожилой", "child": "детский", "teen": "подросток",
    "narration": "для рассказов", "narrative_story": "для рассказов", "narrative & story": "для рассказов",
    "conversational": "разговорный", "news": "дикторский, новости", "informative_educational": "обучающий",
    "educational": "обучающий", "characters": "для персонажей", "characters_animation": "для мультфильмов",
    "animation": "для мультфильмов", "social_media": "для соцсетей", "social media": "для соцсетей",
    "advertisement": "рекламный", "entertainment_tv": "для ТВ", "audiobook": "для аудиокниг", "meditation": "для медитаций",
    "video games": "для игр", "asmr": "ASMR",
    "calm": "спокойный", "deep": "низкий", "warm": "тёплый", "raspy": "хрипловатый", "soft": "мягкий",
    "strong": "сильный", "confident": "уверенный", "casual": "непринуждённый", "crisp": "чёткий",
    "authoritative": "властный", "friendly": "дружелюбный", "pleasant": "приятный", "gravelly": "грубоватый",
    "husky": "с хрипотцой", "intense": "напряжённый", "seductive": "чувственный", "upbeat": "бодрый",
    "energetic": "энергичный", "excited": "взволнованный", "sassy": "дерзкий", "mature": "зрелый",
    "professional": "профессиональный", "classy": "солидный", "expressive": "выразительный", "emotive": "эмоциональный",
    "wise": "мудрый", "smooth": "плавный", "resonant": "звучный", "playful": "игривый", "cute": "милый",
    "whispery": "шепчущий", "childish": "детский", "dramatic": "драматичный", "mysterious": "загадочный", "hoarse": "охрипший",
}


def _ru(word: str) -> str:
    w = word.lower().strip()
    return _WORDS_RU.get(w, word)


def _desc_ru(labels: dict) -> str:
    parts = [labels.get("age"), labels.get("description") or labels.get("descriptive"), labels.get("use_case")]
    return ", ".join(_ru(x) for x in parts if x)


def _kind(labels: dict, text: str) -> str:
    """male / female / child / other."""
    age = labels.get("age", "").lower()
    blob = " ".join([age, labels.get("description", ""), labels.get("descriptive", ""), text]).lower()
    if any(w in blob for w in ("child", "kid", "teen", "boy", "girl", "детск", "ребён", "ребен")):
        return "child"
    g = labels.get("gender", "").lower()
    return "male" if g == "male" else "female" if g == "female" else "other"


_COUNTRIES = [
    (("american", "us", "usa"), "🇺🇸", "США"), (("british", "english", "uk", "london", "essex"), "🇬🇧", "Великобритания"),
    (("australian",), "🇦🇺", "Австралия"), (("irish",), "🇮🇪", "Ирландия"), (("scottish",), "🏴", "Шотландия"),
    (("canadian",), "🇨🇦", "Канада"), (("indian",), "🇮🇳", "Индия"), (("african", "nigerian", "south african"), "🌍", "Африка"),
    (("russian",), "🇷🇺", "Россия и СНГ"), (("ukrainian",), "🇺🇦", "Украина"), (("belarusian",), "🇧🇾", "Беларусь"),
    (("kazakh",), "🇰🇿", "Казахстан"), (("german",), "🇩🇪", "Германия"), (("french",), "🇫🇷", "Франция"),
    (("spanish", "latin", "mexican"), "🇪🇸", "Испания / Латинская Америка"), (("italian",), "🇮🇹", "Италия"),
    (("swedish",), "🇸🇪", "Швеция"), (("transatlantic",), "🌐", "Англоязычные страны"),
]


def _country(accent: str, audience: str) -> tuple:
    a = accent.lower()
    for keys, flag, name in _COUNTRIES:
        if any(a == k or a.startswith(k + " ") or k in a.split() for k in keys):
            return flag, name
    if audience == "ru":
        return "🇷🇺", "Россия и СНГ"
    if audience == "en":
        return "🌐", "Англоязычные страны"
    if audience in ("de", "es", "fr"):
        return {"de": ("🇩🇪", "Германия"), "es": ("🇪🇸", "Испания / Латинская Америка"), "fr": ("🇫🇷", "Франция")}[audience]
    return "🌐", "Не указано"


_EN_ACCENTS = ("american", "british", "australian", "irish", "english", "canadian", "scottish", "us", "uk")


def _audience(v: dict) -> str:
    """Who a voice suits: 'ru', 'en', 'de', 'es', 'fr' (a native speaker) or 'both' (not clear / multilingual)."""
    labels = {k: str(x).lower() for k, x in (v.get("labels") or {}).items()}
    if v.get("category") == "premade":
        return "en"  # the standard ElevenLabs voices are native English speakers
    verified = {str(x.get("language", "")).lower() for x in (v.get("verified_languages") or []) if isinstance(x, dict)}
    # A voice verified for many languages says nothing about its native one.
    langs = verified if len(verified) <= 2 else set()
    langs.add(labels.get("language", ""))
    langs.add(str((v.get("fine_tuning") or {}).get("language") or "").lower())
    accent = labels.get("accent", "")
    if "ru" in langs or "russian" in langs or "russian" in accent or any("а" <= ch <= "я" for ch in v.get("name", "").lower()):
        return "ru"
    for code, name, extra in (("de", "german", ("austrian", "swiss")), ("es", "spanish", ("mexican", "latin", "castilian", "argentinian", "colombian")),
                              ("fr", "french", ("parisian", "québécois", "quebecois", "belgian"))):
        if code in langs or name in langs or name in accent or any(a in accent for a in extra):
            return code
    if langs & {"en", "english"} or any(a in accent.split() or accent.startswith(a) for a in _EN_ACCENTS):
        return "en"
    return "both"


def account_info(settings) -> dict:
    r = net.request("ElevenLabs", "GET", f"{BASE}/user/subscription", headers={"xi-api-key": _key(settings)}, timeout=60)
    d = r.json()
    return {"tier": d.get("tier"), "used": d.get("character_count"), "limit": d.get("character_limit")}


def _unit(v, default: float) -> float:
    try:
        return min(1.0, max(0.0, float(v)))
    except (TypeError, ValueError):
        return default


BLOCKED = ("ElevenLabs не пустил: он блокирует доступ из России и с некоторых серверов VPN. "
           "Включите VPN или смените его сервер на другую страну и запустите шаг ещё раз.")


def is_audio(head: bytes) -> bool:
    """An mp3 starts with an ID3 tag or an MPEG frame; a blocked request brings back an HTML page instead."""
    return head[:3] == b"ID3" or (len(head) > 1 and head[0] == 0xFF and head[1] & 0xE0 == 0xE0)


def synthesize(settings, text: str, out_path: Path, previous_text: str = "", next_text: str = "",
               language: str = "") -> int:
    """Writes an mp3 file. Returns the number of characters billed. When the credits of the working key run out,
    the next reserve key takes over (settings["elevenlabs_key"] is changed in place), and a library voice is added
    to that account by itself."""
    from . import elkeys
    voice = settings.get("elevenlabs_voice_id") or "JBFqnCBsd6RMkjVDRZzb"
    if settings.get("voice_provider") == "royal":
        return _royal(settings, text, out_path, language)
    readded = set()
    for _ in range(len(elkeys.all_keys()) + 3):
        key = _key(settings)
        try:
            return _synthesize(dict(settings, elevenlabs_voice_id=elkeys.voice_for(key, voice)), text, out_path,
                               previous_text, next_text, language)
        except UserError as e:
            msg = str(e)
            if "закончились деньги" in msg or "лимит на аккаунте" in msg:
                if elkeys.switch(settings, key):
                    continue
                if len(elkeys.all_keys()) > 1:
                    raise UserError("ElevenLabs: на всех ваших ключах закончились кредиты. Добавьте новый ключ в "
                                    "Настройках → «2. Озвучка» → «Запасные ключи ElevenLabs» и нажмите «Продолжить».")
                raise
            info = elkeys.known_voice(voice)
            if ("voice_not_found" in msg or "(404)" in msg) and not info:
                info = _learn_voice(voice)
            if ("voice_not_found" in msg or "(404)" in msg) and info and key not in readded:
                # A library voice is personal to an account: it is added to this account too.
                readded.add(key)
                new = add_from_library(settings, info["owner"], info["public_id"], info.get("name", ""))
                elkeys.set_voice(key, voice, new)
                continue
            if "voice_not_found" in msg or "(404)" in msg:
                raise UserError("ElevenLabs: этого голоса нет в аккаунте ключа, который сейчас работает (голоса из "
                                "библиотеки у каждого аккаунта свои). Выберите голос заново через «🌍 Библиотека "
                                "голосов»: программа запомнит его и сама добавит в другие аккаунты.")
            raise
    raise UserError("ElevenLabs: не получилось озвучить ни с одним ключом.")


# ElevenLabs model names at RoyalTechno, and the voice settings each one takes there.
ROYAL_MODELS = {"eleven_multilingual_v2": "eleven-multilingual-v2", "eleven_v3": "eleven-v3",
                "eleven_v4": "eleven-v4", "eleven_flash_v2_5": "eleven-flash-v2.5", "eleven_turbo_v2_5": "eleven-flash-v2.5"}


def _royal(settings, text: str, out_path: Path, language: str = "") -> int:
    """The same ElevenLabs voices through RoyalTechno (much cheaper per character). It gives no word timings, so the
    subtitles are spread over the speech by word length."""
    from . import elkeys, royal
    voice = settings.get("elevenlabs_voice_id") or "JBFqnCBsd6RMkjVDRZzb"
    info = elkeys.known_voice(voice) or {}
    voice = info.get("public_id") or voice  # a library voice added to an account: its original id
    model = ROYAL_MODELS.get(settings.get("elevenlabs_model") or "eleven_multilingual_v2", "eleven-multilingual-v2")
    stability = _unit(settings.get("voice_stability", 0.5), 0.5)
    if model in ("eleven-v3", "eleven-v4"):
        vs = {"stability": min((0.0, 0.5, 1.0), key=lambda x: abs(x - stability))}
    elif model == "eleven-flash-v2.5":
        vs = {"stability": stability, "similarity_boost": _unit(settings.get("voice_similarity", 0.75), 0.75),
              "speed": min(1.2, max(0.7, float(settings.get("voice_speed", 1.0))))}
    else:
        vs = {"stability": stability, "similarity_boost": _unit(settings.get("voice_similarity", 0.75), 0.75),
              "style": _unit(settings.get("voice_style", 0.0), 0.0), "use_speaker_boost": True,
              "speed": float(settings.get("voice_speed", 1.0))}
    inp = {"prompt": text, "voice": voice, "voice_settings": vs}
    if language:
        inp["language"] = language
    try:
        out = royal.run(settings, model, inp, poll=3, limit=5 * 60)
    except UserError as e:
        if "voice_not_available" in str(e) or "voice" in str(e).lower() and "(400)" in str(e):
            raise UserError("RoyalTechno не даёт этот голос (у них доступны не все голоса ElevenLabs). Выберите в "
                            "Настройках → «Озвучка» другой голос, например стандартный George, или переключите "
                            "озвучку обратно на ElevenLabs напрямую.")
        raise
    audio = royal.fetch(out["url"], 500)
    if not is_audio(audio[:16]):
        raise UserError("RoyalTechno вернул вместо звука что-то другое. Попробуйте ещё раз.")
    royal.save(audio, out_path)
    out_path.with_suffix(".json").unlink(missing_ok=True)
    from . import balance
    balance.record("royaltechno", round(len(text) / 1000 * 0.03, 4))
    return len(text)


def _learn_voice(voice: str) -> dict:
    """A library voice chosen before the reserve keys existed: its owner is read from an account that has it."""
    from . import elkeys
    for k in elkeys.all_keys():
        try:
            v = net.request("ElevenLabs", "GET", f"{BASE}/voices/{voice}", headers={"xi-api-key": k}, timeout=30,
                            tries=1).json()
        except (UserError, ValueError):
            continue
        sh = v.get("sharing") or {}
        owner, public = sh.get("public_owner_id"), sh.get("original_voice_id")
        if owner and public:
            elkeys.remember_voice(voice, owner, public, v.get("name", ""), k)
            return elkeys.known_voice(voice)
    return {}


def _synthesize(settings, text: str, out_path: Path, previous_text: str = "", next_text: str = "",
                language: str = "") -> int:
    model = settings.get("elevenlabs_model") or "eleven_multilingual_v2"
    voice = settings.get("elevenlabs_voice_id") or "JBFqnCBsd6RMkjVDRZzb"
    stability = _unit(settings.get("voice_stability", 0.5), 0.5)
    if model == "eleven_v3":
        stability = min((0.0, 0.5, 1.0), key=lambda x: abs(x - stability))  # v3 takes only these three
    body = {
        "text": text,
        "model_id": model,
        "voice_settings": {
            "stability": stability,
            "similarity_boost": _unit(settings.get("voice_similarity", 0.75), 0.75),
            "style": _unit(settings.get("voice_style", 0.0), 0.0),
            "use_speaker_boost": True,
            "speed": float(settings.get("voice_speed", 1.0)),
        },
    }
    if language and "v2_5" in model:
        body["language_code"] = language  # Turbo and Flash v2.5 otherwise guess the language and read numbers badly
    if model != "eleven_v3":
        # Context around the fragment keeps intonation continuous between scenes.
        if previous_text:
            body["previous_text"] = previous_text[-1000:]
        if next_text:
            body["next_text"] = next_text[:1000]
    headers = {"xi-api-key": _key(settings)}
    params = {"output_format": "mp3_44100_128"}
    audio, alignment = None, None
    try:
        # The timestamps endpoint also returns when each character is spoken: used for subtitles.
        r = net.request("ElevenLabs", "POST", f"{BASE}/text-to-speech/{voice}/with-timestamps",
                        params=params, headers=headers, json=body, timeout=300)
        if b"Access restricted" in r.content[:4000]:
            raise UserError(BLOCKED)
        d = r.json()
        audio = base64.b64decode(d.get("audio_base64") or "")
        alignment = d.get("alignment") or d.get("normalized_alignment")
    except (UserError, ValueError) as e:
        if any(w in str(e) for w in ("ключ", "денег", "лимит", "кредит", "VPN")):
            raise
    if not audio or len(audio) < 500:
        r = net.request("ElevenLabs", "POST", f"{BASE}/text-to-speech/{voice}", params=params,
                        headers={**headers, "Accept": "audio/mpeg"}, json=body, timeout=300)
        audio = r.content
        alignment = None
        out_path.with_suffix(".json").unlink(missing_ok=True)
    if not audio or len(audio) < 500:
        raise UserError("ElevenLabs вернул пустой звук. Попробуйте ещё раз.")
    if not is_audio(audio[:16]):
        raise UserError(BLOCKED if b"Access restricted" in audio else
                        "ElevenLabs вернул вместо звука веб-страницу. Проверьте VPN и запустите шаг ещё раз.")
    tmp = out_path.with_suffix(".part")
    tmp.write_bytes(audio)
    tmp.replace(out_path)
    if alignment and alignment.get("characters"):
        out_path.with_suffix(".json").write_text(json.dumps(alignment), encoding="utf-8")
    return len(text)


def _words(items) -> list:
    """[(word, start, end)] with real words only (no spaces, no sound tags like "(laughter)")."""
    out = []
    for w in items or []:
        t = (w.get("text") or "").strip()
        if not t or w.get("type") in ("spacing", "audio_event") or not any(ch.isalnum() for ch in t):
            continue
        out.append((t, float(w.get("start") or 0), float(w.get("end") or w.get("start") or 0)))
    return out


def align(settings, audio: Path, text: str) -> list:
    """When each word of the owner's own narration is spoken: his text matched to his recording (ElevenLabs)."""
    r = net.request("ElevenLabs", "POST", f"{BASE}/forced-alignment", headers={"xi-api-key": _key(settings)},
                    files={"file": (audio.name, audio.read_bytes())}, data={"text": text}, timeout=900, tries=3)
    if b"Access restricted" in r.content[:4000]:
        raise UserError(BLOCKED)
    words = _words(r.json().get("words"))
    if not words:
        raise UserError("ElevenLabs не смог сопоставить ваш текст с озвучкой. Проверьте, что текст тот же, что звучит.")
    return words


def transcribe(settings, audio: Path, language: str = "") -> tuple:
    """The owner's own narration turned into text with the time of every word: (text, [(word, start, end)])."""
    data = {"model_id": "scribe_v2", "timestamps_granularity": "word", "tag_audio_events": "false"}
    if language:
        data["language_code"] = language
    r = net.request("ElevenLabs", "POST", f"{BASE}/speech-to-text", headers={"xi-api-key": _key(settings)},
                    files={"file": (audio.name, audio.read_bytes())}, data=data, timeout=900, tries=3)
    if b"Access restricted" in r.content[:4000]:
        raise UserError(BLOCKED)
    d = r.json()
    words = _words(d.get("words"))
    if not words:
        raise UserError("В вашей озвучке не нашлось речи. Проверьте файл.")
    return (d.get("text") or " ".join(w[0] for w in words)).strip(), words
