"""A small, fully local, non-destructive video editor.

Projects live next to the rest of the application data.  Original uploads are never
changed: the renderer only reads them and writes preview/final files into ``render``.
No network service or API key is used by this module.
"""
from __future__ import annotations

import array
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
from copy import deepcopy
from pathlib import Path

from fastapi import APIRouter, Body, HTTPException, Request
from fastapi.responses import FileResponse

from . import captions, editing_styles, effects, graphics, local_whisper, media, tts
from .config import DATA_DIR, load_settings
from .net import UserError


router = APIRouter(prefix="/api/local-editor", tags=["local-editor"])
ROOT = DATA_DIR / "local_editor"
TRASH = ROOT / ".trash"
IMAGE_EXT = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tif", ".tiff", ".avif", ".heic"}
VIDEO_EXT = {".mp4", ".mov", ".m4v", ".webm", ".mkv", ".avi"}
AUDIO_EXT = {".mp3", ".wav", ".m4a", ".aac", ".ogg", ".flac", ".opus", ".webm", ".mp4", ".mov"}
PROJECT_ID = re.compile(r"[0-9a-f]{12}")
FILE_ID = re.compile(r"[0-9a-f]{12}\.[a-z0-9]{2,6}")
_lock = threading.RLock()
_rendering: set[str] = set()
_transcribing: set[str] = set()
LOCAL_GRAPHICS = {"none", "counter", "money", "percent", "bar", "timer", "stopwatch", "up", "down", "date", "rank", "keyword", "warning", "people", "location", "idea", "trophy", "name", "quote", "chapter", "document", "secret", "news", "timeline"}
GRAPHIC_STYLES = {"classic", "glass", "neon", "minimal", "cinematic", "broadcast"}
GRAPHIC_ANIMATIONS = {"pop", "slide", "pulse", "fade"}
SUBTITLE_PRESETS = {"documentary", "karaoke", "words", "shorts", "clean", "box"}
SUBTITLE_FONTS = {"auto", "arial_black", "impact", "arial_bold"}
SUBTITLE_SIZES = {"small", "medium", "large"}


class RenderCancelled(Exception):
    pass


def _now() -> int:
    return int(time.time())


def _project_dir(project_id: str) -> Path:
    if not PROJECT_ID.fullmatch(project_id or ""):
        raise HTTPException(404)
    path = ROOT / project_id
    if not path.is_dir():
        raise HTTPException(404)
    return path


def _read(project_id: str) -> dict:
    path = _project_dir(project_id) / "edit.json"
    try:
        return json.loads(path.read_text("utf-8"))
    except (OSError, ValueError) as exc:
        raise UserError(f"Не удалось открыть проект монтажа: {exc}") from exc


def _write(project: dict) -> dict:
    with _lock:
        path = _project_dir(project["id"]) / "edit.json"
        project["updated"] = _now()
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(project, ensure_ascii=False, indent=2), "utf-8")
        tmp.replace(path)
    return project


def _duration(path: Path) -> float:
    return max(media.video_duration(path), 0.05)


def _public(project: dict) -> dict:
    out = deepcopy(project)
    pid = project["id"]
    for scene in out.get("scenes", []):
        scene["url"] = f"/api/local-editor/{pid}/media/{scene['source']}"
    for kind in ("voice", "music", "ambience"):
        if out.get(kind):
            out[f"{kind}_url"] = f"/api/local-editor/{pid}/media/{out[kind]['source']}"
    render = out.setdefault("render", {})
    for quality in ("preview", "final"):
        name = f"{quality}.mp4"
        if (_project_dir(pid) / "render" / name).is_file():
            render[f"{quality}_url"] = f"/api/local-editor/{pid}/output/{quality}"
    if (_project_dir(pid) / "render" / "subtitles.srt").is_file():
        out.setdefault("transcript", {})["srt_url"] = f"/api/local-editor/{pid}/output/subtitles"
    out["duration"] = round(sum(float(s.get("duration") or 0) for s in out.get("scenes", [])), 3)
    return out


def _default_project(project_id: str, title: str, format_: str) -> dict:
    return {
        "id": project_id,
        "title": title.strip() or "Новый монтаж",
        "format": "short" if format_ == "short" else "long",
        "fps": 30,
        "music_volume": 0.12,
        "ambience_volume": 0.06,
        "auto_sfx": True,
        "sfx_volume": 0.18,
        "edit_style": "auto",
        "edit_tempo": "balanced",
        "effect_level": "normal",
        "color_look": "auto",
        "resolved_color_look": "natural",
        "avoid_repeats": True,
        "auto_duck": True,
        "voice_cleanup": True,
        "voice_tone": "auto",
        "resolved_voice_tone": "natural",
        "audio_master": True,
        "plan_revision": 0,
        "plan": {},
        "transcription_provider": "local",
        "graphics_enabled": False,
        "graphics_auto": False,
        "subtitles": True,
        "subtitles_position": "mid_low",
        "subtitle_preset": "documentary",
        "subtitle_font": "auto",
        "subtitle_size": "medium",
        "scenes_synced": False,
        "voice": None,
        "music": None,
        "ambience": None,
        "scenes": [],
        "transcript": {"status": "idle", "text": "", "words": [], "language": "", "model": "small", "error": "", "step": ""},
        "render": {"status": "idle", "progress": 0, "quality": "", "error": ""},
        "render_speed": "fast",
        "created": _now(),
        "updated": _now(),
    }


@router.get("")
def list_projects():
    ROOT.mkdir(parents=True, exist_ok=True)
    projects = []
    for path in ROOT.iterdir():
        if not path.is_dir() or not PROJECT_ID.fullmatch(path.name):
            continue
        try:
            projects.append(_public(json.loads((path / "edit.json").read_text("utf-8"))))
        except (OSError, ValueError):
            continue
    projects.sort(key=lambda p: p.get("updated", 0), reverse=True)
    return projects


@router.post("")
def create_project(data: dict = Body(default={})):
    ROOT.mkdir(parents=True, exist_ok=True)
    project_id = uuid.uuid4().hex[:12]
    path = ROOT / project_id
    (path / "media").mkdir(parents=True)
    (path / "render").mkdir()
    project = _default_project(project_id, str(data.get("title") or ""), str(data.get("format") or "long"))
    (path / "edit.json").write_text(json.dumps(project, ensure_ascii=False, indent=2), "utf-8")
    return _public(project)


@router.get("/{project_id}")
def get_project(project_id: str):
    project = _read(project_id)
    if project.get("render", {}).get("status") == "running" and project_id not in _rendering:
        project["render"].update(status="error", error="Сборка была прервана. Запустите её ещё раз.")
        _write(project)
    if project.get("transcript", {}).get("status") == "running" and project_id not in _transcribing:
        project["transcript"].update(status="error", error="Расшифровка была прервана. Запустите её ещё раз.")
        _write(project)
    return _public(project)


def _number(value, default: float, low: float, high: float) -> float:
    try:
        return min(max(float(value), low), high)
    except (TypeError, ValueError):
        return default


def _folder_size(path: Path) -> int:
    total = 0
    if not path.is_dir():
        return 0
    for root, _dirs, files in os.walk(path, followlinks=False):
        for name in files:
            try:
                total += (Path(root) / name).stat().st_size
            except OSError:
                pass
    return total


def _forget_project_history(project_id: str):
    history_path = ROOT / ".editing-history.json"
    try:
        history = json.loads(history_path.read_text("utf-8"))
    except (OSError, ValueError):
        return
    if not isinstance(history, list):
        return
    kept = [item for item in history if item.get("project_id") != project_id]
    if kept:
        history_path.write_text(json.dumps(kept, ensure_ascii=False, indent=2), "utf-8")
    else:
        history_path.unlink(missing_ok=True)


@router.put("/{project_id}")
def update_project(project_id: str, data: dict = Body(...)):
    project = _read(project_id)
    project["title"] = str(data.get("title", project["title"]))[:200].strip() or "Новый монтаж"
    project["format"] = "short" if data.get("format") == "short" else "long"
    project["fps"] = int(_number(data.get("fps", project.get("fps", 30)), 30, 24, 60))
    project["music_volume"] = _number(data.get("music_volume", project.get("music_volume", .12)), .12, 0, 1)
    project["ambience_volume"] = _number(data.get("ambience_volume", project.get("ambience_volume", .06)), .06, 0, .5)
    project["auto_sfx"] = bool(data.get("auto_sfx", project.get("auto_sfx", True)))
    project["sfx_volume"] = _number(data.get("sfx_volume", project.get("sfx_volume", .18)), .18, 0, .8)
    project["edit_style"] = data.get("edit_style") if data.get("edit_style") in editing_styles.STYLE_IDS | {"auto"} else "auto"
    project["edit_tempo"] = data.get("edit_tempo") if data.get("edit_tempo") in editing_styles.TEMPOS else "balanced"
    project["effect_level"] = data.get("effect_level") if data.get("effect_level") in editing_styles.EFFECT_LEVELS else "normal"
    project["color_look"] = data.get("color_look") if data.get("color_look") in editing_styles.COLOR_LOOKS else "auto"
    if project["color_look"] != "auto":
        project["resolved_color_look"] = project["color_look"]
    else:
        project["resolved_color_look"] = data.get("resolved_color_look") if data.get("resolved_color_look") in editing_styles.COLOR_LOOKS - {"auto"} else project.get("resolved_color_look", "natural")
    project["avoid_repeats"] = bool(data.get("avoid_repeats", project.get("avoid_repeats", True)))
    project["auto_duck"] = bool(data.get("auto_duck", project.get("auto_duck", True)))
    project["voice_cleanup"] = bool(data.get("voice_cleanup", project.get("voice_cleanup", True)))
    project["voice_tone"] = data.get("voice_tone") if data.get("voice_tone") in editing_styles.VOICE_TONES else "auto"
    if project["voice_tone"] != "auto":
        project["resolved_voice_tone"] = project["voice_tone"]
    else:
        project["resolved_voice_tone"] = data.get("resolved_voice_tone") if data.get("resolved_voice_tone") in editing_styles.VOICE_TONES - {"auto"} else project.get("resolved_voice_tone", "natural")
    project["audio_master"] = bool(data.get("audio_master", project.get("audio_master", True)))
    project["transcription_provider"] = data.get("transcription_provider") if data.get("transcription_provider") in ("local", "elevenlabs", "auto") else project.get("transcription_provider", "local")
    project["render_speed"] = data.get("render_speed") if data.get("render_speed") in ("fast", "quality") else project.get("render_speed", "fast")
    project["graphics_enabled"] = bool(data.get("graphics_enabled", project.get("graphics_enabled", False)))
    project["graphics_auto"] = bool(data.get("graphics_auto", project.get("graphics_auto", False)))
    project["subtitles"] = bool(data.get("subtitles", project.get("subtitles", True)))
    project["subtitles_position"] = data.get("subtitles_position") if data.get("subtitles_position") in captions.POSITIONS else "mid_low"
    project["subtitle_preset"] = data.get("subtitle_preset") if data.get("subtitle_preset") in SUBTITLE_PRESETS else "documentary"
    project["subtitle_font"] = data.get("subtitle_font") if data.get("subtitle_font") in SUBTITLE_FONTS else "auto"
    project["subtitle_size"] = data.get("subtitle_size") if data.get("subtitle_size") in SUBTITLE_SIZES else "medium"
    current = {s["id"]: s for s in project.get("scenes", [])}
    if isinstance(data.get("scenes"), list):
        scenes = []
        for sent in data["scenes"]:
            old = current.get(str(sent.get("id") or ""))
            if not old:
                continue
            scene = deepcopy(old)
            scene["fit"] = sent.get("fit") if sent.get("fit") in ("cover", "contain") else "cover"
            scene["motion"] = sent.get("motion") if sent.get("motion") in editing_styles.MOTIONS else "none"
            scene["transition"] = sent.get("transition") if sent.get("transition") in editing_styles.TRANSITIONS else "cut"
            scene["effect"] = sent.get("effect") if sent.get("effect") in effects.EFFECTS else str(old.get("effect") or "none")
            scene["sfx"] = sent.get("sfx") if sent.get("sfx") in effects.SFX else str(old.get("sfx") or "none")
            raw_graphic = sent.get("graphic") if isinstance(sent.get("graphic"), dict) else {}
            graphic_type = str(raw_graphic.get("type") or "none")
            if graphic_type not in LOCAL_GRAPHICS:
                graphic_type = "none"
            scene["graphic"] = {
                "type": graphic_type,
                "value": str(raw_graphic.get("value") or "")[:30],
                "unit": str(raw_graphic.get("unit") or "")[:12],
                "label": str(raw_graphic.get("label") or "")[:60],
                "start": round(_number(raw_graphic.get("start"), .2, 0, 3600), 2),
                "style": raw_graphic.get("style") if raw_graphic.get("style") in GRAPHIC_STYLES else "classic",
                "animation": raw_graphic.get("animation") if raw_graphic.get("animation") in GRAPHIC_ANIMATIONS else "pop",
                "auto": bool(raw_graphic.get("auto", False)),
            }
            scene["duration"] = _number(sent.get("duration"), float(old.get("duration") or 5), .1, 3600)
            if scene["kind"] == "video":
                source_duration = float(scene.get("source_duration") or scene["duration"])
                scene["trim_start"] = _number(sent.get("trim_start"), float(old.get("trim_start") or 0), 0, max(source_duration - .1, 0))
                scene["trim_end"] = _number(sent.get("trim_end"), float(old.get("trim_end") or source_duration), scene["trim_start"] + .1, source_duration)
            scenes.append(scene)
        project["scenes"] = scenes
    project["render"] = {"status": "idle", "progress": 0, "quality": "", "error": ""}
    return _public(_write(project))


@router.delete("/{project_id}")
def delete_project(project_id: str):
    path = _project_dir(project_id)
    if project_id in _rendering or project_id in _transcribing:
        raise UserError("Сначала дождитесь окончания текущей обработки.")
    freed = _folder_size(path)
    shutil.rmtree(path)
    _forget_project_history(project_id)
    return {"ok": True, "recoverable": False, "bytes_freed": freed}


@router.get("/maintenance/trash")
def trash_info():
    count = sum(1 for path in TRASH.iterdir() if path.is_dir()) if TRASH.is_dir() else 0
    return {"count": count, "bytes": _folder_size(TRASH)}


@router.delete("/maintenance/trash")
def empty_old_trash():
    freed = _folder_size(TRASH)
    count = sum(1 for path in TRASH.iterdir() if path.is_dir()) if TRASH.is_dir() else 0
    if TRASH.is_dir():
        shutil.rmtree(TRASH)
    return {"ok": True, "count": count, "bytes_freed": freed}


def _upload_ext(name: str, kind: str) -> tuple[str, str]:
    ext = Path(name).suffix.lower()
    if kind == "scene":
        if ext in IMAGE_EXT:
            return ext, "image"
        if ext in VIDEO_EXT:
            return ext, "video"
        raise UserError("Для таймлайна подходят картинки JPG, PNG, WEBP и видео MP4, MOV, WEBM, MKV.")
    if kind in ("voice", "music", "ambience") and ext in AUDIO_EXT:
        return ext, "audio"
    raise UserError("Для озвучки и музыки подходят MP3, WAV, M4A, AAC, OGG, FLAC, OPUS или звук из видео.")


def _media_identity(name: str) -> tuple[str, str]:
    stem = Path(name).stem.lower().replace("ё", "е")
    stem = re.sub(
        r"(?:[\s_.-]*(?:video|vid|clip|animated|animation|motion|image|img|photo|"
        r"видео|клип|анимация|оживленное|оживленная|оживленный|фото|картинка))+$",
        "", stem,
    )
    core = re.sub(r"[^a-zа-я0-9]+", "", stem)
    numbers = re.findall(r"\d+", Path(name).stem)
    number = str(int(numbers[-1])) if numbers else ""
    return core, number


def _image_focus(path: Path) -> tuple[float, float]:
    """Estimate a useful focal point from local detail, without a model or network call."""
    try:
        from PIL import Image, ImageFilter, ImageStat
        with Image.open(path) as source:
            image = source.convert("L")
            image.thumbnail((320, 320))
            if ImageStat.Stat(image).stddev[0] < 6:
                return .5, .5
            edges = image.filter(ImageFilter.FIND_EDGES)
        cols, rows = 5, 5
        cw, ch = max(edges.width // cols, 1), max(edges.height // rows, 1)
        ranked = []
        for row in range(rows):
            for col in range(cols):
                box = (col * cw, row * ch, min((col + 1) * cw, edges.width), min((row + 1) * ch, edges.height))
                detail = ImageStat.Stat(edges.crop(box)).mean[0]
                distance = ((col + .5) / cols - .5) ** 2 + ((row + .5) / rows - .5) ** 2
                ranked.append((detail * (1 - min(distance, .35)), col, row))
        _score, col, row = max(ranked)
        return round(min(max((col + .5) / cols, .18), .82), 3), round(min(max((row + .5) / rows, .18), .82), 3)
    except (OSError, ValueError, ImportError):
        return .5, .5


def _matching_scene(scenes: list[dict], name: str, kind: str) -> dict | None:
    candidates = [scene for scene in scenes if scene.get("kind") == kind]
    core, number = _media_identity(name)
    exact = [scene for scene in candidates if core and _media_identity(str(scene.get("name") or ""))[0] == core]
    if len(exact) == 1:
        return exact[0]
    numbered = [scene for scene in candidates if number and _media_identity(str(scene.get("name") or ""))[1] == number]
    return numbered[0] if len(numbered) == 1 else None


def _source_snapshot(scene: dict) -> dict:
    return {key: scene.get(key) for key in ("source", "name", "kind", "source_duration", "trim_start", "trim_end", "focus_x", "focus_y")}


def _activate_source(scene: dict, source: dict):
    duration = float(scene.get("duration") or source.get("source_duration") or 5)
    scene.update({key: source.get(key) for key in ("source", "name", "kind", "source_duration", "trim_start", "trim_end", "focus_x", "focus_y")})
    scene["duration"] = duration


@router.post("/{project_id}/upload")
async def upload(project_id: str, request: Request, name: str, kind: str = "scene"):
    project = _read(project_id)
    ext, media_kind = _upload_ext(Path(name).name, kind)
    raw = await request.body()
    if not raw:
        raise UserError("Файл пустой.")
    if len(raw) > 2 * 1024 * 1024 * 1024:
        raise UserError("Файл больше 2 ГБ.")
    filename = uuid.uuid4().hex[:12] + ext
    path = _project_dir(project_id) / "media" / filename
    path.write_bytes(raw)
    try:
        if kind == "scene":
            source_duration = _duration(path) if media_kind == "video" else 5.0
            source = {
                "source": filename, "name": Path(name).name, "kind": media_kind,
                "source_duration": round(source_duration, 3), "trim_start": 0,
                "trim_end": round(source_duration, 3), "focus_x": .5, "focus_y": .5,
            }
            if media_kind == "image":
                source["focus_x"], source["focus_y"] = _image_focus(path)
            opposite = "image" if media_kind == "video" else "video"
            matched = _matching_scene(project.get("scenes", []), Path(name).name, opposite)
            replaced = False
            if matched and media_kind == "video":
                matched["alternate_source"] = _source_snapshot(matched)
                _activate_source(matched, source)
                replaced = True
            elif matched:  # A photo uploaded after its video is kept as the optional still source.
                matched["alternate_source"] = source
                replaced = True
            else:
                scene = {
                    "id": uuid.uuid4().hex[:12], "source": filename, "name": Path(name).name,
                    "kind": media_kind, "source_duration": round(source_duration, 3),
                    "trim_start": 0, "trim_end": round(source_duration, 3),
                    "focus_x": source["focus_x"], "focus_y": source["focus_y"],
                    "duration": round(source_duration, 3), "fit": "cover", "motion": "none", "transition": "cut",
                    "effect": "none", "sfx": "none",
                    "graphic": {"type": "none", "value": "", "unit": "", "label": "", "start": .2,
                                "style": "classic", "animation": "pop", "auto": False},
                }
                project.setdefault("scenes", []).append(scene)
                project["scenes_synced"] = False
        else:
            duration = _duration(path)
            old = project.get(kind)
            project[kind] = {"source": filename, "name": Path(name).name, "duration": round(duration, 3)}
            if kind == "voice":
                project["transcript"] = {"status": "idle", "text": "", "words": [], "language": "", "model": "small", "error": "", "step": ""}
                project["scenes_synced"] = False
                (path.parent.parent / "render" / "subtitles.srt").unlink(missing_ok=True)
            if old and FILE_ID.fullmatch(str(old.get("source") or "")):
                # Replaced files are kept in the media folder until the project is removed. This makes undo/recovery possible.
                pass
        project["render"] = {"status": "idle", "progress": 0, "quality": "", "error": ""}
        out = _public(_write(project))
        if kind == "scene":
            out["media_replaced"] = replaced
        return out
    except Exception:
        path.unlink(missing_ok=True)
        raise


@router.post("/{project_id}/match-media")
def match_media(project_id: str):
    project = _read(project_id)
    scenes = project.get("scenes", [])
    replaced = 0
    for video in [scene for scene in scenes if scene.get("kind") == "video"]:
        image = _matching_scene([scene for scene in scenes if scene is not video], str(video.get("name") or ""), "image")
        if not image:
            continue
        image["alternate_source"] = _source_snapshot(image)
        _activate_source(image, _source_snapshot(video))
        scenes.remove(video)
        replaced += 1
    if not replaced:
        raise UserError("Совпадений не найдено. Добавьте одинаковый номер сцены в имена фото и видео, например 012.jpg и 012.mp4.")
    project["scenes_synced"] = False
    project["render"] = {"status": "idle", "progress": 0, "quality": "", "error": ""}
    out = _public(_write(project))
    out["media_replaced"] = replaced
    return out


@router.post("/{project_id}/scene/{scene_id}/swap-source")
def swap_scene_source(project_id: str, scene_id: str):
    project = _read(project_id)
    scene = next((item for item in project.get("scenes", []) if item.get("id") == scene_id), None)
    if not scene or not isinstance(scene.get("alternate_source"), dict):
        raise UserError("Для этой сцены нет второго варианта.")
    current = _source_snapshot(scene)
    _activate_source(scene, scene["alternate_source"])
    scene["alternate_source"] = current
    project["render"] = {"status": "idle", "progress": 0, "quality": "", "error": ""}
    return _public(_write(project))


@router.delete("/{project_id}/audio/{kind}")
def remove_audio(project_id: str, kind: str):
    if kind not in ("voice", "music", "ambience"):
        raise HTTPException(404)
    project = _read(project_id)
    project[kind] = None
    if kind == "voice":
        project["transcript"] = {"status": "idle", "text": "", "words": [], "language": "", "model": "small", "error": "", "step": ""}
        project["scenes_synced"] = False
        (_project_dir(project_id) / "render" / "subtitles.srt").unlink(missing_ok=True)
    project["render"] = {"status": "idle", "progress": 0, "quality": "", "error": ""}
    return _public(_write(project))


@router.get("/{project_id}/media/{filename}")
def source_file(project_id: str, filename: str):
    if not FILE_ID.fullmatch(filename or ""):
        raise HTTPException(404)
    path = _project_dir(project_id) / "media" / filename
    if not path.is_file():
        raise HTTPException(404)
    return FileResponse(path, headers={"Cache-Control": "private, max-age=3600"})


@router.get("/{project_id}/output/{quality}")
def output_file(project_id: str, quality: str, download: bool = False):
    if quality == "subtitles":
        path = _project_dir(project_id) / "render" / "subtitles.srt"
        if not path.is_file():
            raise HTTPException(404)
        return FileResponse(path, filename=f"{_read(project_id)['title']}.srt", media_type="application/x-subrip")
    if quality not in ("preview", "final"):
        raise HTTPException(404)
    path = _project_dir(project_id) / "render" / f"{quality}.mp4"
    if not path.is_file():
        raise HTTPException(404)
    headers = {"Cache-Control": "no-store"}
    return FileResponse(path, filename=f"{_read(project_id)['title']}.mp4" if download else None, headers=headers)


@router.post("/{project_id}/reveal/{quality}")
def reveal_output(project_id: str, quality: str):
    if quality not in ("preview", "final"):
        raise HTTPException(404)
    path = _project_dir(project_id) / "render" / f"{quality}.mp4"
    if not path.is_file():
        raise UserError("Сначала соберите ролик.")
    try:
        if sys.platform == "darwin":
            subprocess.Popen(["open", "-R", str(path)])
        elif sys.platform.startswith("win"):
            subprocess.Popen(["explorer", "/select,", str(path)])
        else:
            subprocess.Popen(["xdg-open", str(path.parent)])
    except OSError:
        raise UserError(f"Не получилось открыть папку. Файл находится здесь: {path}")
    return {"ok": True, "path": str(path)}


@router.get("/{project_id}/waveform/{kind}")
def waveform(project_id: str, kind: str, points: int = 700):
    if kind not in ("voice", "music"):
        raise HTTPException(404)
    project = _read(project_id)
    item = project.get(kind)
    if not item:
        return {"peaks": [], "duration": 0}
    path = _project_dir(project_id) / "media" / item["source"]
    p = subprocess.run([media.ffmpeg(), "-hide_banner", "-loglevel", "error", "-i", str(path), "-vn", "-t", "7200",
                        "-ac", "1", "-ar", "2000", "-f", "s16le", "-"], capture_output=True)
    if p.returncode:
        raise UserError("Не удалось построить волну звука.")
    samples = array.array("h")
    samples.frombytes(p.stdout)
    points = int(_number(points, 700, 100, 1600))
    step = max(len(samples) // points, 1)
    peaks = [round(max((abs(x) for x in samples[i:i + step]), default=0) / 32768, 3)
             for i in range(0, len(samples), step)][:points]
    return {"peaks": peaks, "duration": item.get("duration", 0)}


@router.get("/whisper/info")
def whisper_info():
    out = local_whisper.info()
    out["elevenlabs"] = bool(load_settings().get("elevenlabs_key"))
    return out


def _transcript_cues(project: dict) -> list:
    words = [(str(w[0]), float(w[1]), float(w[2]), 0) for w in project.get("transcript", {}).get("words", [])]
    return captions.group(words, 3, 18) if project.get("format") == "short" else captions.group(words, 8, 42)


def _write_srt(project: dict):
    cues = _transcript_cues(project)
    if cues:
        captions.write_srt(cues, _project_dir(project["id"]) / "render" / "subtitles.srt")


def _set_transcript(project_id: str, **changes):
    with _lock:
        try:
            project = _read(project_id)
        except Exception:
            return
        project.setdefault("transcript", {}).update(changes)
        _write(project)


def _transcribe_worker(project_id: str, model: str, language: str, provider: str):
    try:
        project = _read(project_id)
        voice = project.get("voice")
        if not voice:
            raise UserError("Сначала добавьте озвучку.")
        source = _project_dir(project_id) / "media" / voice["source"]
        used_provider = provider
        api_error = None
        settings = load_settings()
        if provider in ("elevenlabs", "auto") and settings.get("elevenlabs_key"):
            try:
                _set_transcript(project_id, step="ElevenLabs Scribe быстро расшифровывает дорожку…")
                text, words, detected = tts.transcribe_detailed(settings, source, language)
                used_provider = "elevenlabs"
            except Exception as exc:
                if provider == "elevenlabs":
                    raise
                api_error = exc
                _set_transcript(project_id, step="ElevenLabs недоступен — продолжаю бесплатно на этом Mac…")
        if provider == "local" or (provider == "auto" and (not settings.get("elevenlabs_key") or api_error)):
            try:
                text, words, detected = local_whisper.transcribe(
                    source, model, language,
                    on_status=lambda step: _set_transcript(project_id, step=step),
                )
                used_provider = "local"
            except Exception as local_error:
                if api_error:
                    raise UserError(f"ElevenLabs не сработал ({api_error}); локальный Whisper тоже не завершился ({local_error}).") from local_error
                raise
        project = _read(project_id)
        project["transcript"] = {
            "status": "done", "text": text, "words": words, "language": detected,
            "model": model, "provider": used_provider, "error": "", "step": "Готово", "finished": _now(),
        }
        if project.get("scenes"):
            cuts = _sync_cuts(project)
            for scene, start, end in zip(project["scenes"], cuts, cuts[1:]):
                scene["duration"] = round(end - start, 3)
            project["scenes_synced"] = True
            if project.get("graphics_auto"):
                _apply_graphic_suggestions(project)
        _write_srt(project)
        _write(project)
    except Exception as exc:
        _set_transcript(project_id, status="error", error=str(exc), step="")
    finally:
        with _lock:
            _transcribing.discard(project_id)


@router.post("/{project_id}/transcribe")
def start_transcription(project_id: str, model: str = "small", language: str = "", provider: str = "local"):
    project = _read(project_id)
    if not project.get("voice"):
        raise UserError("Сначала добавьте озвучку.")
    if model not in local_whisper.MODELS:
        model = "small"
    if provider not in ("local", "elevenlabs", "auto"):
        provider = "local"
    if provider == "elevenlabs" and not load_settings().get("elevenlabs_key"):
        raise UserError("Сначала добавьте ключ ElevenLabs в Настройках.")
    if provider == "local" and not local_whisper.available():
        raise UserError("Локальный Whisper не установлен. Выберите ElevenLabs или обновите библиотеки программы.")
    with _lock:
        if project_id in _transcribing:
            raise UserError("Эта озвучка уже расшифровывается.")
        if project_id in _rendering:
            raise UserError("Сначала дождитесь окончания сборки видео.")
        _transcribing.add(project_id)
    project["transcription_provider"] = provider
    first_step = "Отправляю дорожку в ElevenLabs Scribe…" if provider == "elevenlabs" else (
        "Пробую быстро через ElevenLabs…" if provider == "auto" and load_settings().get("elevenlabs_key") else "Запускаю локальный Whisper…")
    project["transcript"] = {"status": "running", "text": "", "words": [], "language": language,
                             "model": model, "provider": provider, "error": "", "step": first_step, "started": _now()}
    _write(project)
    threading.Thread(target=_transcribe_worker, args=(project_id, model, language, provider), daemon=True,
                     name=f"speech-to-text-{project_id}").start()
    return {"ok": True, "status": "running"}


def _sync_cuts(project: dict) -> list[float]:
    scenes = project.get("scenes", [])
    words = project.get("transcript", {}).get("words", [])
    total = float((project.get("voice") or {}).get("duration") or (words[-1][2] if words else 0))
    if not scenes or not words or total <= 0:
        raise UserError("Для синхронизации нужны сцены и готовая расшифровка Whisper.")
    current = [max(float(s.get("duration") or 0), .1) for s in scenes]
    current_total = sum(current) or len(scenes)
    targets, acc = [], 0.0
    for duration in current[:-1]:
        acc += duration
        targets.append(acc / current_total * total)
    boundaries = []
    for i, word in enumerate(words[:-1]):
        end, next_start = float(word[2]), float(words[i + 1][1])
        text = str(word[0])
        if next_start - end >= .22 or re.search(r"[.!?…]\W*$", text):
            boundaries.append((end + next_start) / 2)
    cuts, last = [0.0], 0.0
    for target in targets:
        available = [x for x in boundaries if x >= last + .25 and x <= total - .25]
        cut = min(available, key=lambda x: abs(x - target)) if available else target
        if abs(cut - target) > 3.0:
            cut = target
        cut = min(max(cut, last + .25), total - .25)
        cuts.append(cut)
        last = cut
    cuts.append(total)
    return cuts


@router.post("/{project_id}/sync-scenes")
def sync_scenes(project_id: str):
    project = _read(project_id)
    cuts = _sync_cuts(project)
    for scene, start, end in zip(project["scenes"], cuts, cuts[1:]):
        scene["duration"] = round(end - start, 3)
    project["scenes_synced"] = True
    project["render"] = {"status": "idle", "progress": 0, "quality": "", "error": ""}
    return _public(_write(project))


def _graphic_suggestions(project: dict) -> list[tuple[int, dict]]:
    """Find facts and visual cues in the local Whisper transcript. No model or network call is used."""
    words = project.get("transcript", {}).get("words", [])
    scenes = project.get("scenes", [])
    if not words or not scenes:
        raise UserError("Сначала расшифруйте озвучку Whisper и добавьте сцены.")
    ends, total = [], 0.0
    for scene in scenes:
        total += float(scene.get("duration") or 0)
        ends.append(total)
    suggestions, used_scenes, last_time = [], set(), -99.0
    limit = 4 if project.get("format") == "short" else min(16, max(5, len(scenes) // 2))
    for wi, raw in enumerate(words):
        token = str(raw[0]).strip()
        match = re.search(r"(?<!\w)([+−-]?[€$₽]?\d+(?:[.,]\d+)?[%€$₽]?)(?!\w)", token)
        if not match:
            continue
        at = float(raw[1])
        if at - last_time < (4 if project.get("format") == "short" else 8):
            continue
        scene_i = next((i for i, end in enumerate(ends) if at < end), len(scenes) - 1)
        if scene_i in used_scenes:
            continue
        shown = match.group(1).replace("−", "-")
        clean = re.sub(r"[^\d.,+-]", "", shown).replace(",", ".")
        try:
            number = float(clean)
        except ValueError:
            continue
        following = []
        for next_word in words[wi + 1:wi + 4]:
            raw_next = str(next_word[0])
            cleaned_next = re.sub(r"^[\W_]+|[\W_]+$", "", raw_next)
            if cleaned_next and not re.search(r"\d", cleaned_next):
                following.append(cleaned_next)
            if re.search(r"[.!?…]", raw_next):
                break
        context = " ".join(following[:2])[:40]
        low = (token + " " + context).lower()
        if "%" in shown or "процент" in low or "percent" in low:
            kind, unit = "percent", "%"
        elif any(x in shown for x in ("₽", "$", "€")) or any(x in low for x in ("рубл", "доллар", "евро")):
            kind = "money"
            unit = next((x for x in ("₽", "$", "€") if x in shown), "₽" if "рубл" in low else "$" if "доллар" in low else "€")
        elif number.is_integer() and 1000 <= number <= 2100:
            kind, unit = "date", ""
        elif any(x in low for x in ("место", "топ", "place", "rank", "top")):
            kind, unit = "rank", ""
        else:
            kind, unit = "counter", ""
        start = sum(float(s.get("duration") or 0) for s in scenes[:scene_i])
        graphic = {"type": kind, "value": clean, "unit": unit, "label": context,
                   "start": round(min(max(at - start - .15, 0), max(float(scenes[scene_i].get("duration") or 0) - .2, 0)), 2),
                   "style": ("glass", "neon", "minimal", "classic")[scene_i % 4],
                   "animation": ("pop", "slide", "pulse", "fade")[scene_i % 4], "auto": True}
        suggestions.append((scene_i, graphic))
        used_scenes.add(scene_i)
        last_time = at
        if len(suggestions) >= limit:
            break
    semantic_last = -99.0
    rules = [
        (r"опас|угроз|предупр|риск|danger|threat|warning|risk|gefahr|bedroh|warnung|risiko|peligr|amenaz|advert|riesgo", "warning"),
        (r"вырос|рост|увелич|поднял|подорож|grow|grew|increase|rise|rose|wuchs|wachs|stieg|steig|creci|aument|subi", "up"),
        (r"упал|паден|сниз|уменьш|сократ|подешев|fall|fell|drop|decrease|decline|fiel|sank|sink|cay|cae|baj|dismin", "down"),
        (r"люд|человек|жител|населен|аудитор|people|person|population|resident|menschen|bevölker|einwohner|gente|personas|poblaci|habitant", "people"),
        (r"город|страна|остров|место|регион|континент|city|country|island|place|region|continent|river|ocean|stadt|land|insel|fluss|ciudad|país|pais|isla|río|rio", "location"),
        (r"иде|открыт|изобрел|придум|idea|discover|invent|entdeck|erfand|erfind|descubr|invent", "idea"),
        (r"побед|достижен|чемпион|награ|winner|champion|award|achievement|sieg|gewann|meister|victori|gan[oó]|campe", "trophy"),
        (r"архив|документ|доклад|письмо|записк|archive|document|report|letter|record|dokument|bericht|brief|archivo|documento|informe|carta", "document"),
        (r"секрет|засекреч|тайн|secret|classified|mystery|geheim|rätsel|secreto|misterio", "secret"),
        (r"новост|сообщил|данным|news|reported|according|nachricht|berichtet|noticia|inform[oó]", "news"),
        (r"спустя|позже|затем|later|afterward|meanwhile|then|später|danach|después|luego", "timeline"),
        (r"главн|важн|впервые|никогда|important|first|never|key|wichtig|erstmals|niemals|importante|nunca|primera", "keyword"),
    ]
    for wi, raw in enumerate(words):
        at = float(raw[1])
        if at - semantic_last < (5 if project.get("format") == "short" else 9):
            continue
        token = re.sub(r"^[\W_]+|[\W_]+$", "", str(raw[0])).lower().replace("ё", "е")
        phrase_start, phrase_count, unit = wi, 3, ""
        if token in ("звали", "имени", "называли", "named", "called", "name", "hieß", "namens", "llamaba", "llamado") and wi + 1 < len(words):
            kind, phrase_start, phrase_count, unit = "name", wi + 1, 2, graphics.word("hero", project.get("language") or project.get("transcript", {}).get("language") or "ru")
        elif re.search(r"сказал|сказала|говорил|заявил|ответил|said|says|stated|replied|sagte|erklärte|dijo|declaró", token) and wi + 1 < len(words):
            kind, phrase_start, phrase_count = "quote", wi + 1, 5
        elif re.search(r"глава|часть|далее|тем временем|chapter|part|next|meanwhile|kapitel|capítulo", token):
            kind, phrase_start, phrase_count, unit = "chapter", wi + 1, 3, token
        else:
            kind = next((kind for pattern, kind in rules if re.search(pattern, token)), "")
        if not kind:
            continue
        if kind == "location":
            phrase_start, phrase_count, unit = wi + 1, 2, token
        scene_i = next((i for i, end in enumerate(ends) if at < end), len(scenes) - 1)
        if scene_i in used_scenes:
            continue
        phrase = []
        for item in words[phrase_start:phrase_start + phrase_count]:
            cleaned = re.sub(r"^[\W_]+|[\W_]+$", "", str(item[0]))
            if cleaned:
                phrase.append(cleaned)
            if re.search(r"[.!?…]", str(item[0])):
                break
        start = sum(float(s.get("duration") or 0) for s in scenes[:scene_i])
        special = kind in ("name", "location", "quote", "chapter", "document", "secret", "news", "timeline")
        graphic = {"type": kind, "value": "", "unit": unit, "label": " ".join(phrase)[:40],
                   "start": round(min(max(at - start - .1, 0), max(float(scenes[scene_i].get("duration") or 0) - .2, 0)), 2),
                   "style": ("cinematic", "broadcast")[scene_i % 2] if special else ("glass", "neon", "minimal", "classic")[scene_i % 4],
                   "animation": {"name": "slide", "location": "fade", "quote": "fade", "chapter": "pop", "document": "slide", "secret": "pop", "news": "slide", "timeline": "fade"}.get(kind, ("pop", "slide", "pulse", "fade")[scene_i % 4]), "auto": True}
        suggestions.append((scene_i, graphic))
        used_scenes.add(scene_i)
        semantic_last = at
        if len(suggestions) >= limit:
            break
    return suggestions


def _apply_graphic_suggestions(project: dict) -> int:
    added = 0
    for scene_i, graphic in _graphic_suggestions(project):
        scene = project["scenes"][scene_i]
        current = scene.get("graphic") or {}
        if current.get("type") not in (None, "", "none") and not current.get("auto"):
            continue
        scene["graphic"] = graphic
        added += 1
    return added


@router.post("/{project_id}/suggest-graphics")
def suggest_graphics(project_id: str):
    project = _read(project_id)
    added = _apply_graphic_suggestions(project)
    if not added:
        raise UserError("Подходящих фактов или визуальных акцентов не найдено. Моушен можно настроить вручную.")
    project["graphics_enabled"] = True
    project["render"] = {"status": "idle", "progress": 0, "quality": "", "error": ""}
    out = _public(_write(project))
    out["graphics_added"] = added
    return out


def _editing_history() -> list[dict]:
    path = ROOT / ".editing-history.json"
    try:
        value = json.loads(path.read_text("utf-8"))
        return value if isinstance(value, list) else []
    except (OSError, ValueError):
        return []


def _remember_editing_style(project: dict):
    plan = project.get("plan") or {}
    style = str(plan.get("style") or "")
    if style not in editing_styles.STYLE_IDS:
        return
    history = [item for item in _editing_history() if item.get("project_id") != project.get("id")]
    history.insert(0, {"project_id": project.get("id"), "style": style, "at": _now()})
    ROOT.mkdir(parents=True, exist_ok=True)
    (ROOT / ".editing-history.json").write_text(
        json.dumps(history[:30], ensure_ascii=False, indent=2), "utf-8")


@router.post("/{project_id}/director-plan")
def create_director_plan(project_id: str):
    project = _read(project_id)
    recent = []
    if project.get("avoid_repeats", True):
        recent = [str(item.get("style") or "") for item in _editing_history()
                  if item.get("project_id") != project_id]
    plan = editing_styles.build_plan(project, recent)
    graphics_added = 0
    if project.get("graphics_auto") and project.get("transcript", {}).get("status") == "done" and project.get("scenes"):
        try:
            graphics_added = _apply_graphic_suggestions(project)
        except UserError:
            pass
    project["render"] = {"status": "idle", "progress": 0, "quality": "", "error": ""}
    out = _public(_write(project))
    out["director_plan"] = plan
    out["quality_report"] = editing_styles.quality_report(project)
    out["graphics_added"] = graphics_added
    return out


@router.get("/{project_id}/quality-report")
def quality_report(project_id: str):
    return {"items": editing_styles.quality_report(_read(project_id))}


def _set_render(project_id: str, **changes):
    with _lock:
        try:
            project = _read(project_id)
        except Exception:
            return
        project.setdefault("render", {}).update(changes)
        _write(project)


def _fit_filter(width: int, height: int, fit: str) -> str:
    if fit == "contain":
        return (f"scale={width}:{height}:force_original_aspect_ratio=decrease,"
                f"pad={width}:{height}:(ow-iw)/2:(oh-ih)/2:color=black")
    return f"scale={width}:{height}:force_original_aspect_ratio=increase,crop={width}:{height}"


def _look_filter(look: str) -> str:
    return editing_styles.COLOR_FILTERS.get(look, editing_styles.COLOR_FILTERS["natural"])


def _transition_filter(kind: str, duration: float) -> str:
    """Per-clip texture only; actual transitions are composed between neighbouring clips at join time."""
    if kind == "film":
        return ",noise=alls=5:allf=t+u"
    return ""


def _join_scene_clips(clips: list[Path], scenes: list[dict], out: Path, fast: bool, fps: int):
    """Real transitions with no time loss: the outgoing frame is padded over the overlap."""
    if len(clips) < 2 or not any(str(scene.get("transition") or "cut") != "cut" for scene in scenes[1:]):
        media.concat_clips(clips, out)
        return
    xfade = {"fade": "fadeblack", "dissolve": "dissolve", "flash": "fadewhite",
             "light_leak": "smoothleft", "film": "pixelize"}
    args = []
    for clip in clips:
        args += ["-i", clip]
    rendered_duration = lambda scene: max(round(float(scene.get("duration") or 0) * fps), 1) / fps
    # Clips made from photos and stock video can have different stream time bases even at the same FPS.
    # xfade requires identical time bases and otherwise can fail near the end of a long finished render.
    filters = [f"[{index}:v]settb=AVTB,fps={fps},setsar=1[n{index}]" for index in range(len(clips))]
    current = "n0"
    cumulative = rendered_duration(scenes[0])
    for index in range(1, len(clips)):
        kind = str(scenes[index].get("transition") or "cut")
        output = f"v{index}"
        if kind == "cut":
            filters.append(f"[{current}][n{index}]concat=n=2:v=1:a=0[{output}]")
        else:
            duration = min(.28, max(rendered_duration(scenes[index - 1]) / 3, .08),
                           max(rendered_duration(scenes[index]) / 3, .08))
            padded = f"p{index}"
            filters.append(f"[{current}]tpad=stop_mode=clone:stop_duration={duration:.3f}[{padded}]")
            filters.append(f"[{padded}][n{index}]xfade=transition={xfade.get(kind, 'fade')}:"
                           f"duration={duration:.3f}:offset={cumulative:.3f}[{output}]")
        current = output
        cumulative += rendered_duration(scenes[index])
    media.run([*args, "-filter_complex", ";".join(filters), "-map", f"[{current}]", "-an",
               "-c:v", "libx264", "-preset", "superfast" if fast else "veryfast",
               "-crf", 20 if fast else 21, "-threads", 3 if fast else 0,
               "-pix_fmt", "yuv420p", "-movflags", "+faststart", out], "Переходы локального монтажа")


def _image_filter(scene: dict, width: int, height: int, fps: int, frames: int, look: str,
                  fast: bool = False) -> str:
    fit = scene.get("fit", "cover")
    motion = editing_styles.smooth_motion(scene.get("motion", "none"))
    if motion == "none" or fit == "contain":
        vf = f"{_fit_filter(width, height, fit)},fps={fps}"
    else:
        # 1.4x still leaves enough real pixels for the strongest 1.32x zoom, but
        # avoids processing a needless 4K canvas for every 1080p photograph.
        scale = 1.4 if fast else 2.0
        big_w, big_h = int(width * scale) // 2 * 2, int(height * scale) // 2 * 2
        p = f"on/{max(frames, 1)}"
        focus_x = _number(scene.get("focus_x"), .5, .05, .95)
        focus_y = _number(scene.get("focus_y"), .5, .05, .95)
        focus_x_expr = f"max(min(iw*{focus_x:.3f}-iw/zoom/2,iw-iw/zoom),0)"
        focus_y_expr = f"max(min(ih*{focus_y:.3f}-ih/zoom/2,ih-ih/zoom),0)"
        y = focus_y_expr
        if motion == "zoom_out":
            z, x = f"1.16-0.16*{p}", focus_x_expr
        elif motion == "pan_left":
            z, x = "1.16", f"(iw-iw/zoom)*(1-{p})"
        elif motion == "pan_right":
            z, x = "1.16", f"(iw-iw/zoom)*{p}"
        elif motion == "pan_up":
            z, x, y = "1.16", "(iw-iw/zoom)/2", f"(ih-ih/zoom)*(1-{p})"
        elif motion == "pan_down":
            z, x, y = "1.16", "(iw-iw/zoom)/2", f"(ih-ih/zoom)*{p}"
        elif motion == "diagonal_in":
            z, x, y = f"1+0.18*{p}", f"(iw-iw/zoom)*{p}", f"(ih-ih/zoom)*(1-{p})"
        elif motion == "punch_in":
            z, x = f"min(1+0.32*on/{max(round(frames * .35), 1)},1.32)", focus_x_expr
        else:
            z, x = f"1+0.16*{p}", focus_x_expr
        vf = (f"scale={big_w}:{big_h}:force_original_aspect_ratio=increase,crop={big_w}:{big_h},"
              f"zoompan=z='{z}':x='{x}':y='{y}':d={frames}:s={width}x{height}:fps={fps}")
    duration = frames / fps
    if look != "baked":  # «baked»: the colour look is already in the picture itself
        vf += "," + _look_filter(look)
    vf += _transition_filter(str(scene.get("transition") or "cut"), duration)
    return vf + ",setsar=1,format=yuv420p"


def _video_filter(scene: dict, width: int, height: int, fps: int, look: str) -> str:
    duration = float(scene["duration"])
    source_window = max(float(scene.get("trim_end") or duration) - float(scene.get("trim_start") or 0), .1)
    # If the voice needs this scene for longer than the source clip, hold the last frame.
    vf = (f"trim=duration={source_window:.3f},setpts=PTS-STARTPTS,{_fit_filter(width, height, scene.get('fit', 'cover'))},"
          f"fps={fps},tpad=stop_mode=clone:stop_duration={duration:.3f}")
    vf += "," + _look_filter(look)
    vf += _transition_filter(str(scene.get("transition") or "cut"), duration)
    return vf + ",setsar=1,format=yuv420p"


def _clip_cache_key(project_dir: Path, scene: dict, width: int, height: int, fps: int,
                    graphics_enabled: bool, color_look: str, fast: bool, lang: str = "ru") -> str:
    source = project_dir / "media" / str(scene.get("source") or "")
    try:
        stat = source.stat()
        source_state = [stat.st_size, stat.st_mtime_ns]
    except OSError:
        source_state = [0, 0]
    visual = {key: scene.get(key) for key in (
        "source", "kind", "duration", "fit", "motion", "transition", "trim_start", "trim_end", "focus_x", "focus_y")}
    if graphics_enabled:
        visual["graphic"] = scene.get("graphic")
        visual["lang"] = lang
    visual["motion"] = editing_styles.smooth_motion(str(visual.get("motion") or "none"))
    # 4: clips cached with the old shaking zooms are rendered again as smooth pans.
    payload = [4, visual, source_state, width, height, fps, graphics_enabled, color_look, fast]
    raw = json.dumps(payload, sort_keys=True, ensure_ascii=False, default=str).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()[:24]


def _render_clip(project_dir: Path, scene: dict, out: Path, width: int, height: int, fps: int,
                 graphics_enabled: bool = False, color_look: str = "natural", fast: bool = False, lang: str = "ru"):
    source = project_dir / "media" / scene["source"]
    duration = float(scene["duration"])
    frames = max(round(duration * fps), 1)
    graphic = deepcopy(scene.get("graphic") or {})
    active_graphic = graphics_enabled and graphic.get("type") in LOCAL_GRAPHICS - {"none"}
    base = out.with_name(f".{out.stem}.base.mp4") if active_graphic else out
    if scene["kind"] == "image":
        image_look = color_look
        if True:
            # A still picture needs its colour look once, not on every one of ~200 frames: bake it into the image.
            # Profiling on an M1: «cinematic» took a 7-second clip from ~2.5 s to ~10 s when applied per frame.
            try:
                stat = source.stat()
                key = hashlib.sha256(f"{source}|{stat.st_size}|{stat.st_mtime_ns}|{_look_filter(color_look)}".encode()).hexdigest()[:16]
                baked = project_dir / "render" / ".looked" / f"{key}.png"
                if not baked.is_file():
                    baked.parent.mkdir(parents=True, exist_ok=True)
                    tmp = baked.with_name(f".{key}.{os.getpid()}.{threading.get_ident()}.png")
                    media.run(["-i", source, "-vf", _look_filter(color_look) + ",format=rgb24", "-frames:v", 1, tmp],
                              "Цвет кадра")
                    tmp.replace(baked)
                source, image_look = baked, "baked"
            except (OSError, UserError):
                image_look = color_look  # fall back to the per-frame look
        args = ["-loop", "1", "-framerate", fps, "-i", source, "-vf", _image_filter(scene, width, height, fps, frames, image_look, fast),
                "-frames:v", frames]
    else:
        args = ["-ss", f"{float(scene.get('trim_start') or 0):.3f}", "-i", source, "-t", f"{duration:.3f}",
                "-vf", _video_filter(scene, width, height, fps, color_look)]
    encode_args = ["-c:v", "libx264", "-preset", "superfast" if fast else "veryfast",
                   "-crf", 21 if fast else 22, "-threads", 2 if fast else 0]
    media.run([*args, "-an", "-r", fps, *encode_args,
               "-pix_fmt", "yuv420p", base], "Фрагмент локального монтажа")
    if active_graphic:
        work = out.parent / f".{out.stem}-graphics"
        if graphic["type"] == "date":
            caption = graphic.get("label", "")
            graphic["label"] = graphic.get("value", "")
            graphic["unit"] = caption
        graphic["start"] = min(max(float(graphic.get("start") or 0), 0), max(duration - .1, 0))
        try:
            overlay_args = ["-c:v", "libx264", "-preset", "superfast", "-crf", 18, "-threads", 2] if fast else None
            graphics.overlay(base, out, [{**graphic, "lang": lang}], width, height, work, fps=fps, encode_args=overlay_args)
        finally:
            base.unlink(missing_ok=True)
            shutil.rmtree(work, ignore_errors=True)


def _mix(project_dir: Path, project: dict, video: Path, out: Path, total: float, sfx_path: Path | None = None,
         subtitles: tuple | None = None):
    """subtitles: (ass, fonts) - burned in this same pass on the Mac's video chip; no separate subtitle pass."""
    args: list = ["-i", video]
    filters = []
    audio_labels = []
    idx = 1
    voice = project.get("voice")
    music = project.get("music")
    ambience = project.get("ambience")
    if voice:
        args += ["-i", project_dir / "media" / voice["source"]]
        cleanup = ",highpass=f=75,lowpass=f=15500,acompressor=threshold=0.10:ratio=3:attack=8:release=160:makeup=1.6" if project.get("voice_cleanup", True) else ""
        tone = {
            "warm": ",equalizer=f=180:width_type=o:width=1.4:g=2",
            "deep": ",equalizer=f=120:width_type=o:width=1.2:g=3,equalizer=f=2800:width_type=o:width=1.4:g=-1",
            "bright": ",equalizer=f=3600:width_type=o:width=1.3:g=2",
            "radio": ",highpass=f=180,lowpass=f=6500,equalizer=f=1800:width_type=o:width=1.5:g=2",
        }.get(str(project.get("resolved_voice_tone") or project.get("voice_tone") or "natural"), "")
        split = ",asplit=2[voice][voice_side]" if music and project.get("auto_duck", True) else "[voice]"
        filters.append(f"[{idx}:a]aformat=sample_rates=44100:channel_layouts=stereo{cleanup}{tone},apad,atrim=0:{total:.3f}{split}")
        audio_labels.append("[voice]")
        idx += 1
    if music:
        args += ["-stream_loop", "-1", "-i", project_dir / "media" / music["source"]]
        volume = float(project.get("music_volume", .12))
        filters.append(f"[{idx}:a]aformat=sample_rates=44100:channel_layouts=stereo,volume={volume:.3f},atrim=0:{total:.3f}[music_base]")
        if voice and project.get("auto_duck", True):
            filters.append("[music_base][voice_side]sidechaincompress=threshold=0.025:ratio=10:attack=20:release=350[music]")
        else:
            filters.append("[music_base]anull[music]")
        audio_labels.append("[music]")
        idx += 1
    if ambience:
        args += ["-stream_loop", "-1", "-i", project_dir / "media" / ambience["source"]]
        volume = float(project.get("ambience_volume", .06))
        filters.append(f"[{idx}:a]aformat=sample_rates=44100:channel_layouts=stereo,volume={volume:.3f},atrim=0:{total:.3f}[ambience]")
        audio_labels.append("[ambience]")
        idx += 1
    if sfx_path and sfx_path.is_file():
        args += ["-i", sfx_path]
        filters.append(f"[{idx}:a]aformat=sample_rates=44100:channel_layouts=stereo,apad,atrim=0:{total:.3f}[sfx]")
        audio_labels.append("[sfx]")
        idx += 1
    if not audio_labels:
        args += ["-f", "lavfi", "-t", f"{total:.3f}", "-i", "anullsrc=r=44100:cl=stereo"]
        audio_map = f"{idx}:a"
    elif len(audio_labels) == 1:
        audio_map = audio_labels[0]
    else:
        filters.append("".join(audio_labels) + f"amix=inputs={len(audio_labels)}:duration=longest:normalize=0[a]")
        audio_map = "[a]"
    if audio_labels and project.get("audio_master", True):
        filters.append(f"{audio_map}loudnorm=I=-14:LRA=11:TP=-1.5,alimiter=limit=0.95,aresample=44100[master]")
        audio_map = "[master]"
    if not subtitles:
        filter_args = ["-filter_complex", ";".join(filters)] if filters else []
        media.run([*args, *filter_args, "-map", "0:v", "-map", audio_map, "-c:v", "copy", "-c:a", "aac", "-b:a", "192k",
                   "-t", f"{total:.3f}", "-movflags", "+faststart", out], "Звук локального монтажа")
        return
    ass, fonts = subtitles
    fonts_arg = str(Path(fonts).resolve()).replace("\\", "/").replace(":", "\\:")
    filters.insert(0, f"[0:v]subtitles=filename={ass.name}:fontsdir={fonts_arg},format=yuv420p[v]")
    args = [str(Path(a).resolve()) if isinstance(a, Path) else a for a in args]
    last = None
    for encoder in (["-c:v", "h264_videotoolbox", "-b:v", "10M", "-maxrate", "14M", "-bufsize", "20M", "-profile:v", "high", "-allow_sw", 1],
                    ["-c:v", "libx264", "-preset", "veryfast", "-crf", 20]):
        try:
            media.run([*args, "-filter_complex", ";".join(filters), "-map", "[v]", "-map", audio_map, *encoder,
                       "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k", "-t", f"{total:.3f}", "-movflags", "+faststart",
                       Path(out).resolve()], "Звук и субтитры локального монтажа", cwd=ass.parent, exe=media.ffmpeg_with_subtitles())
            return
        except UserError as exc:
            last = exc
            Path(out).unlink(missing_ok=True)
    raise last


def _subtitle_files(project: dict, width: int, height: int) -> tuple | None:
    """(subtitles.ass, fonts folder) for the owner's subtitle settings, or None when there is nothing to show."""
    cues = _transcript_cues(project)
    if not cues:
        return None
    render_dir = _project_dir(project["id"]) / "render"
    ass = render_dir / "subtitles.ass"
    captions.write_srt(cues, render_dir / "subtitles.srt")
    words = [(str(w[0]), float(w[1]), float(w[2])) for w in project.get("transcript", {}).get("words", [])]
    fonts = captions.styled_ass(words, ass, width, height, str(project.get("subtitle_preset") or "documentary"),
                                str(project.get("subtitle_font") or "auto"), str(project.get("subtitle_size") or "medium"),
                                str(project.get("subtitles_position") or "mid_low"), cues=cues)
    return ass, fonts


def _render_worker(project_id: str, quality: str, cancel_check=None):
    work = None

    def check_cancel():
        if cancel_check and cancel_check():
            raise RenderCancelled("Сборка остановлена владельцем.")

    try:
        check_cancel()
        project = _read(project_id)
        project_dir = _project_dir(project_id)
        scenes = project.get("scenes", [])
        if not scenes:
            raise UserError("Добавьте хотя бы одну картинку или видео.")
        if quality == "preview":
            width, height = ((540, 960) if project.get("format") == "short" else (960, 540))
        else:
            width, height = ((1080, 1920) if project.get("format") == "short" else (1920, 1080))
        fps = int(project.get("fps") or 30)
        fast = project.get("render_speed", "fast") == "fast"
        work = project_dir / "render" / f".{quality}-work"
        if work.exists():
            shutil.rmtree(work)
        work.mkdir(parents=True)
        clips = [work / f"{i:04d}.mp4" for i in range(len(scenes))]
        cache_dir = project_dir / "render" / ".clip-cache" / quality
        cache_dir.mkdir(parents=True, exist_ok=True)
        color_look = str(project.get("resolved_color_look") or project.get("color_look") or "natural")
        if color_look == "auto" or color_look not in editing_styles.COLOR_LOOKS:
            color_look = "natural"
        graphics_enabled = bool(project.get("graphics_enabled"))
        lang = project.get("language") or (project.get("transcript") or {}).get("language") or "ru"
        cache_keys = [_clip_cache_key(project_dir, scene, width, height, fps, graphics_enabled, color_look, fast, lang)
                      for scene in scenes]
        def render_one(index: int):
            check_cancel()
            cached = cache_dir / f"{cache_keys[index]}.mp4"
            if cached.is_file() and cached.stat().st_size > 1000:
                try:
                    os.link(cached, clips[index])
                except OSError:
                    shutil.copy2(cached, clips[index])
                return index, True
            _render_clip(project_dir, scenes[index], clips[index], width, height, fps,
                         graphics_enabled, color_look, fast, lang)
            check_cancel()
            cache_tmp = cache_dir / f".{cache_keys[index]}-{index}.tmp.mp4"
            cache_tmp.unlink(missing_ok=True)
            try:
                os.link(clips[index], cache_tmp)
            except OSError:
                shutil.copy2(clips[index], cache_tmp)
            cache_tmp.replace(cached)
            return index, False

        if fast and len(scenes) > 2:
            # zoompan and most colour filters are mostly single-threaded. A few
            # small FFmpeg jobs therefore use Apple Silicon much better than one
            # process that renders 150+ scenes serially.
            requested_workers = max(1, min(int(project.get("render_parallel") or 3), 4))
            workers = min(requested_workers, max(2, (os.cpu_count() or 6) // 3))
            completed = cached_count = 0
            with ThreadPoolExecutor(max_workers=workers, thread_name_prefix="local-scene") as pool:
                futures = [pool.submit(render_one, i) for i in range(len(scenes))]
                try:
                    for future in as_completed(futures):
                        _index, was_cached = future.result()
                        check_cancel()
                        cached_count += int(was_cached)
                        completed += 1
                        _set_render(project_id, progress=round(completed / (len(scenes) + 1) * .9, 3),
                                    cached=cached_count, workers=workers, step="Обрабатываю сцены…")
                except Exception:
                    for future in futures:
                        future.cancel()
                    raise
        else:
            cached_count = 0
            for i in range(len(scenes)):
                check_cancel()
                _index, was_cached = render_one(i)
                cached_count += int(was_cached)
                _set_render(project_id, progress=round((i + 1) / (len(scenes) + 1) * .9, 3),
                            cached=cached_count, workers=1, step="Обрабатываю сцены…")
        check_cancel()
        _set_render(project_id, progress=.91, step="Склеиваю готовые сцены…")
        joined = work / "joined.mp4"
        try:
            _join_scene_clips(clips, scenes, joined, fast, fps)
        except UserError as transition_error:
            # One odd stock clip must not throw away a completed 100+ scene render. Plain cuts preserve every
            # frame, use the already encoded cache and are much faster than restarting scene processing.
            if not any(str(scene.get("transition") or "cut") != "cut" for scene in scenes[1:]):
                raise
            joined.unlink(missing_ok=True)
            _set_render(project_id, progress=.92, step="Один переход несовместим — быстро склеиваю обычными склейками…",
                        warning=str(transition_error))
            media.concat_clips(clips, joined)
        total = sum(float(s["duration"]) for s in scenes)
        target = project_dir / "render" / f"{quality}.mp4"
        tmp = project_dir / "render" / f".{quality}.tmp.mp4"
        sfx_path = work / "automatic-sfx.wav"
        has_sfx = False
        if project.get("auto_sfx", True):
            fx_plan = effects.plan(scenes, "light", project.get("format") == "short")
            has_sfx = effects.build_track(fx_plan, [float(s["duration"]) for s in scenes],
                                          sfx_path, float(project.get("sfx_volume", .18)))
        check_cancel()
        _set_render(project_id, progress=.94, step="Смешиваю голос, музыку и звуковые эффекты…")
        subtitles = None
        if project.get("subtitles") and project.get("transcript", {}).get("words"):
            # Subtitles go in together with the sound: one pass on the video chip, not another hour of CPU encoding.
            subtitles = _subtitle_files(project, width, height)
            if subtitles:
                _set_render(project_id, progress=.94, step="Смешиваю звук и накладываю субтитры…")
        _mix(project_dir, project, joined, tmp, total, sfx_path if has_sfx else None, subtitles)
        joined.unlink(missing_ok=True)  # an hour of video is gigabytes: never keep two copies longer than needed
        check_cancel()
        tmp.replace(target)
        _set_render(project_id, status="done", progress=1, quality=quality, error="", finished=_now())
        active_cache = {f"{key}.mp4" for key in cache_keys}
        for old_cache in cache_dir.glob("*.mp4"):
            if old_cache.name not in active_cache:
                old_cache.unlink(missing_ok=True)
        if quality == "final":
            _remember_editing_style(_read(project_id))
    except RenderCancelled as exc:
        _set_render(project_id, status="cancelled", error=str(exc), quality=quality)
    except Exception as exc:  # the error must be visible on the editor page, not lost in the background thread
        _set_render(project_id, status="error", error=str(exc), progress=0, quality=quality)
    finally:
        if work:
            shutil.rmtree(work, ignore_errors=True)
        with _lock:
            _rendering.discard(project_id)


@router.post("/{project_id}/render")
def start_render(project_id: str, quality: str = "preview"):
    project = _read(project_id)
    if quality not in ("preview", "final"):
        raise UserError("Неизвестное качество сборки.")
    if not project.get("scenes"):
        raise UserError("Добавьте хотя бы одну картинку или видео.")
    with _lock:
        if project_id in _rendering:
            raise UserError("Этот проект уже собирается.")
        if project_id in _transcribing:
            raise UserError("Сначала дождитесь окончания расшифровки Whisper.")
        _rendering.add(project_id)
    _set_render(project_id, status="running", progress=0, quality=quality, error="", cached=0, workers=0,
                step="Подготавливаю сцены…", started=_now())
    threading.Thread(target=_render_worker, args=(project_id, quality), daemon=True, name=f"local-render-{project_id}").start()
    return {"ok": True, "status": "running", "quality": quality}
