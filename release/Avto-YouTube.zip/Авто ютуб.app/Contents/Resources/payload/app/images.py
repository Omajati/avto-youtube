"""Image generation providers. Each takes a prompt and an orientation and returns image bytes."""
import base64
import time
import uuid

from . import net
from .net import UserError

# Shown in Settings. price = approximate USD per image.
PROVIDERS = {
    "fal": {
        "name": "fal.ai (Flux)",
        "key_field": "fal_key",
        "model_field": "fal_model",
        "signup": "https://fal.ai/dashboard/keys",
        "models": [
            ("fal-ai/flux/schnell", "Flux Schnell — очень дёшево, попроще", 0.003),
            ("fal-ai/flux/dev", "Flux Dev — хорошее качество (рекомендую)", 0.025),
            ("fal-ai/flux-pro/v1.1", "Flux 1.1 Pro — лучшее качество", 0.04),
        ],
    },
    "replicate": {
        "name": "Replicate (Flux)",
        "key_field": "replicate_key",
        "model_field": "replicate_model",
        "signup": "https://replicate.com/account/api-tokens",
        "models": [
            ("black-forest-labs/flux-schnell", "Flux Schnell — очень дёшево", 0.003),
            ("black-forest-labs/flux-dev", "Flux Dev — хорошее качество", 0.025),
            ("black-forest-labs/flux-1.1-pro", "Flux 1.1 Pro — лучшее качество", 0.04),
        ],
    },
    "runware": {
        "name": "Runware (Flux, самый дешёвый)",
        "key_field": "runware_key",
        "model_field": "runware_model",
        "signup": "https://my.runware.ai/keys",
        "models": [
            ("runware:100@1", "Flux Schnell — меньше цента за картинку", 0.0013),
            ("runware:101@1", "Flux Dev — хорошее качество, дёшево", 0.004),
        ],
    },
    "together": {
        "name": "Together AI (Flux)",
        "key_field": "together_key",
        "model_field": "together_model",
        "signup": "https://api.together.ai/settings/api-keys",
        "models": [
            ("black-forest-labs/FLUX.1-schnell", "Flux Schnell — дёшево", 0.003),
            ("black-forest-labs/FLUX.1-dev", "Flux Dev — хорошее качество", 0.025),
        ],
    },
    "openai": {
        "name": "OpenAI (как в ChatGPT)",
        "key_field": "openai_key",
        "model_field": "openai_image_model",
        "signup": "https://platform.openai.com/api-keys",
        "models": [
            ("gpt-image-2.5-flare", "GPT Image 2.5 Flare — быстро, ~$0.01–0.02", 0.015),
            ("gpt-image-2.5-sunburst", "GPT Image 2.5 Sunburst — тщательнее, медленнее, ~$0.01–0.02", 0.015),
        ],
    },
    "royal": {
        "name": "RoyalTechno (Nano Banana, Seedream, GPT Image — сторонний перепродавец, дёшево)",
        "key_field": "royal_key",
        "model_field": "royal_image_model",
        "signup": "https://t.me/royaltechno_ai_bot",
        "models": [
            ("nano-banana-2", "Nano Banana 2 — лучше всего держит лица персонажей (рекомендую)", 0.03),
            ("nano-banana-pro", "Nano Banana Pro — самое качественное", 0.06),
            ("seedream-4.6", "Seedream 4.6 — как в Dreamina", 0.03),
            ("gpt-image-2.5", "GPT Image 2.5", 0.03),
        ],
    },
}
# Royal models that draw by reference pictures (characters, items, places), and how many pictures each takes.
ROYAL_REF = {"nano-banana-2": 10, "nano-banana-pro": 10, "seedream-4.6": 6}


def price_per_image(settings) -> float:
    p = PROVIDERS.get(settings.get("image_provider"), PROVIDERS["fal"])
    model = settings.get(p["model_field"])
    for mid, _, price in p["models"]:
        if mid == model:
            return price
    return p["models"][0][2]


def generate(settings, prompt: str, vertical: bool = False) -> bytes:
    provider = settings.get("image_provider") or "fal"
    p = PROVIDERS.get(provider)
    if not p:
        raise UserError(f"Неизвестный сервис картинок: {provider}")
    key = settings.get(p["key_field"])
    if not key:
        raise UserError(f"Не указан ключ для {p['name']}. Вставьте его в Настройках, раздел «Картинки».")
    model = settings.get(p["model_field"]) or p["models"][0][0]
    if provider == "openai":
        return _openai(key, model, prompt, vertical, settings.get("openai_image_quality") or "medium")
    if provider == "royal":
        return _royal(settings, model, prompt, vertical)
    fn = {"fal": _fal, "replicate": _replicate, "runware": _runware, "together": _together, "openai": _openai}[provider]
    return fn(key, model, prompt, vertical)


def _royal(settings, model, prompt, vertical, refs: list = None, square: bool = False):
    from . import royal
    inp = {"prompt": prompt, "aspect_ratio": "1:1" if square else "9:16" if vertical else "16:9"}
    if refs:
        inp["reference_image_urls"] = refs
    out = royal.run(settings, model, inp, poll=4, limit=5 * 60, optional=("aspect_ratio",) if square else ())
    return royal.fetch(out["url"])


def royal_refs(settings) -> bool:
    """Pictures by reference go to RoyalTechno when it is the chosen picture service."""
    return settings.get("image_provider") == "royal" and bool(settings.get("royal_key"))


def can_reference(settings) -> bool:
    """Characters, items and places can be drawn from reference pictures (fal.ai or RoyalTechno)."""
    return bool(settings.get("fal_key")) or royal_refs(settings)


def _download(service, url) -> bytes:
    return net.request(service, "GET", url, timeout=120).content


def _fal(key, model, prompt, vertical):
    body = {
        "prompt": prompt,
        "image_size": "portrait_16_9" if vertical else "landscape_16_9",
        "num_images": 1,
        "enable_safety_checker": True,
        "output_format": "png",
    }
    r = net.request("fal.ai", "POST", f"https://fal.run/{model}",
                    headers={"Authorization": f"Key {key}"}, json=body, timeout=300)
    data = r.json()
    images = data.get("images") or []
    if not images:
        raise UserError(f"fal.ai не вернул картинку: {str(data)[:300]}")
    if (data.get("has_nsfw_concepts") or [False])[0]:
        raise UserError("fal.ai: картинка заблокирована фильтром безопасности")
    url = images[0]["url"]
    if url.startswith("data:"):
        return base64.b64decode(url.split(",", 1)[1])
    return _download("fal.ai", url)


def _replicate(key, model, prompt, vertical):
    headers = {"Authorization": f"Bearer {key}", "Prefer": "wait=60"}
    body = {"input": {"prompt": prompt, "aspect_ratio": "9:16" if vertical else "16:9",
                      "output_format": "png", "num_outputs": 1}}
    if "1.1-pro" in model:
        body["input"].pop("num_outputs")
    r = net.request("Replicate", "POST", f"https://api.replicate.com/v1/models/{model}/predictions",
                    headers=headers, json=body, timeout=300)
    data = r.json()
    deadline = time.time() + 300
    while data.get("status") not in ("succeeded", "failed", "canceled"):
        if time.time() > deadline:
            raise UserError("Replicate слишком долго генерирует картинку")
        time.sleep(2)
        data = net.request("Replicate", "GET", data["urls"]["get"],
                           headers={"Authorization": f"Bearer {key}"}, timeout=60).json()
    if data["status"] != "succeeded":
        raise UserError(f"Replicate: не получилось ({data.get('error')})")
    out = data.get("output")
    url = out[0] if isinstance(out, list) else out
    return _download("Replicate", url)


def _runware(key, model, prompt, vertical):
    w, h = (768, 1344) if vertical else (1344, 768)
    task = [{
        "taskType": "imageInference",
        "taskUUID": str(uuid.uuid4()),
        "positivePrompt": prompt,
        "model": model,
        "width": w, "height": h,
        "numberResults": 1,
        "outputType": "URL",
        "outputFormat": "PNG",
    }]
    r = net.request("Runware", "POST", "https://api.runware.ai/v1",
                    headers={"Authorization": f"Bearer {key}"}, json=task, timeout=300)
    data = r.json()
    if data.get("errors"):
        raise UserError(f"Runware: {str(data['errors'])[:300]}")
    items = data.get("data") or []
    if not items or not items[0].get("imageURL"):
        raise UserError(f"Runware не вернул картинку: {str(data)[:300]}")
    return _download("Runware", items[0]["imageURL"])


def _together(key, model, prompt, vertical):
    w, h = (768, 1344) if vertical else (1344, 768)
    body = {"model": model, "prompt": prompt, "width": w, "height": h, "n": 1,
            "steps": 4 if "schnell" in model.lower() else 28, "response_format": "b64_json"}
    r = net.request("Together AI", "POST", "https://api.together.xyz/v1/images/generations",
                    headers={"Authorization": f"Bearer {key}"}, json=body, timeout=300)
    data = r.json().get("data") or []
    if not data:
        raise UserError("Together AI не вернул картинку")
    if data[0].get("b64_json"):
        return base64.b64decode(data[0]["b64_json"])
    return _download("Together AI", data[0]["url"])


# OpenAI shut gpt-image-1 down on 23 October 2026, the others follow on 1 December 2026.
OPENAI_RETIRED = {"gpt-image-1", "gpt-image-1-mini", "gpt-image-1.5", "chatgpt-image-latest", "dall-e-2", "dall-e-3"}


def _openai(key, model, prompt, vertical, quality="medium"):
    if not model or model in OPENAI_RETIRED or model.startswith("gpt-image-1.5"):
        model = "gpt-image-2.5-flare"
    body = {"model": model, "prompt": prompt, "size": "1024x1536" if vertical else "1536x1024",
            "quality": quality, "n": 1}
    r = net.request("OpenAI Images", "POST", "https://api.openai.com/v1/images/generations",
                    headers={"Authorization": f"Bearer {key}"}, json=body, timeout=300)
    data = r.json().get("data") or []
    if not data:
        raise UserError("OpenAI не вернул картинку")
    if data[0].get("b64_json"):
        return base64.b64decode(data[0]["b64_json"])
    return _download("OpenAI", data[0]["url"])


REFERENCE_MODEL = "fal-ai/nano-banana/edit"
MAX_REFERENCE_IMAGES = 3  # the editing model works best with a few pictures: one per character
MAX_ITEM_IMAGES = 2  # and one per item, on top of the characters
REFERENCE_PRICE = 0.04  # approximate USD per image
# The model that draws pictures by reference (characters, items, places). FLUX.2 Dev Edit is billed per megapixel
# of every input and of the output, so it is cheapest with one reference (a place) and takes at most 4 pictures.
REF_MODELS = {
    "nano": ("fal-ai/nano-banana/edit", "Nano Banana: лучше всего держит лица и места, ~$0.04 за картинку"),
    "flux2": ("fal-ai/flux-2/edit", "Экономно: FLUX.2 Dev Edit, когда образцов 1-2"),
}
FLUX2_MAX_INPUTS = 2  # with more inputs FLUX.2 costs more than Nano Banana, so those pictures go to Nano Banana
FLUX2_PER_MP = 0.012


def _ref_model(settings) -> str:
    return settings.get("ref_model") if settings.get("ref_model") in REF_MODELS else "nano"


def _flux2_size(vertical: bool, square: bool) -> dict:
    return {"width": 1024, "height": 1024} if square else \
        {"width": 768, "height": 1344} if vertical else {"width": 1344, "height": 768}


def _inputs(refs, place, items) -> int:
    return (1 if place else 0) + len((refs or [])[:MAX_REFERENCE_IMAGES]) + len((items or [])[:MAX_ITEM_IMAGES])


def _use_flux2(settings, refs, place, items) -> bool:
    return _ref_model(settings) == "flux2" and _inputs(refs, place, items) <= FLUX2_MAX_INPUTS


def reference_price(settings, refs: list = None, place=None, items: list = None) -> float:
    """Approximate USD for one picture drawn by reference."""
    if royal_refs(settings):
        return price_per_image({**settings, "royal_image_model": _royal_ref_model(settings)})
    if not _use_flux2(settings, refs, place, items):
        return REFERENCE_PRICE
    return round((_inputs(refs, place, items) + 1.03) * FLUX2_PER_MP, 4)  # every input is resized to 1 MP


def _royal_ref_model(settings) -> str:
    m = settings.get("royal_image_model")
    return m if m in ROYAL_REF else "nano-banana-2"


def _sheet(paths: list):
    """Puts several photos of one character side by side on a white sheet."""
    from PIL import Image
    ims = [Image.open(p).convert("RGB") for p in paths[:9]]
    if len(ims) == 1:
        return ims[0]
    cols = 2 if len(ims) <= 4 else 3
    rows = -(-len(ims) // cols)
    cell = 512
    sheet = Image.new("RGB", (cols * cell, rows * cell), "white")
    for i, im in enumerate(ims):
        im.thumbnail((cell - 8, cell - 8))
        x, y = (i % cols) * cell, (i // cols) * cell
        sheet.paste(im, (x + (cell - im.width) // 2, y + (cell - im.height) // 2))
    return sheet


def generate_with_reference(settings, prompt: str, refs: list, vertical: bool = False, square: bool = False,
                            place=None, items: list = None, keep_view: bool = False, example: bool = False) -> bytes:
    """A new picture where the characters look like their portraits and the items like their photos
    (fal.ai, image editing model). Order of the pictures: the place, one sheet per character, one per item.
    keep_view: the place picture is an enlarged crop to redraw sharp with exactly its framing."""
    from PIL import Image
    import io
    royal = royal_refs(settings)
    key = settings.get("fal_key")
    if not key and not royal:
        raise UserError("Для картинок по портрету нужен ключ fal.ai или RoyalTechno (Настройки → Картинки).")
    refs = list(refs[:MAX_REFERENCE_IMAGES])
    items = list((items or [])[:MAX_ITEM_IMAGES])
    flux2 = _use_flux2(settings, refs, place, items) and not royal
    pics = ([place] if place else []) + refs + items
    urls = []
    for pic in pics:
        # A list is several photos of one character or item (front, side, back...): they go in as one sheet.
        im = _sheet(pic) if isinstance(pic, (list, tuple)) else Image.open(pic).convert("RGB")
        im.thumbnail((1536, 1536))
        buf = io.BytesIO()
        im.save(buf, "JPEG", quality=90)
        urls.append("data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode())

    def which(start, n):
        if flux2:  # FLUX.2 names its inputs @image1, @image2...
            return (f"@image{start} shows" if n == 1
                    else " and ".join(f"@image{i}" for i in range(start, start + n)) + " show")
        if len(pics) == 1:
            return "The reference image shows"
        return (f"Reference image {start} shows" if n == 1 else f"Reference images {start}-{start + n - 1} show")

    parts = [f"Recreate this exact frame as a sharp high-resolution photograph: {prompt}" if keep_view
             else f"Create a new illustration: {prompt}"]
    if vertical:
        parts.append("The result is a tall vertical 9:16 picture that fills the whole frame, whatever the shape of "
                     "the reference images; no white or empty margins.")
    n = 1
    if place and keep_view:
        parts.append(f"{which(n, 1)} the frame to recreate, an enlarged crop of a bigger photo: keep exactly its framing, "
                     "camera position, composition, the position and size of every object, the background and the light. "
                     "Only make it crisp and detailed, as if shot this close with a macro lens; add no new objects.")
        n += 1
    elif place and example:
        parts.append(f"{which(n, 1)} an EXAMPLE frame from this video: keep its characters (same faces and looks), "
                     "its art style, colours and setting, but never copy its composition: build the new, far more "
                     "dramatic close-up composition described above.")
        n += 1
    elif place:
        parts.append(f"{which(n, 1)} the PLACE where this happens: keep exactly the same location, layout, colours, "
                     "furniture, objects and light, seen from the camera angle and distance described; move the camera "
                     "freely as described and never copy the viewpoint of the reference picture."
                     + ("" if refs or items else " Add the people and action described."))
        n += 1
    if refs:
        parts.append(f"{which(n, len(refs))} the character(s): they must look exactly like them (same face, hair, age, "
                     "build and typical clothing). A reference can be a sheet with several photos of one character from "
                     "different sides (front, profile, back, details): use all of them so every detail stays the same. "
                     "Draw each character only once and do not copy their reference pose or background.")
        n += len(refs)
    if items:
        parts.append(f"{which(n, len(items))} the exact item(s) or product(s) that appear in the scene: reproduce them "
                     "exactly as in the photos (same shape, proportions, colours, materials, logo, labels and text on "
                     "them), at a realistic size, placed and used as described. A reference can be a sheet with several "
                     "photos of one item from different sides. Draw each item only once and do not copy the photo's "
                     "background.")
    parts.append("No text, no letters, no watermark" + (" apart from what is printed on the items themselves." if items else "."))
    if royal:
        return _royal(settings, _royal_ref_model(settings), " ".join(parts), vertical, urls, square)
    body = {
        "prompt": " ".join(parts),
        "image_urls": urls,
        "num_images": 1,
        "output_format": "png",
    }
    if flux2:
        body.update(image_size=_flux2_size(vertical, square), enable_safety_checker=True)
    else:
        body["aspect_ratio"] = "1:1" if square else "9:16" if vertical else "16:9"
    model = REF_MODELS["flux2" if flux2 else "nano"][0]
    r = net.request("fal.ai", "POST", f"https://fal.run/{model}",
                    headers={"Authorization": f"Key {key}"}, json=body, timeout=300)
    data = r.json()
    imgs = data.get("images") or []
    if not imgs:
        raise UserError(f"fal.ai не вернул картинку по портрету: {str(data)[:300]}")
    url = imgs[0]["url"]
    if url.startswith("data:"):
        return base64.b64decode(url.split(",", 1)[1])
    return _download("fal.ai", url)
